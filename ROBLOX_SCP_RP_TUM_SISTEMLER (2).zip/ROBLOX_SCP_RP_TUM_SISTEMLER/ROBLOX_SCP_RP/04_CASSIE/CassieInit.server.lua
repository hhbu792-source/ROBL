-- ServerScriptService icine "CassieInit" adiyla normal SCRIPT olarak koy.
-- Cassie modulunu baslatir ve adminler icin sohbet komutlari ekler:
--   /cassie <metin>        bilgi anonsu
--   /cassieuyari <metin>   uyari anonsu (turuncu)
--   /cassiekritik <metin>  acil durum anonsu (kirmizi)
--   /cassietest            hazir anonslari sirayla dener

local Players = game:GetService("Players")
local ServerScriptService = game:GetService("ServerScriptService")
local TextChatService = game:GetService("TextChatService")
local TextService = game:GetService("TextService")

local Cassie = require(ServerScriptService:WaitForChild("Cassie"))

-- AdminServer'daki IsAdmin attribute'unu kullanir; oyun sahibi de her zaman yetkilidir.
local function isAdmin(player)
	return player:GetAttribute("IsAdmin") == true or player.UserId == game.CreatorId
end

-- Admin'in yazdigi, herkese gosterilecek metni filtreler
local function filter(player, text)
	local ok, result = pcall(function()
		local f = TextService:FilterStringAsync(text, player.UserId, Enum.TextFilterContext.PublicChat)
		return f:GetNonChatStringForBroadcastAsync()
	end)
	if ok then return result end
	warn("[CassieInit] filtre hatasi: " .. tostring(result))
	return nil
end

local function makeCommand(alias, handler)
	local cmd = Instance.new("TextChatCommand")
	cmd.Name = "Cmd_" .. alias
	cmd.PrimaryAlias = "/" .. alias
	cmd.Parent = TextChatService
	cmd.Triggered:Connect(function(source, text)
		local player = Players:GetPlayerByUserId(source.UserId)
		if not player or not isAdmin(player) then return end
		local rest = string.match(text, "^%S+%s*(.*)$") or ""
		handler(player, rest)
	end)
end

local function textCommand(alias, kind)
	makeCommand(alias, function(player, rest)
		if rest == "" then return end
		rest = string.sub(rest, 1, 250)
		local clean = filter(player, rest)
		if clean then
			Cassie.Announce(clean, {kind = kind})
		end
	end)
end

textCommand("cassie", "info")
textCommand("cassieuyari", "warning")
textCommand("cassiekritik", "critical")

makeCommand("cassietest", function()
	Cassie.RoundStart()
	Cassie.MTFArrival("Epsilon-11, Dokuz Kuyruklu Tilki", 3)
	Cassie.SCPContained("173", "MTF Epsilon-11")
	Cassie.DecontWarning(5)
	Cassie.WarheadStart(90)
end)

print("[CassieInit] hazir")
