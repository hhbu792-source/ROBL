-- ReplicatedStorage icine "CassieConfig" adiyla MODULESCRIPT olarak koy.
-- Hem server hem client bunu kullanir. Tum CASSIE ayarlari burada.

local Config = {}

-- ZAMANLAMA (saniye)
Config.WORD_TIME = 0.45     -- her kelime icin temel sure
Config.PAUSE_COMMA = 0.25   -- virgul / noktalı virgul sonrasi ek bekleme
Config.PAUSE_PERIOD = 0.6   -- nokta / unlem / soru / iki nokta sonrasi ek bekleme
Config.START_DELAY = 1.2    -- zil sesinden sonra yazi baslamadan once bekleme
Config.END_PADDING = 2.5    -- yazi bittikten sonra ekranda kalma suresi
Config.GAP = 1.0            -- iki anons arasindaki bosluk

-- SES
Config.VOLUME = 0.8
Config.BELL_ID = ""         -- anons oncesi zil sesi: "rbxassetid://123456" (bos = zil yok)

-- KELIME SESLERI (istege bagli)
-- Kelime kucuk harfle yazilir, noktalama yazilmaz. Ses dosyasi olmayan kelime sessiz kalir,
-- yazi her durumda ekranda gorunur.
Config.WORD_SOUNDS = {
	-- ["dikkat"] = "rbxassetid://123456",
	-- ["tesis"] = "rbxassetid://123457",
}

-- ANONS TURLERI (renk ve etiket)
Config.KINDS = {
	info     = {label = "BİLGİ",      color = Color3.fromRGB(90, 160, 255)},
	warning  = {label = "UYARI",      color = Color3.fromRGB(255, 170, 60)},
	critical = {label = "ACİL DURUM", color = Color3.fromRGB(235, 70, 70)},
}

----------------------------------------------------------------
-- OTOMATIK OLAY DUYURULARI (CassieEvents scripti kullanir)
----------------------------------------------------------------
Config.EVENTS = {
	-- 1) ONEMLI KISI OLUMU
	-- Isim "Unvan|Isim" seklinde verilirse (ornek: Tesis Komutanı|Liewex) ve unvan asagidaki
	-- listedeyse oyuncu "onemli kisi" sayilir. Yetki seviyesi VIP_MIN_LEVEL ve ustuyse de sayilir.
	-- Unvandaki Turkce buyuk/kucuk harfler listedekiyle AYNI yazilmali (İ, ı gibi).
	VIP_TITLES = {"Tesis Komutanı", "Tesis Yöneticisi", "Saha Direktörü", "Güvenlik Şefi", "Bilim Direktörü"},
	VIP_MIN_LEVEL = 6,   -- 0 yaparsan seviyeye bakmaz
	VIP_DEATH_DELAY = 4, -- olumden kac saniye sonra duyurulsun

	-- 2) TESISE GIRIS (takim adi -> duyuru). Toplu girislerde cooldown sayesinde tek anons okunur.
	TEAM_ARRIVALS = {
		["Chaos Insurgency"] = {
			text = "Dikkat. Kaos İsyancıları tesise giriş yaptı. Yetkisiz silahlı personel tespit edildi.",
			kind = "critical", cooldown = 90,
		},
		["GOC"] = {
			text = "Dikkat. Küresel Okült Koalisyon birimleri tesise giriş yaptı.",
			kind = "critical", cooldown = 90,
		},
	},

	-- 3) RUTBELI GIRISI
	-- Asagidaki rollerden biri tesise girince, ADMIN'IN VERDIGI ISIMLE anons okunur.
	-- Ornek: isim "Tesis Teğmeni|Liewex" ise ->
	--   "DİKKAT DİKKAT. TESİS TEĞMENİ LİEWEX TESİSE GİRİŞ YAPMIŞTIR. BİLGİNİZE."
	-- Isim verilmemisse title + oyuncunun gorunen adi okunur.
	-- Minimum rutbe NTF Çavuşu: yeni rutbe eklemek icin roles tablosuna bir satir ekle.
	RANK_ARRIVALS = {
		template = "Dikkat dikkat. %s tesise giriş yapmıştır. Bilginize.", -- %s = isim
		kind = "warning",
		uppercase = true,  -- tum anons BUYUK HARFLE (Turkce harflere uygun)
		cooldown = 60,     -- ayni oyuncu icin tekrar duyuru araligi (sn)
		roles = {
			-- rol anahtari = {team = rolun takimi (baska takimdaysa duyurulmaz), title = isim yoksa kullanilacak unvan}
			ntf_cavus = {team = "MTF", title = "NTF Çavuşu"},
			ntf_albay = {team = "MTF", title = "NTF Albayı"},
		},
	},

	-- 4) SILAHLI D-CLASS
	-- Bir D-Class elinde silahla, tanik takimlardan birinin gorus alaninda ve gorus mesafesinde
	-- ise duyurulur.
	ARMED_D = {
		enabled = true,
		dTeam = "Class-D",
		witnessTeams = {"Scientist", "Facility Guard", "MTF"}, -- kimler gorurse duyurulsun
		weapons = {"Pistol", "Rifle"},  -- silah sayilan Tool adlari (veya Tool'a IsWeapon = true attribute'u ver)
		range = 60,             -- gorus mesafesi (stud)
		viewAngle = 120,        -- taniğin gorus acisi (derece)
		perPlayerCooldown = 120, -- ayni D-Class icin tekrar duyuru araligi (sn)
		globalCooldown = 20,     -- herhangi iki silahli D-Class duyurusu arasi (sn)
		scanInterval = 0.75,
	},
}

-- Kelimeyi ses aramasi icin sadelestirir (kucuk harf, noktalama yok)
function Config.Normalize(word)
	local lowered = string.lower(word)
	local cleaned = string.gsub(lowered, "[%.,!%?:;\"']", "")
	return cleaned
end

-- Metni kelimelere boler; her kelimenin ne kadar bekleyecegini ve toplam sureyi dondurur.
-- Server (kuyruk suresi) ve client (yazi hizi) AYNI fonksiyonu kullanir, boylece senkron kalir.
function Config.Schedule(text)
	local words = {}
	local total = Config.START_DELAY

	for w in string.gmatch(text, "%S+") do
		local delay = Config.WORD_TIME
		local last = string.sub(w, -1)
		if last == "," or last == ";" then
			delay += Config.PAUSE_COMMA
		elseif last == "." or last == "!" or last == "?" or last == ":" then
			delay += Config.PAUSE_PERIOD
		end
		table.insert(words, {text = w, key = Config.Normalize(w), delay = delay})
		total += delay
	end

	total += Config.END_PADDING
	return words, total
end

return Config
