-- ServerScriptService icine "CassieEvents" adiyla normal SCRIPT olarak koy.
-- Otomatik CASSIE duyurulari:
--   1) Onemli kisi (ornek: "Tesis Komutanı|Liewex") olunce
--   2) Kaos / GOC tesise girince
--   3) Rutbeli (NTF Albayi, Kaos Komutani ...) tesise girince
--   4) Bir oyuncu silahli D-Class gorunce
-- Tum ayarlar CassieConfig > Config.EVENTS icinde.

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerScriptService = game:GetService("ServerScriptService")
local TextService = game:GetService("TextService")

local Config = require(ReplicatedStorage:WaitForChild("CassieConfig"))
local Cassie = require(ServerScriptService:WaitForChild("Cassie"))
local E = Config.EVENTS

----------------------------------------------------------------
-- YARDIMCI FONKSIYONLAR
----------------------------------------------------------------
local function trimLower(s)
	s = string.lower(s)
	s = string.gsub(s, "^%s+", "")
	s = string.gsub(s, "%s+$", "")
	return s
end

-- Herkese gosterilecek ismi filtreler; basarisizsa nil doner
local function filterPublic(player, text)
	local ok, result = pcall(function()
		local f = TextService:FilterStringAsync(text, player.UserId, Enum.TextFilterContext.PublicChat)
		return f:GetNonChatStringForBroadcastAsync()
	end)
	if ok and result then return result end
	warn("[CassieEvents] filtre hatasi: " .. tostring(result))
	return nil
end

local function isAlive(player)
	local char = player.Character
	local hum = char and char:FindFirstChildOfClass("Humanoid")
	return hum ~= nil and hum.Health > 0
end

local function teamName(player)
	return player.Team and player.Team.Name or nil
end

----------------------------------------------------------------
-- 1) ONEMLI KISI OLUMU
----------------------------------------------------------------
local function isVIP(player)
	local name = player:GetAttribute("RPName")
	if typeof(name) == "string" then
		local title = string.match(name, "^(.-)|") or name
		title = trimLower(title)
		for _, t in ipairs(E.VIP_TITLES) do
			if trimLower(t) == title then return true end
		end
	end

	if E.VIP_MIN_LEVEL and E.VIP_MIN_LEVEL > 0 then
		local level = player:GetAttribute("RPLevel")
		if typeof(level) == "string" then
			local n = tonumber(string.match(level, "%d+"))
			if n and n >= E.VIP_MIN_LEVEL then return true end
		end
	end
	return false
end

local function hookDeath(player, char)
	local hum = char:WaitForChild("Humanoid", 10)
	if not hum then return end

	hum.Died:Connect(function()
		if not isVIP(player) then return end
		local rawName = player:GetAttribute("RPName") or player.DisplayName
		-- "Tesis Komutanı|Liewex" -> "Tesis Komutanı Liewex"
		local spoken = string.gsub(rawName, "%s*|%s*", " ")

		task.delay(E.VIP_DEATH_DELAY, function()
			local safe = filterPublic(player, spoken) or player.DisplayName
			Cassie.VIPDead(safe)
		end)
	end)
end

----------------------------------------------------------------
-- 2 + 3) TESISE GIRIS / RUTBELI GIRISI
----------------------------------------------------------------
local lastArrival = {}

local function tryArrival(key, cfg)
	local now = os.clock()
	if lastArrival[key] and now - lastArrival[key] < cfg.cooldown then return end
	lastArrival[key] = now
	Cassie.Announce(cfg.text, {kind = cfg.kind or "warning"})
end

-- Turkce buyuk harf (i -> İ, ı -> I ...); string.upper bunu dogru yapmaz
local TR_UPPER = {["i"] = "İ", ["ı"] = "I", ["ç"] = "Ç", ["ğ"] = "Ğ", ["ö"] = "Ö", ["ş"] = "Ş", ["ü"] = "Ü"}

local function trUpper(s)
	local ok, result = pcall(function()
		local out = {}
		for _, cp in utf8.codes(s) do
			local ch = utf8.char(cp)
			table.insert(out, TR_UPPER[ch] or string.upper(ch))
		end
		return table.concat(out)
	end)
	return ok and result or string.upper(s)
end

local lastRank = {}

-- Rutbeli biri girince admin'in verdigi isimle anons yapar
local function announceRank(player, rankCfg)
	local R = E.RANK_ARRIVALS
	local now = os.clock()
	if lastRank[player] and now - lastRank[player] < R.cooldown then return end
	lastRank[player] = now

	local who
	local rawName = player:GetAttribute("RPName")
	if typeof(rawName) == "string" and rawName ~= "" then
		-- "Tesis Teğmeni|Liewex" -> "Tesis Teğmeni Liewex"
		who = string.gsub(rawName, "%s*|%s*", " ")
	else
		who = rankCfg.title .. " " .. player.DisplayName
	end

	who = filterPublic(player, who) or player.DisplayName

	local text = string.format(R.template, who)
	if R.uppercase then text = trUpper(text) end
	Cassie.Announce(text, {kind = R.kind or "warning", priority = 4})
end

Players.PlayerRemoving:Connect(function(p) lastRank[p] = nil end)

local function checkArrivals(player)
	local team = teamName(player)
	-- Lobi / izleyici takimindaki dogumlar "tesise giris" sayilmaz
	if not team or team == "Lobby" or team == "Spectator" then return end

	local teamCfg = E.TEAM_ARRIVALS[team]
	if teamCfg then
		tryArrival("team:" .. team, teamCfg)
	end

	local roleKey = player:GetAttribute("RoleKey")
	local rankCfg = roleKey and E.RANK_ARRIVALS.roles[roleKey]
	if rankCfg and rankCfg.team == team then
		announceRank(player, rankCfg)
	end
end

----------------------------------------------------------------
-- OYUNCU BAGLANTILARI
----------------------------------------------------------------
local function onPlayer(player)
	player.CharacterAdded:Connect(function(char)
		hookDeath(player, char)
		checkArrivals(player)
	end)
	if player.Character then
		hookDeath(player, player.Character)
	end
end

Players.PlayerAdded:Connect(onPlayer)
for _, p in ipairs(Players:GetPlayers()) do onPlayer(p) end

----------------------------------------------------------------
-- 4) SILAHLI D-CLASS
----------------------------------------------------------------
local A = E.ARMED_D

local witnessTeams = {}
for _, t in ipairs(A.witnessTeams) do witnessTeams[t] = true end
local minDot = math.cos(math.rad(A.viewAngle / 2))

local function hasWeaponInHand(char)
	for _, child in ipairs(char:GetChildren()) do
		if child:IsA("Tool") and (child:GetAttribute("IsWeapon") == true or table.find(A.weapons, child.Name)) then
			return true
		end
	end
	return false
end

-- Taniğin gorus acisi, mesafesi ve engel olup olmadigi
local function canSee(observer, target)
	local oChar, tChar = observer.Character, target.Character
	local oHead = oChar and oChar:FindFirstChild("Head")
	local tHead = tChar and tChar:FindFirstChild("Head")
	if not oHead or not tHead then return false end

	local offset = tHead.Position - oHead.Position
	local dist = offset.Magnitude
	if dist > A.range then return false end
	if dist > 0.1 and offset.Unit:Dot(oHead.CFrame.LookVector) < minDot then return false end

	local params = RaycastParams.new()
	params.FilterDescendantsInstances = {oChar, tChar}
	params.FilterType = Enum.RaycastFilterType.Exclude
	return workspace:Raycast(oHead.Position, offset, params) == nil
end

-- Istege bagli: Workspace > Zones klasorundeki buyuk Part'larin adi bolge adi olur
local function getZone(position)
	local zones = workspace:FindFirstChild("Zones")
	if not zones then return nil end
	for _, part in ipairs(zones:GetChildren()) do
		if part:IsA("BasePart") then
			local rel = part.CFrame:PointToObjectSpace(position)
			local half = part.Size / 2
			if math.abs(rel.X) <= half.X and math.abs(rel.Y) <= half.Y and math.abs(rel.Z) <= half.Z then
				return part.Name
			end
		end
	end
	return nil
end

local lastGlobal = -math.huge
local lastPerPlayer = {}

local function scanArmedD()
	local now = os.clock()
	if now - lastGlobal < A.globalCooldown then return end

	for _, d in ipairs(Players:GetPlayers()) do
		if teamName(d) == A.dTeam and isAlive(d) and hasWeaponInHand(d.Character) then
			local last = lastPerPlayer[d]
			if not last or now - last >= A.perPlayerCooldown then
				for _, w in ipairs(Players:GetPlayers()) do
					if w ~= d and witnessTeams[teamName(w) or ""] and isAlive(w) and canSee(w, d) then
						lastGlobal = now
						lastPerPlayer[d] = now
						local root = d.Character:FindFirstChild("HumanoidRootPart")
						Cassie.ArmedDClass(root and getZone(root.Position) or nil)
						return
					end
				end
			end
		end
	end
end

Players.PlayerRemoving:Connect(function(p) lastPerPlayer[p] = nil end)

if A.enabled then
	task.spawn(function()
		while true do
			task.wait(A.scanInterval)
			local ok, err = pcall(scanArmedD)
			if not ok then warn("[CassieEvents] tarama hatasi: " .. tostring(err)) end
		end
	end)
end

print("[CassieEvents] hazir")
