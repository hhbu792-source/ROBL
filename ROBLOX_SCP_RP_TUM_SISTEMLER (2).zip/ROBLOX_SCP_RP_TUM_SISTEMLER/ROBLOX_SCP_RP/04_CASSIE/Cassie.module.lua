-- ServerScriptService icine "Cassie" adiyla MODULESCRIPT olarak koy.
-- Baska script'ler: local Cassie = require(game.ServerScriptService.Cassie)

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Config = require(ReplicatedStorage:WaitForChild("CassieConfig"))

-- Client'a anons gonderen remote
local remote = ReplicatedStorage:FindFirstChild("CassieAnnounce")
if not remote then
	remote = Instance.new("RemoteEvent")
	remote.Name = "CassieAnnounce"
	remote.Parent = ReplicatedStorage
end

local Cassie = {}

----------------------------------------------------------------
-- KUYRUK: anonslar ust uste binmez, oncelige gore siralanir
----------------------------------------------------------------
local PRIORITY = {info = 1, warning = 2, critical = 3}
local queue = {}
local order = 0
local running = false

local function runQueue()
	if running then return end
	running = true
	task.spawn(function()
		while #queue > 0 do
			table.sort(queue, function(a, b)
				if a.priority ~= b.priority then return a.priority > b.priority end
				return a.order < b.order
			end)
			local item = table.remove(queue, 1)
			remote:FireAllClients(item.text, item.kind)
			task.wait(item.duration + Config.GAP)
		end
		running = false
	end)
end

-- opts.kind: "info" | "warning" | "critical"   (varsayilan info)
-- opts.priority: sayi, buyuk olan once okunur  (varsayilan turun onceligi)
function Cassie.Announce(text, opts)
	if typeof(text) ~= "string" or text == "" then return end
	opts = opts or {}
	local kind = Config.KINDS[opts.kind] and opts.kind or "info"
	local _, duration = Config.Schedule(text)

	order += 1
	table.insert(queue, {
		text = text,
		kind = kind,
		priority = opts.priority or PRIORITY[kind],
		order = order,
		duration = duration,
	})
	runQueue()
end

-- Bekleyen anonslari siler (okunmakta olan bitene kadar devam eder)
function Cassie.Clear()
	table.clear(queue)
end

----------------------------------------------------------------
-- HAZIR ANONSLAR
----------------------------------------------------------------
function Cassie.RoundStart()
	Cassie.Announce("Dikkat. Tesis yönetimi tüm personeli göreve çağırıyor. Muhafaza protokolleri aktif.", {kind = "warning"})
end

-- unit: ör. "Epsilon-11, Dokuz Kuyruklu Tilki"
function Cassie.MTFArrival(unit, scpCount)
	local text
	if scpCount and scpCount > 0 then
		text = string.format("Mobil Görev Gücü, %s birimi, tesise giriş yaptı. Tespit edilen SCP sayısı: %d.", unit, scpCount)
	else
		text = string.format("Mobil Görev Gücü, %s birimi, tesise giriş yaptı. Tüm SCP nesneleri muhafaza altında.", unit)
	end
	Cassie.Announce(text, {kind = "info"})
end

function Cassie.ChaosAlert()
	Cassie.Announce("Dikkat. Yetkisiz silahlı personel tesise giriş yaptı. Güvenlik protokolü devrede.", {kind = "warning"})
end

function Cassie.Breach(scpName)
	Cassie.Announce(string.format("Dikkat. SCP %s muhafazayı ihlal etti.", scpName), {kind = "critical"})
end

function Cassie.SCPContained(scpName, unit)
	if unit and unit ~= "" then
		Cassie.Announce(string.format("SCP %s muhafaza edildi. Muhafaza birimi: %s.", scpName, unit), {kind = "info"})
	else
		Cassie.Announce(string.format("SCP %s muhafaza edildi.", scpName), {kind = "info"})
	end
end

function Cassie.SCPTerminated(scpName, cause)
	Cassie.Announce(string.format("SCP %s sonlandırıldı. Sebep: %s.", scpName, cause or "bilinmiyor"), {kind = "info"})
end

function Cassie.DecontWarning(minutes)
	Cassie.Announce(string.format("Hafif Muhafaza Bölgesi dekontaminasyonuna %d dakika kaldı. Tüm personel bölgeyi terk etsin.", minutes), {kind = "warning"})
end

function Cassie.DecontStart()
	Cassie.Announce("Hafif Muhafaza Bölgesi dekontaminasyonu başladı.", {kind = "critical"})
end

function Cassie.WarheadStart(seconds)
	Cassie.Announce(string.format("Alfa Savaş Başlığı başlatıldı. Patlamaya %d saniye. Tüm personel yüzeye çıksın.", seconds), {kind = "critical", priority = 10})
end

function Cassie.WarheadCancel()
	Cassie.Announce("Alfa Savaş Başlığı iptal edildi.", {kind = "warning", priority = 10})
end

function Cassie.WarheadDetonated()
	Cassie.Announce("Alfa Savaş Başlığı patladı. Tesis imha edildi.", {kind = "critical", priority = 10})
end

-- who: ör. "Tesis Komutanı Liewex"
function Cassie.VIPDead(who)
	Cassie.Announce(string.format("Dikkat. %s ölü bulundu.", who), {kind = "critical", priority = 5})
end

-- zone: bölge adı (yoksa nil)
function Cassie.ArmedDClass(zone)
	if zone and zone ~= "" then
		Cassie.Announce(string.format("Dikkat. %s bölgesinde silahlı D-Class tespit edildi.", zone), {kind = "warning", priority = 4})
	else
		Cassie.Announce("Dikkat. Silahlı D-Class tespit edildi.", {kind = "warning", priority = 4})
	end
end

print("[Cassie] hazir")

return Cassie
