-- StarterPlayer > StarterPlayerScripts icine "CassieClient" adiyla LOCALSCRIPT olarak koy.

print("[CassieClient] basladi")

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")
local SoundService = game:GetService("SoundService")
local Debris = game:GetService("Debris")

local player = Players.LocalPlayer
local Config = require(ReplicatedStorage:WaitForChild("CassieConfig"))

----------------------------------------------------------------
-- ARAYUZ
----------------------------------------------------------------
local gui = Instance.new("ScreenGui")
gui.Name = "Cassie"
gui.ResetOnSpawn = false
gui.IgnoreGuiInset = true
gui.DisplayOrder = 100
gui.Parent = player:WaitForChild("PlayerGui")

local HIDDEN_POS = UDim2.new(0.5, -310, 0, -140)
local SHOWN_POS = UDim2.new(0.5, -310, 0, 100) -- HUD'daki round kutusunun altinda

local frame = Instance.new("Frame")
frame.Size = UDim2.fromOffset(620, 110)
frame.Position = HIDDEN_POS
frame.BackgroundColor3 = Color3.fromRGB(18, 20, 26)
frame.BackgroundTransparency = 0.08
frame.Visible = false
frame.Parent = gui
Instance.new("UICorner", frame).CornerRadius = UDim.new(0, 8)

local stroke = Instance.new("UIStroke")
stroke.Thickness = 2
stroke.Parent = frame

local accent = Instance.new("Frame")
accent.Size = UDim2.new(0, 6, 1, 0)
accent.BorderSizePixel = 0
accent.Parent = frame
Instance.new("UICorner", accent).CornerRadius = UDim.new(0, 8)

local header = Instance.new("TextLabel")
header.Size = UDim2.new(1, -30, 0, 22)
header.Position = UDim2.fromOffset(20, 8)
header.BackgroundTransparency = 1
header.TextXAlignment = Enum.TextXAlignment.Left
header.Font = Enum.Font.GothamBold
header.TextSize = 14
header.Parent = frame

local body = Instance.new("TextLabel")
body.Size = UDim2.new(1, -36, 1, -40)
body.Position = UDim2.fromOffset(20, 32)
body.BackgroundTransparency = 1
body.TextXAlignment = Enum.TextXAlignment.Left
body.TextYAlignment = Enum.TextYAlignment.Top
body.TextWrapped = true
body.Font = Enum.Font.Gotham
body.TextSize = 19
body.TextColor3 = Color3.fromRGB(240, 240, 245)
body.Text = ""
body.Parent = frame

----------------------------------------------------------------
-- SES
----------------------------------------------------------------
local function playSound(id)
	if typeof(id) ~= "string" or id == "" then return end
	local s = Instance.new("Sound")
	s.SoundId = id
	s.Volume = Config.VOLUME
	s.Parent = SoundService
	s:Play()
	Debris:AddItem(s, 15)
end

----------------------------------------------------------------
-- ANONS GOSTERIMI
----------------------------------------------------------------
local token = 0

local function slide(show)
	if show then frame.Visible = true end
	local tween = TweenService:Create(
		frame,
		TweenInfo.new(0.35, Enum.EasingStyle.Quad, Enum.EasingDirection.Out),
		{Position = show and SHOWN_POS or HIDDEN_POS}
	)
	tween:Play()
	if not show then
		tween.Completed:Once(function()
			-- yeni bir anons baslamadiysa gizle
			if frame.Position == HIDDEN_POS then frame.Visible = false end
		end)
	end
end

local function show(text, kind)
	token += 1
	local myToken = token

	local style = Config.KINDS[kind] or Config.KINDS.info
	stroke.Color = style.color
	accent.BackgroundColor3 = style.color
	header.TextColor3 = style.color
	header.Text = "CASSIE  ·  " .. style.label
	body.Text = ""

	local words = Config.Schedule(text)
	slide(true)
	playSound(Config.BELL_ID)

	task.spawn(function()
		task.wait(Config.START_DELAY)
		local shown = {}
		for _, w in ipairs(words) do
			if myToken ~= token then return end -- yeni anons geldi
			table.insert(shown, w.text)
			body.Text = table.concat(shown, " ")
			playSound(Config.WORD_SOUNDS[w.key])
			task.wait(w.delay)
		end
		task.wait(Config.END_PADDING)
		if myToken == token then slide(false) end
	end)
end

----------------------------------------------------------------
-- SERVER BAGLANTISI
----------------------------------------------------------------
task.spawn(function()
	local remote = ReplicatedStorage:WaitForChild("CassieAnnounce", 15)
	if not remote then
		warn("[CassieClient] CassieAnnounce bulunamadi - CassieInit/Cassie server'da calismiyor")
		return
	end
	remote.OnClientEvent:Connect(show)
	print("[CassieClient] server baglandi")
end)
