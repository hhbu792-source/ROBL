# Roblox SCP:SL Tarzı RP Oyunu — Tüm Sistemler

Bu zipte sohbet boyunca yazılan **bütün script'ler** sistem sistem klasörlere ayrılmış halde bulunur.
Her dosyanın ilk satırlarında Studio'da nereye konacağı da yazar.

## Dosya adı = script türü

| Uzantı | Studio'daki türü |
|---|---|
| `Ad.server.lua` | **Script** |
| `Ad.client.lua` | **LocalScript** |
| `Ad.module.lua` | **ModuleScript** |

Studio'daki script'in adı, dosya adının ilk noktaya kadar olan kısmıdır
(`HudClient.client.lua` → `HudClient`). Dosyanın içeriğini script'e yapıştır.

## Nereye konacak (toplam 11 script: 5 Script, 4 LocalScript, 2 ModuleScript)

| Klasör | Script adı | Tür | Studio'da konum |
|---|---|---|---|
| 01_Round | `RoundManager` | Script | `ServerScriptService` |
| 02_Admin_ve_Roller | `AdminServer` | Script | `ServerScriptService` |
| 02_Admin_ve_Roller | `AdminPanelClient` | LocalScript | `StarterPlayer > StarterPlayerScripts` |
| 03_RP_Konsol | `RPConsoleServer` | Script | `ServerScriptService` |
| 03_RP_Konsol | `RPConsoleClient` | LocalScript | `StarterPlayer > StarterPlayerScripts` |
| 04_CASSIE | `CassieConfig` | **ModuleScript** | **`ReplicatedStorage`** |
| 04_CASSIE | `Cassie` | **ModuleScript** | `ServerScriptService` |
| 04_CASSIE | `CassieInit` | Script | `ServerScriptService` |
| 04_CASSIE | `CassieEvents` | Script | `ServerScriptService` |
| 04_CASSIE | `CassieClient` | LocalScript | `StarterPlayer > StarterPlayerScripts` |
| 05_HUD | `HudClient` | LocalScript | `StarterPlayer > StarterPlayerScripts` |

## Studio'da elle hazırlanacaklar

1. `Workspace > Spawns` klasörü: içine şu adlarda Part'lar (her biri birden fazla olabilir):
   `ClassD`, `Scientist`, `Guard`, `SCP`, `MTF`, `Chaos`, `GOC`, `GOI`, `SerpentsHand`
2. Lobi için `Workspace` içinde bir **SpawnLocation**.
3. (İsteğe bağlı) `ServerStorage > Tools`: `Keycard2`, `Keycard3`, `Keycard4`, `Keycard5`, `Pistol`, `Rifle` adlı Tool'lar.
   Kart seviyesi için Tool adı `Keycard1..5` olmalı (veya Tool'a `KeycardLevel` attribute'u ver).
4. (İsteğe bağlı) `Workspace > Zones`: büyük, görünmez Part'lar; adları bölge adı olur ("Hafif Muhafaza Bölgesi").
   CASSIE "silahlı D-Class" anonsunda bölgeyi söyler.
5. `AdminServer` içindeki `ADMINS` listesine **kendi UserId'ni** yaz (yayınlanmamış oyunda sahip kimliği 0'dır).
6. Eski `AdminRoleSystem` script'i varsa **sil**; yerini `AdminServer` aldı.

## Kontrol: Output'ta şu satırlar görünmeli (View > Output)

```
[Cassie] hazir
[CassieInit] hazir
[CassieEvents] hazir
[RPConsoleServer] hazir
[RPConsole] client basladi
[CassieClient] basladi
[HudClient] basladi
```

## Tuşlar ve komutlar

- **M**: admin paneli (sadece adminler)
- **I / İ** (yedek **T**): RP konsolu. Komutlar: `.me .do .de .ooc .b .s .f .bayil .kalk .yardim`
- Admin sohbet komutları: `/cassie`, `/cassieuyari`, `/cassiekritik`, `/cassietest`

## Önemli notlar

- Roblox'un varsayılan **çanta (eşya çubuğu) kapalı** (`HudClient` içinde `HIDE_ROBLOX_BACKPACK`). Kapalıyken 1-2-3 tuşlarıyla
  eşya alınamaz; kendi eşya çubuğumuz yazılana kadar `false` yapabilirsin.
- `RPConsoleClient` içinde `DEBUG = true` (ekranda son basılan tuşu gösterir); sorun çözülünce `false` yap.

## Dokümanlar

- `Dokumanlar/CLAUDE.md`: proje bağlamı + **tüm kodlar** tek dosyada (Claude'a vermek için)
- `Dokumanlar/PROMPT.md`: oyunu sıfırdan yazdırmak için istem
