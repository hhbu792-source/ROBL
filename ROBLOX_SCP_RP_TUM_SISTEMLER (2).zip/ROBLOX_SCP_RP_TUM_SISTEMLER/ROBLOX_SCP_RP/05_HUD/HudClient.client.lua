-- StarterPlayer > StarterPlayerScripts icine "HudClient" adiyla LOCALSCRIPT olarak koy.
-- Icerik: round durumu, geri sayim, dalga suresi, can, kart seviyesi, rol ekrani (5 sn),
-- izleyici bilgisi ve round sonu sonuc ekrani. Tum arayuz kodla uretilir.

print("[HudClient] basladi")

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")
local StarterGui = game:GetService("StarterGui")

local player = Players.LocalPlayer

----------------------------------------------------------------
-- AYARLAR
----------------------------------------------------------------
local ROLE_SCREEN_TIME = 5   -- rol ekrani suresi (sn)
local RESULT_FADE = 0.5

local BG = Color3.fromRGB(18, 20, 26)
local PANEL = Color3.fromRGB(28, 31, 40)
local TEXT = Color3.fromRGB(240, 240, 245)
local MUTED = Color3.fromRGB(150, 155, 170)
local GREEN = Color3.fromRGB(80, 200, 120)
local RED = Color3.fromRGB(235, 70, 70)
local YELLOW = Color3.fromRGB(255, 220, 100)
local BLUE = Color3.fromRGB(90, 160, 255)

-- Takim adi -> oyuncuya gosterilecek hedef cumlesi (istedigin gibi degistir)
local OBJECTIVES = {
	["Class-D"] = "Tesisten kaç. Silah ve kart bul, hayatta kal.",
	["Scientist"] = "Hayatta kal ve tesisten kaç. Güvenlik personeline yakın dur.",
	["Facility Guard"] = "Bilim insanlarını koru, SCP'leri muhafaza et.",
	["SCP"] = "Muhafazadan çık ve tesisteki herkesi etkisiz hale getir.",
	["MTF"] = "SCP'leri muhafaza et ve hayatta kalan personeli kurtar.",
	["Chaos Insurgency"] = "D-Class'ları kurtar ve Vakıf personelini etkisiz hale getir.",
	["GOC"] = "Anormal tehditleri tespit et ve yok et.",
	["GOI"] = "Kendi hedefin için tesise sız.",
	["Serpent's Hand"] = "SCP'leri koru ve Vakıf'a karşı çalış.",
}

-- Rol adi yoksa takim adindan gosterilecek ad
local TEAM_NAMES = {
	["Class-D"] = "D-Class",
	["Scientist"] = "Bilim Adamı",
	["Facility Guard"] = "Güvenlik Personeli",
	["MTF"] = "NTF",
	["Chaos Insurgency"] = "Kaos İsyancıları",
}

local RESULTS = {
	Foundation = {title = "VAKIF KAZANDI", color = BLUE},
	SCP = {title = "SCP'LER KAZANDI", color = RED},
	Chaos = {title = "KAOS İSYANCILARI KAZANDI", color = Color3.fromRGB(255, 170, 60)},
	Timeout = {title = "SÜRE DOLDU", color = YELLOW},
	Draw = {title = "BERABERLİK", color = MUTED},
}

local PHASE_STYLE = {
	Lobby = {"LOBİ", MUTED},
	Intermission = {"ROUND BAŞLIYOR", YELLOW},
	Round = {"ROUND", GREEN},
	Ended = {"ROUND BİTTİ", RED},
}

local KEYCARD_COLORS = {
	[1] = Color3.fromRGB(200, 200, 210),
	[2] = Color3.fromRGB(90, 200, 110),
	[3] = Color3.fromRGB(255, 200, 70),
	[4] = Color3.fromRGB(255, 130, 50),
	[5] = Color3.fromRGB(235, 70, 70),
}

----------------------------------------------------------------
-- TURKCE YARDIMCILAR ("Sen X'sin" cumlesi icin)
----------------------------------------------------------------
local TR_LOWER = {["İ"] = "i", ["I"] = "ı", ["Ç"] = "ç", ["Ğ"] = "ğ", ["Ö"] = "ö", ["Ş"] = "ş", ["Ü"] = "ü"}
local VOWEL_SUFFIX = {
	["a"] = "sın", ["ı"] = "sın", ["e"] = "sin", ["i"] = "sin",
	["o"] = "sun", ["u"] = "sun", ["ö"] = "sün", ["ü"] = "sün",
}

local function trLower(s)
	local out = {}
	for _, cp in utf8.codes(s) do
		local ch = utf8.char(cp)
		table.insert(out, TR_LOWER[ch] or string.lower(ch))
	end
	return table.concat(out)
end

-- "NTF Çavuşu" -> "Sen NTF Çavuşu'sun"; kisaltmalar (NTF, GOC, SCP) -> "...'sin"
local function youAre(roleName)
	local lastWord = string.match(roleName, "(%S+)%s*$") or roleName
	local suffix = "sin"
	local isAcronym = string.find(lastWord, "%l") == nil and #lastWord <= 4
	if not isAcronym then
		local lastVowel
		for _, cp in utf8.codes(trLower(lastWord)) do
			local ch = utf8.char(cp)
			if VOWEL_SUFFIX[ch] then lastVowel = ch end
		end
		if lastVowel then suffix = VOWEL_SUFFIX[lastVowel] end
	end
	return "Sen " .. roleName .. "'" .. suffix
end

local function fmt(seconds)
	seconds = math.max(0, math.floor(seconds or 0))
	return string.format("%d:%02d", seconds // 60, seconds % 60)
end

----------------------------------------------------------------
-- ARAYUZ YARDIMCILARI
----------------------------------------------------------------
local function make(class, props, parent)
	local o = Instance.new(class)
	for k, v in pairs(props) do o[k] = v end
	o.Parent = parent
	return o
end

local function corner(obj, r)
	make("UICorner", {CornerRadius = UDim.new(0, r or 8)}, obj)
end

local function label(parent, props)
	local l = Instance.new("TextLabel")
	l.BackgroundTransparency = 1
	l.Font = Enum.Font.Gotham
	l.TextColor3 = TEXT
	l.TextSize = 14
	l.TextXAlignment = Enum.TextXAlignment.Center
	for k, v in pairs(props) do l[k] = v end
	l.Parent = parent
	return l
end

local gui = make("ScreenGui", {
	Name = "Hud", ResetOnSpawn = false, IgnoreGuiInset = true, DisplayOrder = 10,
}, player:WaitForChild("PlayerGui"))

-- Varsayilan Roblox arayuzlerini kapat (can cubugu bizde var)
local HIDE_ROBLOX_BACKPACK = true -- false yaparsan Roblox'un esya cubugu geri gelir

task.spawn(function()
	for _ = 1, 3 do
		pcall(function()
			StarterGui:SetCoreGuiEnabled(Enum.CoreGuiType.Health, false)
			if HIDE_ROBLOX_BACKPACK then
				StarterGui:SetCoreGuiEnabled(Enum.CoreGuiType.Backpack, false)
			end
		end)
		task.wait(1)
	end
end)

----------------------------------------------------------------
-- 1) UST ORTA: ROUND DURUMU
----------------------------------------------------------------
local topPill = make("Frame", {
	AnchorPoint = Vector2.new(0.5, 0), Position = UDim2.new(0.5, 0, 0, 12),
	Size = UDim2.fromOffset(340, 78), BackgroundColor3 = PANEL, BackgroundTransparency = 0.1,
}, gui)
corner(topPill, 10)
make("UIStroke", {Color = Color3.fromRGB(60, 65, 80), Thickness = 1}, topPill)

local phaseLabel = label(topPill, {
	Position = UDim2.fromOffset(0, 6), Size = UDim2.new(1, 0, 0, 16),
	Font = Enum.Font.GothamBold, TextSize = 12,
})
local timerLabel = label(topPill, {
	Position = UDim2.fromOffset(0, 22), Size = UDim2.new(1, 0, 0, 34),
	Font = Enum.Font.GothamBold, TextSize = 28,
})
local subLabel = label(topPill, {
	Position = UDim2.fromOffset(0, 57), Size = UDim2.new(1, 0, 0, 16),
	TextSize = 12, TextColor3 = MUTED,
})

----------------------------------------------------------------
-- 2) SAG ALT: KART SEVIYESI + CAN
----------------------------------------------------------------
local bottomRight = make("Frame", {
	AnchorPoint = Vector2.new(1, 1), Position = UDim2.new(1, -16, 1, -16),
	Size = UDim2.fromOffset(280, 76), BackgroundTransparency = 1,
}, gui)

-- Kart satiri
local cardRow = make("Frame", {
	Size = UDim2.new(1, 0, 0, 34), BackgroundColor3 = PANEL, BackgroundTransparency = 0.1,
}, bottomRight)
corner(cardRow, 8)

label(cardRow, {
	Position = UDim2.fromOffset(12, 0), Size = UDim2.fromOffset(40, 34),
	Text = "KART", Font = Enum.Font.GothamBold, TextSize = 12, TextColor3 = MUTED,
	TextXAlignment = Enum.TextXAlignment.Left,
})

local pips = {}
for i = 1, 5 do
	local pip = make("Frame", {
		Position = UDim2.fromOffset(58 + (i - 1) * 26, 13), Size = UDim2.fromOffset(22, 8),
		BackgroundColor3 = Color3.fromRGB(55, 60, 75), BorderSizePixel = 0,
	}, cardRow)
	corner(pip, 3)
	pips[i] = pip
end

local cardText = label(cardRow, {
	Position = UDim2.new(1, -92, 0, 0), Size = UDim2.fromOffset(80, 34),
	Font = Enum.Font.GothamBold, TextSize = 12, TextXAlignment = Enum.TextXAlignment.Right,
})

-- Can satiri
local healthRow = make("Frame", {
	Position = UDim2.fromOffset(0, 42), Size = UDim2.new(1, 0, 0, 34),
	BackgroundColor3 = PANEL, BackgroundTransparency = 0.1, ClipsDescendants = true,
}, bottomRight)
corner(healthRow, 8)

local healthFill = make("Frame", {
	Size = UDim2.fromScale(1, 1), BackgroundColor3 = GREEN, BorderSizePixel = 0, BackgroundTransparency = 0.35,
}, healthRow)

local healthText = label(healthRow, {
	Size = UDim2.fromScale(1, 1), Font = Enum.Font.GothamBold, TextSize = 15, Text = "100",
})
label(healthRow, {
	Position = UDim2.fromOffset(12, 0), Size = UDim2.fromOffset(40, 34),
	Text = "CAN", Font = Enum.Font.GothamBold, TextSize = 12, TextXAlignment = Enum.TextXAlignment.Left,
})

----------------------------------------------------------------
-- 3) IZLEYICI BILGISI
----------------------------------------------------------------
local specFrame = make("Frame", {
	AnchorPoint = Vector2.new(0.5, 1), Position = UDim2.new(0.5, 0, 1, -110),
	Size = UDim2.fromOffset(340, 40), BackgroundColor3 = PANEL, BackgroundTransparency = 0.1,
	Visible = false,
}, gui)
corner(specFrame, 8)
local specLabel = label(specFrame, {
	Size = UDim2.fromScale(1, 1), Font = Enum.Font.GothamBold, TextSize = 14,
})

----------------------------------------------------------------
-- 4) ROL EKRANI
----------------------------------------------------------------
local roleCard = make("CanvasGroup", {
	AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.new(0.5, 0, 0.34, 0),
	Size = UDim2.fromOffset(580, 200), BackgroundColor3 = BG, BackgroundTransparency = 0.05,
	GroupTransparency = 1, Visible = false,
}, gui)
corner(roleCard, 12)

local roleAccent = make("Frame", {Size = UDim2.new(1, 0, 0, 5), BorderSizePixel = 0}, roleCard)
local roleKicker = label(roleCard, {
	Position = UDim2.fromOffset(0, 18), Size = UDim2.new(1, 0, 0, 16),
	Text = "ROLÜN", Font = Enum.Font.GothamBold, TextSize = 13,
})
local roleMain = label(roleCard, {
	Position = UDim2.fromOffset(20, 40), Size = UDim2.new(1, -40, 0, 52),
	Font = Enum.Font.GothamBold, TextScaled = true,
})
make("UITextSizeConstraint", {MaxTextSize = 36, MinTextSize = 16}, roleMain)
local roleSub = label(roleCard, {
	Position = UDim2.fromOffset(20, 98), Size = UDim2.new(1, -40, 0, 22), TextSize = 16,
})
local roleGoal = label(roleCard, {
	Position = UDim2.fromOffset(30, 130), Size = UDim2.new(1, -60, 0, 56),
	TextSize = 15, TextColor3 = MUTED, TextWrapped = true, TextYAlignment = Enum.TextYAlignment.Top,
})

local roleToken = 0

local function showRole()
	local team = player.Team
	if not team or team.Name == "Lobby" or team.Name == "Spectator" then return end

	roleToken += 1
	local myToken = roleToken

	local roleName = player:GetAttribute("RoleName") or TEAM_NAMES[team.Name] or team.Name
	local ok, text = pcall(youAre, roleName)
	if not ok then text = "Sen " .. roleName end

	local color = team.TeamColor.Color
	-- cok koyu takim renkleri (Kaos: siyah) okunmaz; aciklastir
	if color.R + color.G + color.B < 0.45 then color = Color3.fromRGB(190, 190, 200) end

	roleAccent.BackgroundColor3 = color
	roleKicker.TextColor3 = color
	roleMain.Text = text

	local parts = {}
	local rpName = player:GetAttribute("RPName")
	local level = player:GetAttribute("RPLevel") or player:GetAttribute("RoleLevel")
	if typeof(rpName) == "string" and rpName ~= "" then
		table.insert(parts, (string.gsub(rpName, "%s*|%s*", " ")))
	end
	if level then table.insert(parts, tostring(level)) end
	roleSub.Text = table.concat(parts, "   ·   ")
	roleGoal.Text = OBJECTIVES[team.Name] or ""

	roleCard.Visible = true
	TweenService:Create(roleCard, TweenInfo.new(0.4), {GroupTransparency = 0}):Play()

	task.delay(ROLE_SCREEN_TIME, function()
		if myToken ~= roleToken then return end
		local tween = TweenService:Create(roleCard, TweenInfo.new(0.5), {GroupTransparency = 1})
		tween:Play()
		tween.Completed:Once(function()
			if myToken == roleToken then roleCard.Visible = false end
		end)
	end)
end

----------------------------------------------------------------
-- 5) ROUND SONU SONUC EKRANI
----------------------------------------------------------------
local resultOverlay = make("CanvasGroup", {
	Size = UDim2.fromScale(1, 1), BackgroundColor3 = Color3.new(0, 0, 0), BackgroundTransparency = 0.35,
	GroupTransparency = 1, Visible = false, ZIndex = 20,
}, gui)

local resAccent = make("Frame", {
	AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.new(0.5, 0, 0.5, -70),
	Size = UDim2.fromOffset(420, 4), BorderSizePixel = 0,
}, resultOverlay)

local resTitle = label(resultOverlay, {
	AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.new(0.5, 0, 0.5, -20),
	Size = UDim2.fromOffset(900, 70), Font = Enum.Font.GothamBold, TextSize = 52,
})
local resSub = label(resultOverlay, {
	AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.new(0.5, 0, 0.5, 38),
	Size = UDim2.fromOffset(700, 28), TextSize = 20, TextColor3 = TEXT,
})
local resMe = label(resultOverlay, {
	AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.new(0.5, 0, 0.5, 84),
	Size = UDim2.fromOffset(400, 28), Font = Enum.Font.GothamBold, TextSize = 18,
})

local currentHum = nil
local state = nil

local function isAlive()
	local team = player.Team
	if not team or team.Name == "Spectator" or team.Name == "Lobby" then return false end
	return currentHum ~= nil and currentHum.Health > 0
end

local function showResult()
	if not state then return end
	local res = RESULTS[state:GetAttribute("Result") or ""] or RESULTS.Draw
	resTitle.Text = res.title
	resTitle.TextColor3 = res.color
	resAccent.BackgroundColor3 = res.color
	resSub.Text = string.format(
		"Hayatta kalan: %d   ·   Round süresi: %s",
		state:GetAttribute("Survivors") or 0,
		fmt(state:GetAttribute("Duration") or 0)
	)
	local alive = isAlive()
	resMe.Text = alive and "HAYATTA KALDIN" or "ÖLDÜN"
	resMe.TextColor3 = alive and GREEN or RED

	resultOverlay.Visible = true
	TweenService:Create(resultOverlay, TweenInfo.new(RESULT_FADE), {GroupTransparency = 0}):Play()
end

local function hideResult()
	if not resultOverlay.Visible then return end
	local tween = TweenService:Create(resultOverlay, TweenInfo.new(RESULT_FADE), {GroupTransparency = 1})
	tween:Play()
	tween.Completed:Once(function()
		if resultOverlay.GroupTransparency >= 0.99 then resultOverlay.Visible = false end
	end)
end

----------------------------------------------------------------
-- GUNCELLEME FONKSIYONLARI
----------------------------------------------------------------
local function refreshSpectator()
	local isSpec = player.Team ~= nil and player.Team.Name == "Spectator"
	local phase = state and state:GetAttribute("Phase")
	specFrame.Visible = isSpec and phase == "Round"
	if specFrame.Visible then
		specLabel.Text = "İZLEYİCİSİN   ·   Sonraki dalga " .. fmt(state:GetAttribute("NextWave"))
	end
end

local function refreshTop()
	if not state then
		phaseLabel.Text = "ROUND"
		phaseLabel.TextColor3 = MUTED
		timerLabel.TextSize = 28
		timerLabel.Text = "--:--"
		subLabel.Text = "Round sistemi bulunamadı"
		return
	end

	local phase = state:GetAttribute("Phase") or "Lobby"
	local style = PHASE_STYLE[phase] or PHASE_STYLE.Lobby
	phaseLabel.Text = style[1]
	phaseLabel.TextColor3 = style[2]
	timerLabel.TextSize = 28

	if phase == "Lobby" then
		timerLabel.TextSize = 20
		timerLabel.Text = "Oyuncu bekleniyor"
		subLabel.Text = string.format("%d / %d oyuncu", state:GetAttribute("PlayerCount") or 0, state:GetAttribute("MinPlayers") or 0)
	elseif phase == "Intermission" then
		timerLabel.Text = fmt(state:GetAttribute("TimeLeft"))
		subLabel.Text = "Hazırlan"
	elseif phase == "Round" then
		timerLabel.Text = fmt(state:GetAttribute("TimeLeft"))
		subLabel.Text = "Sonraki dalga   " .. fmt(state:GetAttribute("NextWave"))
	else
		timerLabel.TextSize = 20
		timerLabel.Text = "Sonuçlar"
		subLabel.Text = ""
	end
	refreshSpectator()
end

local function updateHealth()
	local hum = currentHum
	if not hum then
		healthFill.Size = UDim2.fromScale(0, 1)
		healthText.Text = "0"
		return
	end
	local ratio = math.clamp(hum.Health / math.max(hum.MaxHealth, 1), 0, 1)
	healthFill.Size = UDim2.fromScale(ratio, 1)
	healthFill.BackgroundColor3 = RED:Lerp(GREEN, ratio)
	healthText.Text = tostring(math.ceil(hum.Health))
end

local function renderKeycard(level)
	for i, pip in ipairs(pips) do
		pip.BackgroundColor3 = (i <= level) and KEYCARD_COLORS[level] or Color3.fromRGB(55, 60, 75)
	end
	if level > 0 then
		cardText.Text = "SEVİYE " .. level
		cardText.TextColor3 = KEYCARD_COLORS[level]
	else
		cardText.Text = "KART YOK"
		cardText.TextColor3 = MUTED
	end
end

-- Elindeki / cantasindaki en yuksek kart seviyesi.
-- Tool adi "Keycard1".."Keycard5" olmali (ya da Tool'a KeycardLevel attribute'u ver).
local function keycardLevel()
	local best = 0
	local function scan(container)
		if not container then return end
		for _, item in ipairs(container:GetChildren()) do
			if item:IsA("Tool") then
				local lvl = item:GetAttribute("KeycardLevel") or tonumber(string.match(item.Name, "^Keycard(%d+)$"))
				if typeof(lvl) == "number" and lvl > best then best = lvl end
			end
		end
	end
	scan(player.Character)
	scan(player:FindFirstChildOfClass("Backpack"))
	return math.min(best, 5)
end

----------------------------------------------------------------
-- BAGLANTILAR
----------------------------------------------------------------
local function onCharacter(char)
	local hum = char:WaitForChild("Humanoid", 10)
	if not hum then return end
	currentHum = hum
	updateHealth()
	hum.HealthChanged:Connect(updateHealth)
	hum:GetPropertyChangedSignal("MaxHealth"):Connect(updateHealth)
	task.delay(0.8, showRole) -- rol bilgisi (attribute) gelsin diye kisa bekleme
end

player.CharacterAdded:Connect(onCharacter)
if player.Character then task.spawn(onCharacter, player.Character) end

player:GetPropertyChangedSignal("Team"):Connect(refreshSpectator)

-- Kart seviyesi: 0.4 sn'de bir bakar, sadece degisince cizer
task.spawn(function()
	local shown = -1
	while true do
		local level = keycardLevel()
		if level ~= shown then
			shown = level
			renderKeycard(level)
		end
		task.wait(0.4)
	end
end)

-- Round durumu (RoundManager yayinlar)
state = ReplicatedStorage:WaitForChild("RoundState", 10)
if state then
	state.AttributeChanged:Connect(function(name)
		refreshTop()
		if name == "Phase" then
			if state:GetAttribute("Phase") == "Ended" then showResult() else hideResult() end
		end
	end)
	if state:GetAttribute("Phase") == "Ended" then showResult() end
else
	warn("[HudClient] RoundState bulunamadi - RoundManager (yeni surum) calismiyor")
end

renderKeycard(0)
updateHealth()
refreshTop()
