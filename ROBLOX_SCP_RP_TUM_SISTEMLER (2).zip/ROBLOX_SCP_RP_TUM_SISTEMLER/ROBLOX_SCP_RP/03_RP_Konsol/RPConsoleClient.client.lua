-- StarterPlayer > StarterPlayerScripts icine "RPConsoleClient" adiyla LOCALSCRIPT olarak koy.
-- I / İ tusuyla yazma kutusu acilir. Enter gonderir, Esc kapatir.

print("[RPConsole] client basladi")

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local UserInputService = game:GetService("UserInputService")
local ContextActionService = game:GetService("ContextActionService")
local RunService = game:GetService("RunService")

local player = Players.LocalPlayer

local DEBUG = true -- true: basilan her tusu Output'a yazar. Calisinca false yap.
local MAX_ENTRIES = 60
local FADE_START = 20
local FADE_TIME = 5

----------------------------------------------------------------
-- ARAYUZ
----------------------------------------------------------------
local gui = Instance.new("ScreenGui")
gui.Name = "RPConsole"
gui.ResetOnSpawn = false
gui.DisplayOrder = 50
gui.IgnoreGuiInset = true
gui.Parent = player:WaitForChild("PlayerGui")

local feed = Instance.new("ScrollingFrame")
feed.Size = UDim2.fromOffset(460, 230)
feed.Position = UDim2.new(0, 12, 1, -310)
feed.BackgroundColor3 = Color3.new(0, 0, 0)
feed.BackgroundTransparency = 1
feed.BorderSizePixel = 0
feed.ScrollBarThickness = 4
feed.CanvasSize = UDim2.new()
feed.AutomaticCanvasSize = Enum.AutomaticSize.Y
feed.Parent = gui

local layout = Instance.new("UIListLayout")
layout.SortOrder = Enum.SortOrder.LayoutOrder
layout.Padding = UDim.new(0, 2)
layout.Parent = feed

local inputBar = Instance.new("Frame")
inputBar.Size = UDim2.fromOffset(460, 36)
inputBar.Position = UDim2.new(0, 12, 1, -60)
inputBar.BackgroundColor3 = Color3.fromRGB(24, 26, 32)
inputBar.BackgroundTransparency = 0.1
inputBar.Visible = false
inputBar.Parent = gui
Instance.new("UICorner", inputBar).CornerRadius = UDim.new(0, 8)

local box = Instance.new("TextBox")
box.Size = UDim2.new(1, -16, 1, 0)
box.Position = UDim2.fromOffset(8, 0)
box.BackgroundTransparency = 1
box.Text = ""
box.PlaceholderText = ".me  .do  .de  .ooc  .bayıl  |  yardım için .yardim"
box.PlaceholderColor3 = Color3.fromRGB(140, 145, 160)
box.TextColor3 = Color3.new(1, 1, 1)
box.Font = Enum.Font.Gotham
box.TextSize = 15
box.TextXAlignment = Enum.TextXAlignment.Left
box.ClearTextOnFocus = false
box.Parent = inputBar

-- Debug: son basilan tusu ekranda gosterir (DEBUG = false yapinca gorunmez)
local debugLabel = Instance.new("TextLabel")
debugLabel.Size = UDim2.fromOffset(300, 20)
debugLabel.Position = UDim2.new(0, 12, 1, -332)
debugLabel.BackgroundTransparency = 1
debugLabel.TextXAlignment = Enum.TextXAlignment.Left
debugLabel.Font = Enum.Font.Code
debugLabel.TextSize = 14
debugLabel.TextColor3 = Color3.fromRGB(255, 200, 80)
debugLabel.Text = "Son tuş: (henüz yok)"
debugLabel.Visible = false
debugLabel.Parent = gui

----------------------------------------------------------------
-- MESAJLAR
----------------------------------------------------------------
local entries = {}
local counter = 0
local isOpen = false

local function addMessage(text, color)
	counter += 1
	local label = Instance.new("TextLabel")
	label.Size = UDim2.new(1, -8, 0, 0)
	label.AutomaticSize = Enum.AutomaticSize.Y
	label.BackgroundTransparency = 1
	label.TextWrapped = true
	label.RichText = false
	label.TextXAlignment = Enum.TextXAlignment.Left
	label.Font = Enum.Font.Gotham
	label.TextSize = 15
	label.TextColor3 = color or Color3.new(1, 1, 1)
	label.TextStrokeTransparency = 0.5
	label.Text = text
	label.LayoutOrder = counter
	label.Parent = feed

	table.insert(entries, {label = label, time = os.clock()})
	if #entries > MAX_ENTRIES then
		local old = table.remove(entries, 1)
		old.label:Destroy()
	end

	task.defer(function()
		feed.CanvasPosition = Vector2.new(0, feed.AbsoluteCanvasSize.Y)
	end)
end

task.spawn(function()
	while true do
		task.wait(0.25)
		local now = os.clock()
		for _, e in ipairs(entries) do
			local alpha = 0
			if not isOpen then
				alpha = math.clamp((now - e.time - FADE_START) / FADE_TIME, 0, 1)
			end
			e.label.TextTransparency = alpha
			e.label.TextStrokeTransparency = 0.5 + alpha * 0.5
		end
	end
end)

----------------------------------------------------------------
-- SERVER BAGLANTISI
----------------------------------------------------------------
local remote = nil

task.spawn(function()
	local folder = ReplicatedStorage:WaitForChild("RPRemotes", 10)
	remote = folder and folder:WaitForChild("RPConsole", 10)
	if remote then
		remote.OnClientEvent:Connect(addMessage)
		addMessage("RP konsolu hazır: I / İ tuşuna bas. Komutlar için .yardim yaz.", Color3.fromRGB(255, 240, 150))
		print("[RPConsole] server baglandi")
	else
		addMessage("HATA: RPConsoleServer çalışmıyor. ServerScriptService içinde normal Script olarak durduğundan emin ol.", Color3.fromRGB(255, 120, 120))
		warn("[RPConsole] RPRemotes bulunamadi - RPConsoleServer calismiyor")
	end
end)

----------------------------------------------------------------
-- ACMA / KAPAMA
----------------------------------------------------------------
local function closeConsole()
	isOpen = false
	inputBar.Visible = false
	feed.BackgroundTransparency = 1
end

local function openConsole()
	if isOpen then return end
	isOpen = true
	inputBar.Visible = true
	feed.BackgroundTransparency = 0.6
	task.spawn(function()
		RunService.RenderStepped:Wait() -- tusun harfi kutuya yazilmasin
		box:CaptureFocus()
		box.Text = ""
	end)
end

box.FocusLost:Connect(function(enterPressed)
	local text = box.Text
	box.Text = ""
	if enterPressed and text ~= "" then
		if remote then
			remote:FireServer(text)
		else
			addMessage("Sunucuya bağlanılamadı.", Color3.fromRGB(255, 120, 120))
		end
	end
	closeConsole()
end)

----------------------------------------------------------------
-- TUS DINLEME
-- "processed" kontrolunu BILEREK kullanmiyoruz; sadece bir yazi kutusu
-- odaktaysa tusu yok sayiyoruz.
----------------------------------------------------------------
local OPEN_KEYS = {
	[Enum.KeyCode.I] = true,     -- "ı" tusu
	[Enum.KeyCode.Quote] = true, -- Turkce klavyedeki "İ" tusu
	[Enum.KeyCode.T] = true,     -- yedek tus: T her klavyede calisir
	[Enum.KeyCode.Unknown] = true, -- Roblox'un taniyamadigi tuslar (ı / İ bazen boyle gelir)
}
local OPEN_CHARS = {i = true, I = true, ["ı"] = true, ["İ"] = true}

local function isOpenKey(input)
	if input.UserInputType ~= Enum.UserInputType.Keyboard then return false end
	if OPEN_KEYS[input.KeyCode] then return true end
	local ok, s = pcall(function()
		return UserInputService:GetStringForKeyCode(input.KeyCode)
	end)
	return ok and OPEN_CHARS[s] == true
end

UserInputService.InputBegan:Connect(function(input, processed)
	if input.UserInputType == Enum.UserInputType.Keyboard and DEBUG then
		debugLabel.Visible = true
		debugLabel.Text = "Son tuş: " .. input.KeyCode.Name .. " | processed: " .. tostring(processed)
		print("[RPConsole] tus:", input.KeyCode.Name, "| processed:", processed, "| acik:", isOpen)
	end
	if isOpen then return end
	if UserInputService:GetFocusedTextBox() then return end
	if isOpenKey(input) then
		openConsole()
	end
end)

-- Ikinci yol: ContextActionService (en yuksek oncelik)
ContextActionService:BindActionAtPriority("RPConsoleOpen", function(_, state, input)
	if state == Enum.UserInputState.Begin then
		openConsole()
	end
	return Enum.ContextActionResult.Pass
end, false, Enum.ContextActionPriority.High.Value, Enum.KeyCode.I, Enum.KeyCode.Quote, Enum.KeyCode.T)
