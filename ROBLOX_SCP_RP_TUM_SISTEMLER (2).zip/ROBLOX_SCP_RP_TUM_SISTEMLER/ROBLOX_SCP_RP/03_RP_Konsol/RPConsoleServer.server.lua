-- ServerScriptService icine "RPConsoleServer" adiyla normal SCRIPT olarak koy.
-- Komutlar: .me .do .de .ooc .b .s .f .bayil .kalk .yardim (+ nokta olmadan yazilan normal konusma)

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TextService = game:GetService("TextService")

----------------------------------------------------------------
-- AYARLAR
----------------------------------------------------------------
local RANGE = {say = 25, me = 30, ["do"] = 30, de = 30, b = 25, s = 60, f = 5}
local MAX_LEN = 200
local COOLDOWN = 0.7
local MAX_FAINT_TIME = 600 -- ".bayil <saniye>" icin ust sinir

local COLORS = {
	say = Color3.fromRGB(255, 255, 255),
	me = Color3.fromRGB(196, 162, 255),
	["do"] = Color3.fromRGB(255, 205, 130),
	de_ok = Color3.fromRGB(120, 230, 140),
	de_fail = Color3.fromRGB(255, 120, 120),
	ooc = Color3.fromRGB(170, 170, 170),
	shout = Color3.fromRGB(255, 150, 120),
	whisper = Color3.fromRGB(160, 200, 255),
	system = Color3.fromRGB(255, 240, 150),
}

----------------------------------------------------------------
-- REMOTE
----------------------------------------------------------------
local folder = ReplicatedStorage:FindFirstChild("RPRemotes")
if not folder then
	folder = Instance.new("Folder")
	folder.Name = "RPRemotes"
	folder.Parent = ReplicatedStorage
end
local remote = Instance.new("RemoteEvent")
remote.Name = "RPConsole"
remote.Parent = folder

----------------------------------------------------------------
-- YARDIMCI FONKSIYONLAR
----------------------------------------------------------------
-- Turkce karakterleri sadelestirir (.bayıl = .bayil, .bağır = .bagir)
local function normalize(s)
	s = string.gsub(s, "İ", "i")
	s = string.lower(s)
	for from, to in pairs({["ı"] = "i", ["ç"] = "c", ["ş"] = "s", ["ğ"] = "g", ["ö"] = "o", ["ü"] = "u"}) do
		s = string.gsub(s, from, to)
	end
	return s
end

local function getName(player)
	return player:GetAttribute("RPName") or player.DisplayName
end

local function getRoot(player)
	local char = player.Character
	return char and char:FindFirstChild("HumanoidRootPart")
end

local function inRange(sender, other, range)
	if sender == other then return true end
	local a, b = getRoot(sender), getRoot(other)
	return a ~= nil and b ~= nil and (a.Position - b.Position).Magnitude <= range
end

-- Oyuncunun yazdigi metni filtreleyerek yakindaki / herkese gonderir.
-- formatter(filtreliMetin) -> gosterilecek satir
local function broadcastText(sender, rawText, range, color, formatter)
	local ok, filtered = pcall(function()
		return TextService:FilterStringAsync(rawText, sender.UserId, Enum.TextFilterContext.PublicChat)
	end)
	if not ok then return end

	for _, p in ipairs(Players:GetPlayers()) do
		if range == nil or inRange(sender, p, range) then
			local okRecipient, text = pcall(function()
				return filtered:GetChatForUserAsync(p.UserId)
			end)
			if okRecipient then
				remote:FireClient(p, formatter(text), color)
			end
		end
	end
end

-- Oyuncu metni icermeyen sistem/aksiyon mesaji (filtre gerekmez)
local function broadcastPlain(sender, range, color, text)
	for _, p in ipairs(Players:GetPlayers()) do
		if range == nil or inRange(sender, p, range) then
			remote:FireClient(p, text, color)
		end
	end
end

local function reply(player, text)
	remote:FireClient(player, text, COLORS.system)
end

----------------------------------------------------------------
-- BAYILMA
----------------------------------------------------------------
local faintData = {}
local faintCounter = {}

local function isFainted(player)
	return player:GetAttribute("Fainted") == true
end

local function wake(player, silent)
	local data = faintData[player]
	if not data then return end
	faintData[player] = nil
	player:SetAttribute("Fainted", false)

	local char = player.Character
	local hum = char and char:FindFirstChildOfClass("Humanoid")
	local root = getRoot(player)
	if not hum or not root then return end

	root.Anchored = false
	hum.PlatformStand = false
	hum.WalkSpeed = data.walkSpeed
	hum.JumpPower = data.jumpPower
	hum.JumpHeight = data.jumpHeight
	char:PivotTo(CFrame.new(root.Position + Vector3.new(0, 3, 0)) * CFrame.Angles(0, data.yaw, 0))

	if not silent then
		broadcastPlain(player, RANGE.me, COLORS.me, "* " .. getName(player) .. " ayağa kalktı.")
	end
end

local function faint(player, duration)
	if isFainted(player) then return end
	local char = player.Character
	local hum = char and char:FindFirstChildOfClass("Humanoid")
	local root = getRoot(player)
	if not hum or not root or hum.Health <= 0 then return end

	local _, yaw = root.CFrame:ToEulerAnglesYXZ()
	faintData[player] = {
		walkSpeed = hum.WalkSpeed,
		jumpPower = hum.JumpPower,
		jumpHeight = hum.JumpHeight,
		yaw = yaw,
	}

	hum:UnequipTools()
	hum.WalkSpeed = 0
	hum.JumpPower = 0
	hum.JumpHeight = 0
	hum.PlatformStand = true

	-- yerin yuksekligini bul, duz sirt ustu yatir
	local params = RaycastParams.new()
	params.FilterDescendantsInstances = {char}
	params.FilterType = Enum.RaycastFilterType.Exclude
	local hit = workspace:Raycast(root.Position, Vector3.new(0, -20, 0), params)
	local floorY = hit and hit.Position.Y or (root.Position.Y - 3)

	local lying = CFrame.new(root.Position.X, floorY + root.Size.Z / 2 + 0.1, root.Position.Z)
		* CFrame.Angles(0, yaw, 0)
		* CFrame.Angles(math.rad(90), 0, 0)
	char:PivotTo(lying)
	root.Anchored = true
	player:SetAttribute("Fainted", true)

	broadcastPlain(player, RANGE.me, COLORS.me, "* " .. getName(player) .. " bayıldı.")

	-- istege bagli sure: .bayil 30
	faintCounter[player] = (faintCounter[player] or 0) + 1
	local myId = faintCounter[player]
	if duration then
		task.delay(duration, function()
			if faintCounter[player] == myId and isFainted(player) then
				wake(player)
			end
		end)
	end
end

local function onPlayer(player)
	player.CharacterAdded:Connect(function()
		faintData[player] = nil
		player:SetAttribute("Fainted", false)
	end)
end
Players.PlayerAdded:Connect(onPlayer)
for _, p in ipairs(Players:GetPlayers()) do onPlayer(p) end

Players.PlayerRemoving:Connect(function(p)
	faintData[p] = nil
	faintCounter[p] = nil
end)

----------------------------------------------------------------
-- KOMUTLAR
----------------------------------------------------------------
local HELP = {
	"--- KOMUTLAR ---",
	".me <eylem>      → * İsim eylem",
	".do <durum>      → * durum ((İsim))",
	".de <eylem>      → eylemi dener, başarılı / başarısız çıkar",
	".ooc <mesaj>     → herkese OOC mesaj",
	".b <mesaj>       → yakındakilere OOC mesaj",
	".s <mesaj>       → bağırır (uzaktan duyulur)",
	".f <mesaj>       → fısıldar (sadece çok yakın)",
	".bayil [sn]      → yere yığılırsın, hareket edemezsin",
	".kalk            → bayılmışken ayağa kalkarsın",
	"Noktasız yazarsan normal konuşursun.",
}

local lastCommand = {}

local function handle(player, text)
	if typeof(text) ~= "string" then return end
	text = string.sub(text, 1, MAX_LEN)
	text = string.gsub(text, "^%s+", "")
	text = string.gsub(text, "%s+$", "")
	if text == "" then return end

	local now = os.clock()
	if lastCommand[player] and now - lastCommand[player] < COOLDOWN then return end
	lastCommand[player] = now

	local name = getName(player)
	local cmd, rest

	if string.sub(text, 1, 1) == "." then
		local c, r = string.match(text, "^%.(%S+)%s*(.*)$")
		if not c then return end
		cmd = normalize(c)
		rest = r
	else
		cmd = "say"
		rest = text
	end

	local fainted = isFainted(player)

	-- bayilmisken sadece bu komutlar calisir
	local allowedWhileFainted = {ooc = true, b = true, yardim = true, help = true, kalk = true, bayil = true}
	if fainted and not allowedWhileFainted[cmd] then
		reply(player, "Bayılmışken bunu yapamazsın. (.kalk)")
		return
	end

	if cmd == "yardim" or cmd == "help" then
		for _, line in ipairs(HELP) do reply(player, line) end

	elseif cmd == "me" then
		if rest == "" then return reply(player, "Kullanım: .me <eylem>") end
		broadcastText(player, rest, RANGE.me, COLORS.me, function(t)
			return "* " .. name .. " " .. t
		end)

	elseif cmd == "do" then
		if rest == "" then return reply(player, "Kullanım: .do <durum>") end
		broadcastText(player, rest, RANGE["do"], COLORS["do"], function(t)
			return "* " .. t .. " (( " .. name .. " ))"
		end)

	elseif cmd == "de" then
		if rest == "" then return reply(player, "Kullanım: .de <eylem>") end
		local success = math.random() < 0.5
		broadcastText(player, rest, RANGE.de, success and COLORS.de_ok or COLORS.de_fail, function(t)
			return "* " .. name .. " " .. t .. " denedi ve " .. (success and "BAŞARILI OLDU." or "BAŞARAMADI.")
		end)

	elseif cmd == "ooc" then
		if rest == "" then return reply(player, "Kullanım: .ooc <mesaj>") end
		broadcastText(player, rest, nil, COLORS.ooc, function(t)
			return "(( [OOC] " .. player.DisplayName .. ": " .. t .. " ))"
		end)

	elseif cmd == "b" then
		if rest == "" then return reply(player, "Kullanım: .b <mesaj>") end
		broadcastText(player, rest, RANGE.b, COLORS.ooc, function(t)
			return "(( " .. player.DisplayName .. ": " .. t .. " ))"
		end)

	elseif cmd == "s" or cmd == "bagir" then
		if rest == "" then return reply(player, "Kullanım: .s <mesaj>") end
		broadcastText(player, rest, RANGE.s, COLORS.shout, function(t)
			return name .. " bağırır: " .. t .. "!"
		end)

	elseif cmd == "f" or cmd == "fisilda" then
		if rest == "" then return reply(player, "Kullanım: .f <mesaj>") end
		broadcastText(player, rest, RANGE.f, COLORS.whisper, function(t)
			return name .. " fısıldar: " .. t
		end)

	elseif cmd == "bayil" then
		if fainted then
			wake(player)
		else
			local secs = tonumber(rest)
			if secs then secs = math.clamp(secs, 1, MAX_FAINT_TIME) end
			faint(player, secs)
		end

	elseif cmd == "kalk" then
		if fainted then
			wake(player)
		else
			reply(player, "Zaten ayaktasın.")
		end

	elseif cmd == "say" then
		broadcastText(player, rest, RANGE.say, COLORS.say, function(t)
			return name .. ": " .. t
		end)

	else
		reply(player, "Bilinmeyen komut. Liste için .yardim yaz.")
	end
end

remote.OnServerEvent:Connect(handle)

Players.PlayerRemoving:Connect(function(p) lastCommand[p] = nil end)
print("[RPConsoleServer] hazir")
