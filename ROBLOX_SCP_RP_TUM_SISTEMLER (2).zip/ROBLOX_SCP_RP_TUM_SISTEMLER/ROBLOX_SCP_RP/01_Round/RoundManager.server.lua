-- ServerScriptService icindeki ESKI "RoundManager" scriptinin icerigini bununla DEGISTIR.
-- Yenilikler: HUD icin durum yayinlar (ReplicatedStorage > RoundState), round'dan dogan oyunculara
-- rol anahtari atar (AdminServer etiket/can/esya verir), Cassie ile baglidir, lobide yeniden dogma.

local Players = game:GetService("Players")
local Teams = game:GetService("Teams")
local Workspace = game:GetService("Workspace")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerScriptService = game:GetService("ServerScriptService")

Players.CharacterAutoLoads = false

----------------------------------------------------------------
-- AYARLAR
----------------------------------------------------------------
local MIN_PLAYERS = 2
local INTERMISSION = 20            -- round oncesi geri sayim (sn)
local ROUND_TIME = 20 * 60         -- round suresi (sn)
local WAVE_INTERVAL = 5 * 60       -- MTF / Kaos dalga araligi (sn)
local RESULT_TIME = 10             -- sonuc ekrani suresi (sn)
local PLAYERS_PER_SCP = 6
local RESPAWN_DELAY = 3            -- lobide olen oyuncunun yeniden dogma suresi (sn)
local CLEAR_IDENTITY_ON_ROUND_END = true -- round bitince admin'in verdigi isim/boy/yetki silinsin

-- Round'dan doganlar icin varsayilan rol anahtarlari (AdminServer > ROLES ile ayni olmali)
local DEFAULT_ROLE = {
	ClassD = "d_class",
	Scientist = "bilimadami",
	Guard = "guvenlik",
	MTF = "ntf_uzman",
	Chaos = "kaos_piyade",
}

local WAVE_MTF_UNIT = "Epsilon-11, Dokuz Kuyruklu Tilki"

----------------------------------------------------------------
-- CASSIE (yoksa sessizce atlanir)
----------------------------------------------------------------
local Cassie = nil
do
	local module = ServerScriptService:WaitForChild("Cassie", 3)
	if module then
		local ok, result = pcall(require, module)
		if ok then Cassie = result else warn("[RoundManager] Cassie yuklenemedi: " .. tostring(result)) end
	end
end

local function cassie(fnName, ...)
	if Cassie and Cassie[fnName] then
		Cassie[fnName](...)
	end
end

----------------------------------------------------------------
-- HERKESE ACIK DURUM (HUD okur)
----------------------------------------------------------------
local state = ReplicatedStorage:FindFirstChild("RoundState")
if not state then
	state = Instance.new("Folder")
	state.Name = "RoundState"
	state.Parent = ReplicatedStorage
end

local function setState(values)
	for key, value in pairs(values) do
		state:SetAttribute(key, value)
	end
end

setState({
	Phase = "Lobby", TimeLeft = 0, NextWave = 0,
	PlayerCount = #Players:GetPlayers(), MinPlayers = MIN_PLAYERS,
	Result = "", Survivors = 0, Duration = 0,
})

----------------------------------------------------------------
-- TAKIMLAR
----------------------------------------------------------------
local function makeTeam(name, color)
	local t = Teams:FindFirstChild(name)
	if not t then
		t = Instance.new("Team")
		t.Name = name
		t.TeamColor = BrickColor.new(color)
		t.AutoAssignable = false
		t.Parent = Teams
	end
	return t
end

local T = {
	Lobby = makeTeam("Lobby", "Medium stone grey"),
	Spectator = makeTeam("Spectator", "Dark stone grey"),
	ClassD = makeTeam("Class-D", "Deep orange"),
	Scientist = makeTeam("Scientist", "Bright yellow"),
	Guard = makeTeam("Facility Guard", "Dark blue"),
	SCP = makeTeam("SCP", "Really red"),
	MTF = makeTeam("MTF", "Bright blue"),
	Chaos = makeTeam("Chaos Insurgency", "Black"),
}

local phase = "Lobby" -- Lobby | Intermission | Round | Ended
local roundActive = false

----------------------------------------------------------------
-- YARDIMCI FONKSIYONLAR
----------------------------------------------------------------
local function shuffle(list)
	for i = #list, 2, -1 do
		local j = math.random(i)
		list[i], list[j] = list[j], list[i]
	end
	return list
end

local function getSpawn(name)
	local folder = Workspace:FindFirstChild("Spawns")
	local spawns = {}
	if folder then
		for _, p in ipairs(folder:GetChildren()) do
			if p.Name == name then table.insert(spawns, p) end
		end
	end
	if #spawns == 0 then
		warn("[RoundManager] Spawn bulunamadi: " .. name)
		return nil
	end
	return spawns[math.random(#spawns)]
end

local function isAlive(player)
	local hum = player.Character and player.Character:FindFirstChildOfClass("Humanoid")
	return hum ~= nil and hum.Health > 0
end

local function countAlive(team)
	local n = 0
	for _, p in ipairs(Players:GetPlayers()) do
		if p.Team == team and isAlive(p) then n += 1 end
	end
	return n
end

local function countSurvivors()
	local n = 0
	for _, p in ipairs(Players:GetPlayers()) do
		if p.Team and p.Team ~= T.Lobby and p.Team ~= T.Spectator and isAlive(p) then n += 1 end
	end
	return n
end

-- Rol anahtarini ONCE yazar; AdminServer CharacterAdded'de etiket/can/esyayi uygular
local function spawnAs(player, team, spawnName, roleKey)
	player:SetAttribute("RoleKey", roleKey) -- nil = eski rol bilgisini siler
	player.Team = team
	player:LoadCharacter()

	local char = player.Character or player.CharacterAdded:Wait()
	local spawnPart = getSpawn(spawnName)
	if spawnPart then
		char:PivotTo(spawnPart.CFrame + Vector3.new(0, 4, 0))
	end
end

----------------------------------------------------------------
-- OYUNCU GIRIS / OLUM
----------------------------------------------------------------
local function hookDeath(player, char)
	local hum = char:WaitForChild("Humanoid", 10)
	if not hum then return end

	hum.Died:Connect(function()
		if roundActive then
			if player.Team ~= T.Lobby then
				player.Team = T.Spectator
			end
		elseif phase == "Lobby" or phase == "Intermission" then
			-- lobide olen oyuncu yeniden dogar
			task.delay(RESPAWN_DELAY, function()
				if player.Parent == Players and (phase == "Lobby" or phase == "Intermission") then
					player:LoadCharacter()
				end
			end)
		end
	end)
end

local function onPlayer(player)
	player.CharacterAdded:Connect(function(char) hookDeath(player, char) end)

	if not player.Character then
		if roundActive then
			player.Team = T.Spectator -- round'a sonradan girenler izleyici
		else
			player.Team = T.Lobby
			task.spawn(function() player:LoadCharacter() end)
		end
	end
end

Players.PlayerAdded:Connect(onPlayer)
for _, p in ipairs(Players:GetPlayers()) do onPlayer(p) end

----------------------------------------------------------------
-- ROL DAGITIMI
----------------------------------------------------------------
local function assignRoles()
	local list = shuffle(Players:GetPlayers())
	local total = #list
	local scpCount = math.max(1, math.floor(total / PLAYERS_PER_SCP))
	local scientistCount = math.max(1, math.floor(total * 0.15))
	local guardCount = math.max(1, math.floor(total * 0.15))

	for i, player in ipairs(list) do
		if i <= scpCount then
			spawnAs(player, T.SCP, "SCP", nil)
		elseif i <= scpCount + scientistCount then
			spawnAs(player, T.Scientist, "Scientist", DEFAULT_ROLE.Scientist)
		elseif i <= scpCount + scientistCount + guardCount then
			spawnAs(player, T.Guard, "Guard", DEFAULT_ROLE.Guard)
		else
			spawnAs(player, T.ClassD, "ClassD", DEFAULT_ROLE.ClassD)
		end
	end
end

----------------------------------------------------------------
-- RESPAWN DALGASI (MTF / Kaos)
----------------------------------------------------------------
local function spawnWave()
	local spectators = {}
	for _, p in ipairs(Players:GetPlayers()) do
		if p.Team == T.Spectator then table.insert(spectators, p) end
	end
	if #spectators == 0 then return end

	local isChaos = math.random() < 0.4
	local team = isChaos and T.Chaos or T.MTF
	local spawnName = isChaos and "Chaos" or "MTF"
	local roleKey = isChaos and DEFAULT_ROLE.Chaos or DEFAULT_ROLE.MTF

	for _, p in ipairs(spectators) do
		spawnAs(p, team, spawnName, roleKey)
	end

	-- Kaos girisini CassieEvents kendisi duyurur; MTF icin burada duyuruyoruz
	if not isChaos then
		cassie("MTFArrival", WAVE_MTF_UNIT, countAlive(T.SCP))
	end
end

----------------------------------------------------------------
-- KAZANMA SARTI
----------------------------------------------------------------
local function evaluate()
	local scp = countAlive(T.SCP)
	local foundation = countAlive(T.Scientist) + countAlive(T.Guard) + countAlive(T.MTF)
	local chaos = countAlive(T.Chaos) + countAlive(T.ClassD)

	if foundation == 0 and chaos == 0 and scp == 0 then return "Draw" end
	if scp == 0 and chaos == 0 then return "Foundation" end
	if foundation == 0 and scp == 0 then return "Chaos" end
	if foundation == 0 and chaos == 0 then return "SCP" end
	return nil
end

----------------------------------------------------------------
-- ROUND
----------------------------------------------------------------
local IDENTITY_ATTRIBUTES = {"RPName", "RPLevel", "RoleIcon", "BoyScale", "RoleKey", "RoleName", "RoleLevel"}

local function returnToLobby()
	for _, p in ipairs(Players:GetPlayers()) do
		if CLEAR_IDENTITY_ON_ROUND_END then
			for _, attr in ipairs(IDENTITY_ATTRIBUTES) do
				p:SetAttribute(attr, nil)
			end
		else
			p:SetAttribute("RoleKey", nil)
		end
		p.Team = T.Lobby
		task.spawn(function() p:LoadCharacter() end)
	end
end

local function runRound()
	roundActive = true
	phase = "Round"

	local timeLeft = ROUND_TIME
	local nextWave = WAVE_INTERVAL
	setState({TimeLeft = timeLeft, NextWave = nextWave, Result = "", Survivors = 0, Duration = 0})
	setState({Phase = "Round"})

	assignRoles()
	cassie("RoundStart")

	local result
	while timeLeft > 0 and not result do
		task.wait(1)
		timeLeft -= 1
		nextWave -= 1
		if nextWave <= 0 then
			spawnWave()
			nextWave = WAVE_INTERVAL
		end
		setState({TimeLeft = timeLeft, NextWave = nextWave, PlayerCount = #Players:GetPlayers()})
		result = evaluate()
	end

	result = result or "Timeout"
	roundActive = false
	phase = "Ended"
	-- Once sonuc bilgileri, sonra Phase (HUD Phase degisince hepsini okur)
	setState({Result = result, Survivors = countSurvivors(), Duration = ROUND_TIME - timeLeft})
	setState({Phase = "Ended"})
	print("[RoundManager] Round bitti: " .. result)

	task.wait(RESULT_TIME)
	returnToLobby()
	phase = "Lobby"
end

----------------------------------------------------------------
-- ANA DONGU
----------------------------------------------------------------
while true do
	phase = "Lobby"
	setState({Phase = "Lobby", TimeLeft = 0, NextWave = 0})

	while #Players:GetPlayers() < MIN_PLAYERS do
		setState({PlayerCount = #Players:GetPlayers()})
		task.wait(1)
	end

	phase = "Intermission"
	local ready = true
	for t = INTERMISSION, 1, -1 do
		setState({Phase = "Intermission", TimeLeft = t, PlayerCount = #Players:GetPlayers()})
		task.wait(1)
		if #Players:GetPlayers() < MIN_PLAYERS then
			ready = false -- oyuncu sayisi dustu, lobiye don
			break
		end
	end

	if ready then
		runRound()
	end
end
