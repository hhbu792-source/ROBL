# CLAUDE.md — Roblox SCP:SL Tarzı RP Oyunu

Bu dosya projenin tam bağlamını ve **tüm script kodlarını** içerir. Yeni bir sohbete veya Claude Code'a bu dosyayı verirsen proje nerede kaldığını bilir.

## Proje özeti

- **Oyun:** Roblox'ta SCP: Secret Laboratory tarzı (breach odaklı, round tabanlı) bir RP oyunu.
- **Dil:** Luau. Kullanıcı Türkçe yazar (hızlı, kısa, bazen yazım hatalı), cevaplar Türkçe, kısa ve adım adım olmalı.
- **Yapılanlar:** Round sistemi (HUD'a durum yayınlar), admin paneli ve 13 rol, oyuncular için RP konsolu, CASSIE anons sistemi (otomatik olay duyuruları dahil), HUD / rol ekranı / sonuç ekranı.
- **Sıradaki işler:** Özel eşya çubuğu (hotbar), kart ve kapı sistemi, SCP'ler, Warhead / dekontaminasyon.

## Dosya yapısı (Studio'da nereye konur)

| Script | Tür | Konum |
|---|---|---|
| `RoundManager` | Script | `ServerScriptService` |
| `AdminServer` | Script | `ServerScriptService` |
| `AdminPanelClient` | LocalScript | `StarterPlayer > StarterPlayerScripts` |
| `RPConsoleServer` | Script | `ServerScriptService` |
| `RPConsoleClient` | LocalScript | `StarterPlayer > StarterPlayerScripts` |
| `CassieConfig` | **ModuleScript** | **`ReplicatedStorage`** |
| `Cassie` | **ModuleScript** | `ServerScriptService` |
| `CassieInit` | Script | `ServerScriptService` |
| `CassieEvents` | Script | `ServerScriptService` |
| `CassieClient` | LocalScript | `StarterPlayer > StarterPlayerScripts` |
| `HudClient` | LocalScript | `StarterPlayer > StarterPlayerScripts` |

Ek hazırlıklar:
- `Workspace > Spawns`: `ClassD`, `Scientist`, `Guard`, `SCP`, `MTF`, `Chaos`, `GOC`, `GOI`, `SerpentsHand` adlı Part'lar (birden fazla olabilir).
- Lobi için bir `SpawnLocation`.
- `ServerStorage > Tools` (isteğe bağlı): `Keycard2..5`, `Pistol`, `Rifle`.
- `Workspace > Zones` (isteğe bağlı): CASSIE'nin bölge adı söylemesi için büyük görünmez Part'lar.
- Eski `AdminRoleSystem` script'i silinmiş olmalı.

## Sistemler

### 1. Round sistemi (`RoundManager`)
- `CharacterAutoLoads = false`: karakterleri script spawn eder. Sonradan giren lobide doğar (round sırasında girerse izleyici olur). Lobide ölen 3 sn sonra yeniden doğar.
- Akış: Lobby → Intermission (geri sayım) → Round → Ended (sonuç ekranı) → Lobby. Oyuncu sayısı geri sayımda düşerse lobiye döner.
- Roller: her 6 oyuncuya 1 SCP, %15 Bilim Adamı, %15 Güvenlik, kalanı D-Class. Doğan oyuncuya **rol anahtarı** (`RoleKey`) yazılır; `AdminServer` can/hız/eşya/etiketi uygular. SCP'de rol anahtarı yoktur.
- Ölen oyuncu `Spectator`. 5 dakikada bir MTF (%60, `ntf_uzman`) veya Kaos (%40, `kaos_piyade`) dalgası izleyicileri geri getirir.
- Kazanma: SCP / Vakıf (Bilim+Güvenlik+MTF) / Kaos (Kaos+D-Class) / beraberlik / süre doldu.
- Durumu `ReplicatedStorage > RoundState` klasörünün attribute'larına yazar (HUD okur).
- Round bitince admin'in verdiği isim/boy/yetki silinir (`CLEAR_IDENTITY_ON_ROUND_END`).
- `Cassie` varsa round başında ve MTF dalgasında anons yapar (yoksa sessizce atlar).

### 2. Admin paneli ve roller (`AdminServer` + `AdminPanelClient`)
- Panel **M** tuşuyla açılır, sadece adminlerde. Admin: `ADMINS` listesi (UserId); yayınlanmış oyunda sahip ve grup rütbesi 255 de admin. **Yayınlanmamış oyunda sahip kimliği 0'dır; UserId'ni listeye yaz.**
- Panelde: oyuncu seç, rol seç (seçmezsen rol değişmez), İsim/Unvan, Yetki Seviyesi, Boy (0.5–2), Rol Simgesi, Uygula, Sıfırla.
- Rol verilince: izleyiciden çıkar, rolün takımına geçer, rolün spawn noktasında doğar, can/hız/eşya alır.
- Kafa üstü etiket: rol simgesi, admin'in verdiği isim, altında yetki seviyesi.
- İsim formatı: `Unvan|İsim` (ör. `Tesis Komutanı|Liewex`); `|` okunurken boşluğa çevrilir.
- Boy sadece **R15**.

### 3. RP konsolu (`RPConsoleServer` + `RPConsoleClient`)
- **I / İ** tuşuyla (yedek **T**) yazma kutusu açılır. Enter gönderir.
- Komutlar: `.me`, `.do`, `.de` (dene: %50), `.ooc`, `.b`, `.s`, `.f`, `.bayil [sn]`, `.kalk`, `.yardim`; noktasız yazı normal konuşma.
- `.bayil`: sırtüstü düz yatar, `Anchored`, hız/zıplama sıfır, eşya cebe girer. Bayılmışken sadece `.ooc .b .kalk .yardim`.
- Oyuncu metinleri `TextService` filtresinden geçer. Türkçe karakterler komut eşleşmesinde sadeleştirilir.

### 4. CASSIE (`CassieConfig`, `Cassie`, `CassieInit`, `CassieEvents`, `CassieClient`)
- `Cassie` modülü: kuyruklu anons sistemi (öncelik: bilgi < uyarı < acil). `Cassie.Announce(text, {kind, priority})` ve hazır anonslar: `RoundStart`, `MTFArrival`, `ChaosAlert`, `Breach`, `SCPContained`, `SCPTerminated`, `DecontWarning`, `DecontStart`, `WarheadStart/Cancel/Detonated`, `VIPDead`, `ArmedDClass`.
- Ekran: üst ortada (HUD kutusunun altında) kayarak inen banner, kelime kelime yazılır. Zil ve kelime sesleri `CassieConfig`'te (`BELL_ID`, `WORD_SOUNDS`); sesler yoksa sadece yazı.
- `CassieInit`: admin sohbet komutları `/cassie`, `/cassieuyari`, `/cassiekritik`, `/cassietest`.
- `CassieEvents` otomatik duyurular (ayarlar `CassieConfig > Config.EVENTS`):
  1. **Önemli kişi ölümü**: unvan listede (Tesis Komutanı, Tesis Yöneticisi, …) veya yetki seviyesi ≥ 6 ise "… ölü bulundu" (ölümden 4 sn sonra).
  2. **Kaos / GOC girişi**: takım adıyla, 90 sn bekleme.
  3. **Rütbeli girişi** (minimum NTF Çavuşu: `ntf_cavus`, `ntf_albay`): admin'in verdiği isimle, büyük harf: "DİKKAT DİKKAT. TESİS TEĞMENİ LİEWEX TESİSE GİRİŞ YAPMIŞTIR. BİLGİNİZE."
  4. **Silahlı D-Class**: Bilim Adamı / Güvenlik / MTF görünce (mesafe, görüş açısı, engel kontrolüyle) duyurulur; `Workspace > Zones` varsa bölge adı da söylenir.

### 5. HUD (`HudClient`)
- Üst orta: round durumu + sayaç + sonraki dalga süresi. Sağ alt: kart seviyesi (5 çubuk) ve can. İzleyici bilgisi. Doğunca 5 sn **rol ekranı** ("Sen NTF Çavuşu'sun" + isim + yetki + hedef cümlesi; Türkçe ek otomatik). Round sonu **sonuç ekranı** (kazanan, hayatta kalan, süre, "HAYATTA KALDIN / ÖLDÜN").
- Kart seviyesi `Keycard1..5` adlı Tool'lardan (veya `KeycardLevel` attribute'u).
- Roblox'un varsayılan can çubuğu ve **çanta (eşya çubuğu) kapatılır** (`HIDE_ROBLOX_BACKPACK`).

## Roller ve hiyerarşi

| Anahtar | Ad | Takım | Spawn | Varsayılan yetki |
|---|---|---|---|---|
| `d_class` | D-Class | Class-D | ClassD | 0. Seviye Personel |
| `bilimadami` | Bilim Adamı | Scientist | Scientist | 2. Seviye Personel |
| `guvenlik` | Güvenlik Personeli | Facility Guard | Guard | 2. Seviye Personel |
| `ntf_uzman` | NTF Uzmanı | MTF | MTF | 3. Seviye Personel |
| `ntf_cavus` | NTF Çavuşu | MTF | MTF | 4. Seviye Personel |
| `ntf_albay` | NTF Albayı | MTF | MTF | 5. Seviye Personel |
| `kaos_acemi` | Kaos İsyancıları Acemisi | Chaos Insurgency | Chaos | 2. Seviye Personel |
| `kaos_piyade` | Kaos İsyancıları Piyadesi | Chaos Insurgency | Chaos | 3. Seviye Personel |
| `kaos_akinci` | Kaos İsyancıları Akıncısı | Chaos Insurgency | Chaos | 4. Seviye Personel |
| `kaos_komutan` | Kaos İsyancıları Komutanı | Chaos Insurgency | Chaos | 5. Seviye Personel |
| `goc` | GOC | GOC | GOC | 4. Seviye Personel |
| `goi` | GOI | GOI | GOI | 3. Seviye Personel |
| `yilanin_eli` | Yılanın Eli | Serpent's Hand | SerpentsHand | 3. Seviye Personel |

Hiyerarşi (alttan üste): D-Class → Bilim Adamı → Güvenlik; NTF Uzmanı → NTF Çavuşu → NTF Albayı; Kaos Acemi → Piyade → Akıncı → Komutan. Kullanıcı bunu **sonra değiştirecek**; roller `AdminServer > ROLES`, CASSIE'nin duyuracağı rütbeler `CassieConfig > RANK_ARRIVALS.roles`. Tesis Teğmeni / Tesis Komutanı gibi unvanlar rol değil, panelde verilen **isimdir**. Rol simgeleri henüz yapılmadı (`icon = ""`).

## Script'ler arası API

**ReplicatedStorage**
- `AdminRemotes/AdminAction`, `AdminRemotes/GetRoles` (RemoteFunction): panel istekleri; server her istekte admin kontrolü yapar.
- `RPRemotes/RPConsole` (RemoteEvent): komut metni (client→server), `(metin, Color3)` (server→client).
- `CassieAnnounce` (RemoteEvent): `(metin, tür)` server→client.
- `RoundState` (Folder) attribute'ları: `Phase` (Lobby / Intermission / Round / Ended), `TimeLeft`, `NextWave`, `PlayerCount`, `MinPlayers`, `Result` (Foundation / SCP / Chaos / Timeout / Draw), `Survivors`, `Duration`.
- `CassieConfig` (ModuleScript): ayarlar ve `Config.Schedule` (server ve client aynı zamanlamayı kullanır).

**Player attribute'ları:** `IsAdmin`, `RPName`, `RPLevel`, `RoleIcon`, `RoleKey`, `RoleName`, `RoleLevel`, `BoyScale`, `Fainted`.

**Modül / global:** `require(ServerScriptService.Cassie)`; `_G.SetRole(player, roleKey)` ve `_G.SCPRoles` (AdminServer tanımlar).

## Bilinen sorunlar

1. **I / İ tuşu**: Roblox Türkçe klavyede ı/İ tuşlarını `Unknown`/`Quote` olarak bildirebiliyor. `RPConsoleClient`'ta `DEBUG = true` ekranda son tuşu gösterir; T yedek tuş. Kesin sonuç kullanıcıdan bekleniyor; çözülünce `DEBUG = false`.
2. **Çanta kapalı → eşya alınamıyor** (1-2-3 tuşları). Özel eşya çubuğu yazılana kadar `HIDE_ROBLOX_BACKPACK = false` yapılabilir. `.bayil` ve silahlı D-Class tespiti elde tutulan silaha bağlı.
3. "Ölü bulundu" şu an **ölüm anında** (4 sn gecikmeyle) duyuruluyor; cesedin bulunması için ceset sistemi gerekir.
4. `.bayil`'da sunucu client animasyonlarını durduramaz; hafif animasyon kalıntısı olabilir.
5. Rol simgeleri ve CASSIE kelime sesleri yok (yer tutucu). Büyük harfli anonslarda kelime sesi eşleşmesi için `Config.Normalize` Türkçe büyük harfe göre güncellenmeli.
6. GOC / GOI / Yılanın Eli round dengesinde sayılmıyor; GOI ve Yılanın Eli hedef cümleleri yer tutucu.
7. Kod Studio'da uçtan uca test edilmedi; sözdizimi (blok dengesi) kontrol edildi. Hata olursa Output'taki satırları iste.

## Yapılacaklar

- [ ] Özel eşya çubuğu (hotbar): 1-5 tuşları, ikonlar, ad etiketleri
- [ ] Kart sistemi ve kapılar (Seviye 1–5, `ProximityPrompt`)
- [ ] SCP-173 (bakınca donar, boyun kırar) ve diğer SCP'ler (049, 096, 106 …)
- [ ] Silahlar (server-authoritative hasar)
- [ ] Warhead, dekontaminasyon, alarm olayları + CASSIE bağlantısı
- [ ] Rol simgeleri, CASSIE sesleri
- [ ] Ceset sistemi ("ölü bulundu" gerçek keşifte)
- [ ] I / İ tuşu sorununun kesin çözümü

## Claude için çalışma kuralları

- Cevaplar **Türkçe**, kısa ve adım adım. Kod değişince dosyanın tamamını ver ve Studio'da hangi script'in içeriğinin değişeceğini söyle.
- Kullanıcı hızlı ve kısa yazar, yazım hataları olur; niyeti anlamaya çalış, emin değilsen tek kısa soru sor.
- Server tarafı **her remote isteğinde** yetki kontrolü yapar; client'a güvenme.
- Başkalarına gösterilen her oyuncu/admin metni `TextService:FilterStringAsync` ile filtrelenir.
- Script'ler arası haberleşme için ModuleScript / event tercih et (yeni kodda `_G` kullanma).
- Browser storage Roblox'ta yok; kalıcı veri için `DataStoreService`.
- Boy/ölçek kodları R15 varsayar.
- Kullanıcıdan sorun gelirse `View > Output` çıktısını ve hangi script'in hangi türde/yerde olduğunu sor.

---

# EK: TÜM KOD

Her bölüm bir script'in tam içeriğidir. Başlıktaki ad = Studio'daki script adı.

## RoundManager

*Script — ServerScriptService*

```lua
-- ServerScriptService icindeki ESKI "RoundManager" scriptinin icerigini bununla DEGISTIR.
-- Yenilikler: HUD icin durum yayinlar (ReplicatedStorage > RoundState), round'dan dogan oyunculara
-- rol anahtari atar (AdminServer etiket/can/esya verir), Cassie ile baglidir, lobide yeniden dogma.

local Players = game:GetService("Players")
local Teams = game:GetService("Teams")
local Workspace = game:GetService("Workspace")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerScriptService = game:GetService("ServerScriptService")

Players.CharacterAutoLoads = false

----------------------------------------------------------------
-- AYARLAR
----------------------------------------------------------------
local MIN_PLAYERS = 2
local INTERMISSION = 20            -- round oncesi geri sayim (sn)
local ROUND_TIME = 20 * 60         -- round suresi (sn)
local WAVE_INTERVAL = 5 * 60       -- MTF / Kaos dalga araligi (sn)
local RESULT_TIME = 10             -- sonuc ekrani suresi (sn)
local PLAYERS_PER_SCP = 6
local RESPAWN_DELAY = 3            -- lobide olen oyuncunun yeniden dogma suresi (sn)
local CLEAR_IDENTITY_ON_ROUND_END = true -- round bitince admin'in verdigi isim/boy/yetki silinsin

-- Round'dan doganlar icin varsayilan rol anahtarlari (AdminServer > ROLES ile ayni olmali)
local DEFAULT_ROLE = {
	ClassD = "d_class",
	Scientist = "bilimadami",
	Guard = "guvenlik",
	MTF = "ntf_uzman",
	Chaos = "kaos_piyade",
}

local WAVE_MTF_UNIT = "Epsilon-11, Dokuz Kuyruklu Tilki"

----------------------------------------------------------------
-- CASSIE (yoksa sessizce atlanir)
----------------------------------------------------------------
local Cassie = nil
do
	local module = ServerScriptService:WaitForChild("Cassie", 3)
	if module then
		local ok, result = pcall(require, module)
		if ok then Cassie = result else warn("[RoundManager] Cassie yuklenemedi: " .. tostring(result)) end
	end
end

local function cassie(fnName, ...)
	if Cassie and Cassie[fnName] then
		Cassie[fnName](...)
	end
end

----------------------------------------------------------------
-- HERKESE ACIK DURUM (HUD okur)
----------------------------------------------------------------
local state = ReplicatedStorage:FindFirstChild("RoundState")
if not state then
	state = Instance.new("Folder")
	state.Name = "RoundState"
	state.Parent = ReplicatedStorage
end

local function setState(values)
	for key, value in pairs(values) do
		state:SetAttribute(key, value)
	end
end

setState({
	Phase = "Lobby", TimeLeft = 0, NextWave = 0,
	PlayerCount = #Players:GetPlayers(), MinPlayers = MIN_PLAYERS,
	Result = "", Survivors = 0, Duration = 0,
})

----------------------------------------------------------------
-- TAKIMLAR
----------------------------------------------------------------
local function makeTeam(name, color)
	local t = Teams:FindFirstChild(name)
	if not t then
		t = Instance.new("Team")
		t.Name = name
		t.TeamColor = BrickColor.new(color)
		t.AutoAssignable = false
		t.Parent = Teams
	end
	return t
end

local T = {
	Lobby = makeTeam("Lobby", "Medium stone grey"),
	Spectator = makeTeam("Spectator", "Dark stone grey"),
	ClassD = makeTeam("Class-D", "Deep orange"),
	Scientist = makeTeam("Scientist", "Bright yellow"),
	Guard = makeTeam("Facility Guard", "Dark blue"),
	SCP = makeTeam("SCP", "Really red"),
	MTF = makeTeam("MTF", "Bright blue"),
	Chaos = makeTeam("Chaos Insurgency", "Black"),
}

local phase = "Lobby" -- Lobby | Intermission | Round | Ended
local roundActive = false

----------------------------------------------------------------
-- YARDIMCI FONKSIYONLAR
----------------------------------------------------------------
local function shuffle(list)
	for i = #list, 2, -1 do
		local j = math.random(i)
		list[i], list[j] = list[j], list[i]
	end
	return list
end

local function getSpawn(name)
	local folder = Workspace:FindFirstChild("Spawns")
	local spawns = {}
	if folder then
		for _, p in ipairs(folder:GetChildren()) do
			if p.Name == name then table.insert(spawns, p) end
		end
	end
	if #spawns == 0 then
		warn("[RoundManager] Spawn bulunamadi: " .. name)
		return nil
	end
	return spawns[math.random(#spawns)]
end

local function isAlive(player)
	local hum = player.Character and player.Character:FindFirstChildOfClass("Humanoid")
	return hum ~= nil and hum.Health > 0
end

local function countAlive(team)
	local n = 0
	for _, p in ipairs(Players:GetPlayers()) do
		if p.Team == team and isAlive(p) then n += 1 end
	end
	return n
end

local function countSurvivors()
	local n = 0
	for _, p in ipairs(Players:GetPlayers()) do
		if p.Team and p.Team ~= T.Lobby and p.Team ~= T.Spectator and isAlive(p) then n += 1 end
	end
	return n
end

-- Rol anahtarini ONCE yazar; AdminServer CharacterAdded'de etiket/can/esyayi uygular
local function spawnAs(player, team, spawnName, roleKey)
	player:SetAttribute("RoleKey", roleKey) -- nil = eski rol bilgisini siler
	player.Team = team
	player:LoadCharacter()

	local char = player.Character or player.CharacterAdded:Wait()
	local spawnPart = getSpawn(spawnName)
	if spawnPart then
		char:PivotTo(spawnPart.CFrame + Vector3.new(0, 4, 0))
	end
end

----------------------------------------------------------------
-- OYUNCU GIRIS / OLUM
----------------------------------------------------------------
local function hookDeath(player, char)
	local hum = char:WaitForChild("Humanoid", 10)
	if not hum then return end

	hum.Died:Connect(function()
		if roundActive then
			if player.Team ~= T.Lobby then
				player.Team = T.Spectator
			end
		elseif phase == "Lobby" or phase == "Intermission" then
			-- lobide olen oyuncu yeniden dogar
			task.delay(RESPAWN_DELAY, function()
				if player.Parent == Players and (phase == "Lobby" or phase == "Intermission") then
					player:LoadCharacter()
				end
			end)
		end
	end)
end

local function onPlayer(player)
	player.CharacterAdded:Connect(function(char) hookDeath(player, char) end)

	if not player.Character then
		if roundActive then
			player.Team = T.Spectator -- round'a sonradan girenler izleyici
		else
			player.Team = T.Lobby
			task.spawn(function() player:LoadCharacter() end)
		end
	end
end

Players.PlayerAdded:Connect(onPlayer)
for _, p in ipairs(Players:GetPlayers()) do onPlayer(p) end

----------------------------------------------------------------
-- ROL DAGITIMI
----------------------------------------------------------------
local function assignRoles()
	local list = shuffle(Players:GetPlayers())
	local total = #list
	local scpCount = math.max(1, math.floor(total / PLAYERS_PER_SCP))
	local scientistCount = math.max(1, math.floor(total * 0.15))
	local guardCount = math.max(1, math.floor(total * 0.15))

	for i, player in ipairs(list) do
		if i <= scpCount then
			spawnAs(player, T.SCP, "SCP", nil)
		elseif i <= scpCount + scientistCount then
			spawnAs(player, T.Scientist, "Scientist", DEFAULT_ROLE.Scientist)
		elseif i <= scpCount + scientistCount + guardCount then
			spawnAs(player, T.Guard, "Guard", DEFAULT_ROLE.Guard)
		else
			spawnAs(player, T.ClassD, "ClassD", DEFAULT_ROLE.ClassD)
		end
	end
end

----------------------------------------------------------------
-- RESPAWN DALGASI (MTF / Kaos)
----------------------------------------------------------------
local function spawnWave()
	local spectators = {}
	for _, p in ipairs(Players:GetPlayers()) do
		if p.Team == T.Spectator then table.insert(spectators, p) end
	end
	if #spectators == 0 then return end

	local isChaos = math.random() < 0.4
	local team = isChaos and T.Chaos or T.MTF
	local spawnName = isChaos and "Chaos" or "MTF"
	local roleKey = isChaos and DEFAULT_ROLE.Chaos or DEFAULT_ROLE.MTF

	for _, p in ipairs(spectators) do
		spawnAs(p, team, spawnName, roleKey)
	end

	-- Kaos girisini CassieEvents kendisi duyurur; MTF icin burada duyuruyoruz
	if not isChaos then
		cassie("MTFArrival", WAVE_MTF_UNIT, countAlive(T.SCP))
	end
end

----------------------------------------------------------------
-- KAZANMA SARTI
----------------------------------------------------------------
local function evaluate()
	local scp = countAlive(T.SCP)
	local foundation = countAlive(T.Scientist) + countAlive(T.Guard) + countAlive(T.MTF)
	local chaos = countAlive(T.Chaos) + countAlive(T.ClassD)

	if foundation == 0 and chaos == 0 and scp == 0 then return "Draw" end
	if scp == 0 and chaos == 0 then return "Foundation" end
	if foundation == 0 and scp == 0 then return "Chaos" end
	if foundation == 0 and chaos == 0 then return "SCP" end
	return nil
end

----------------------------------------------------------------
-- ROUND
----------------------------------------------------------------
local IDENTITY_ATTRIBUTES = {"RPName", "RPLevel", "RoleIcon", "BoyScale", "RoleKey", "RoleName", "RoleLevel"}

local function returnToLobby()
	for _, p in ipairs(Players:GetPlayers()) do
		if CLEAR_IDENTITY_ON_ROUND_END then
			for _, attr in ipairs(IDENTITY_ATTRIBUTES) do
				p:SetAttribute(attr, nil)
			end
		else
			p:SetAttribute("RoleKey", nil)
		end
		p.Team = T.Lobby
		task.spawn(function() p:LoadCharacter() end)
	end
end

local function runRound()
	roundActive = true
	phase = "Round"

	local timeLeft = ROUND_TIME
	local nextWave = WAVE_INTERVAL
	setState({TimeLeft = timeLeft, NextWave = nextWave, Result = "", Survivors = 0, Duration = 0})
	setState({Phase = "Round"})

	assignRoles()
	cassie("RoundStart")

	local result
	while timeLeft > 0 and not result do
		task.wait(1)
		timeLeft -= 1
		nextWave -= 1
		if nextWave <= 0 then
			spawnWave()
			nextWave = WAVE_INTERVAL
		end
		setState({TimeLeft = timeLeft, NextWave = nextWave, PlayerCount = #Players:GetPlayers()})
		result = evaluate()
	end

	result = result or "Timeout"
	roundActive = false
	phase = "Ended"
	-- Once sonuc bilgileri, sonra Phase (HUD Phase degisince hepsini okur)
	setState({Result = result, Survivors = countSurvivors(), Duration = ROUND_TIME - timeLeft})
	setState({Phase = "Ended"})
	print("[RoundManager] Round bitti: " .. result)

	task.wait(RESULT_TIME)
	returnToLobby()
	phase = "Lobby"
end

----------------------------------------------------------------
-- ANA DONGU
----------------------------------------------------------------
while true do
	phase = "Lobby"
	setState({Phase = "Lobby", TimeLeft = 0, NextWave = 0})

	while #Players:GetPlayers() < MIN_PLAYERS do
		setState({PlayerCount = #Players:GetPlayers()})
		task.wait(1)
	end

	phase = "Intermission"
	local ready = true
	for t = INTERMISSION, 1, -1 do
		setState({Phase = "Intermission", TimeLeft = t, PlayerCount = #Players:GetPlayers()})
		task.wait(1)
		if #Players:GetPlayers() < MIN_PLAYERS then
			ready = false -- oyuncu sayisi dustu, lobiye don
			break
		end
	end

	if ready then
		runRound()
	end
end
```

## AdminServer

*Script — ServerScriptService*

```lua
-- ServerScriptService icine "AdminServer" adiyla normal SCRIPT olarak koy.
-- Eski "AdminRoleSystem" scriptini SIL (yerine bu geciyor).

local Players = game:GetService("Players")
local Teams = game:GetService("Teams")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")

----------------------------------------------------------------
-- AYARLAR
----------------------------------------------------------------
local ADMINS = {
	-- 123456789, -- admin UserId'lerini buraya yaz (oyun sahibi otomatik admin)
}
local MIN_BOY, MAX_BOY = 0.5, 2

----------------------------------------------------------------
-- ROLLER
-- icon: rol simgesi (henuz yapilmadi, hazir olunca "rbxassetid://123" yaz)
-- level: admin bos birakirsa gorunecek varsayilan yetki seviyesi
----------------------------------------------------------------
local ROLE_ORDER = {
	"d_class", "bilimadami", "guvenlik",
	"ntf_uzman", "ntf_cavus", "ntf_albay",
	"kaos_acemi", "kaos_piyade", "kaos_akinci", "kaos_komutan",
	"goc", "goi", "yilanin_eli",
}

local ROLES = {
	d_class      = {name = "D-Class",                   team = "Class-D",          color = "Deep orange", health = 100, speed = 16, spawn = "ClassD",       level = "0. Seviye Personel", icon = "", tools = {}},
	bilimadami   = {name = "Bilim Adamı",               team = "Scientist",        color = "Bright yellow", health = 100, speed = 16, spawn = "Scientist",  level = "2. Seviye Personel", icon = "", tools = {"Keycard2"}},
	guvenlik     = {name = "Güvenlik Personeli",        team = "Facility Guard",   color = "Dark blue",   health = 120, speed = 16, spawn = "Guard",        level = "2. Seviye Personel", icon = "", tools = {"Keycard2", "Pistol"}},
	ntf_uzman    = {name = "NTF Uzmanı",                team = "MTF",              color = "Bright blue", health = 130, speed = 17, spawn = "MTF",          level = "3. Seviye Personel", icon = "", tools = {"Keycard3", "Rifle"}},
	ntf_cavus    = {name = "NTF Çavuşu",                team = "MTF",              color = "Bright blue", health = 140, speed = 17, spawn = "MTF",          level = "4. Seviye Personel", icon = "", tools = {"Keycard4", "Rifle"}},
	ntf_albay    = {name = "NTF Albayı",                team = "MTF",              color = "Bright blue", health = 160, speed = 17, spawn = "MTF",          level = "5. Seviye Personel", icon = "", tools = {"Keycard5", "Rifle"}},
	kaos_acemi   = {name = "Kaos İsyancıları Acemisi",  team = "Chaos Insurgency", color = "Black",       health = 110, speed = 16, spawn = "Chaos",        level = "2. Seviye Personel", icon = "", tools = {"Keycard2", "Pistol"}},
	kaos_piyade  = {name = "Kaos İsyancıları Piyadesi", team = "Chaos Insurgency", color = "Black",       health = 130, speed = 17, spawn = "Chaos",        level = "3. Seviye Personel", icon = "", tools = {"Keycard3", "Rifle"}},
	kaos_akinci  = {name = "Kaos İsyancıları Akıncısı", team = "Chaos Insurgency", color = "Black",       health = 140, speed = 18, spawn = "Chaos",        level = "4. Seviye Personel", icon = "", tools = {"Keycard4", "Rifle"}},
	kaos_komutan = {name = "Kaos İsyancıları Komutanı", team = "Chaos Insurgency", color = "Black",       health = 170, speed = 17, spawn = "Chaos",        level = "5. Seviye Personel", icon = "", tools = {"Keycard5", "Rifle"}},
	goc          = {name = "GOC",                       team = "GOC",              color = "Navy blue",   health = 150, speed = 17, spawn = "GOC",          level = "4. Seviye Personel", icon = "", tools = {"Keycard4", "Rifle"}},
	goi          = {name = "GOI",                       team = "GOI",              color = "Dark green",  health = 120, speed = 16, spawn = "GOI",          level = "3. Seviye Personel", icon = "", tools = {"Keycard3", "Pistol"}},
	yilanin_eli  = {name = "Yılanın Eli",               team = "Serpent's Hand",   color = "Camo",        health = 130, speed = 17, spawn = "SerpentsHand", level = "3. Seviye Personel", icon = "", tools = {"Keycard3", "Pistol"}},
}

----------------------------------------------------------------
-- REMOTE'LAR
----------------------------------------------------------------
local remotes = Instance.new("Folder")
remotes.Name = "AdminRemotes"
remotes.Parent = ReplicatedStorage

local actionRF = Instance.new("RemoteFunction")
actionRF.Name = "AdminAction"
actionRF.Parent = remotes

local rolesRF = Instance.new("RemoteFunction")
rolesRF.Name = "GetRoles"
rolesRF.Parent = remotes

----------------------------------------------------------------
-- YARDIMCI FONKSIYONLAR
----------------------------------------------------------------
local function isAdmin(player)
	if player.UserId == game.CreatorId then return true end
	if game.CreatorType == Enum.CreatorType.Group then
		local ok, rank = pcall(function() return player:GetRankInGroup(game.CreatorId) end)
		if ok and rank >= 255 then return true end
	end
	return table.find(ADMINS, player.UserId) ~= nil
end

local function clean(text, maxLen)
	if typeof(text) ~= "string" then return nil end
	text = string.gsub(text, "^%s+", "")
	text = string.gsub(text, "%s+$", "")
	if text == "" then return nil end
	return string.sub(text, 1, maxLen)
end

local function normalizeIcon(text)
	text = clean(text, 60)
	if not text then return nil end
	if tonumber(text) then return "rbxassetid://" .. text end
	if string.sub(text, 1, 13) == "rbxassetid://" then return text end
	return nil
end

local function getTeam(name, color)
	local t = Teams:FindFirstChild(name)
	if not t then
		t = Instance.new("Team")
		t.Name = name
		t.TeamColor = BrickColor.new(color)
		t.AutoAssignable = false
		t.Parent = Teams
	end
	return t
end

local SCALE_NAMES = {"BodyHeightScale", "BodyWidthScale", "BodyDepthScale", "HeadScale"}

local function applyScale(hum, scale)
	for _, n in ipairs(SCALE_NAMES) do
		local v = hum:FindFirstChild(n)
		if v then v.Value = scale end
	end
end

----------------------------------------------------------------
-- KAFANIN USTUNDEKI ETIKET: [simge] Isim / Yetki seviyesi
----------------------------------------------------------------
local function buildTag(player, char)
	local hum = char:FindFirstChildOfClass("Humanoid")
	local head = char:FindFirstChild("Head")
	if not hum or not head then return end

	local role = ROLES[player:GetAttribute("RoleKey") or ""]
	local title = player:GetAttribute("RPName") or (role and role.name) or player.DisplayName
	local level = player:GetAttribute("RPLevel") or (role and role.level) or ""
	local icon = player:GetAttribute("RoleIcon") or (role and role.icon ~= "" and role.icon) or nil

	hum.DisplayName = title
	hum.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None

	local old = head:FindFirstChild("RPTag")
	if old then old:Destroy() end

	local gui = Instance.new("BillboardGui")
	gui.Name = "RPTag"
	gui.Size = UDim2.fromOffset(280, 60)
	gui.StudsOffset = Vector3.new(0, 3, 0)
	gui.MaxDistance = 45
	gui.Adornee = head
	gui.Parent = head

	local textX = 0
	if icon then
		local img = Instance.new("ImageLabel")
		img.Size = UDim2.fromOffset(52, 52)
		img.Position = UDim2.fromOffset(0, 4)
		img.BackgroundTransparency = 1
		img.Image = icon
		img.Parent = gui
		textX = 58
	end

	local nameLabel = Instance.new("TextLabel")
	nameLabel.Size = UDim2.new(1, -textX, 0.55, 0)
	nameLabel.Position = UDim2.new(0, textX, 0, 0)
	nameLabel.BackgroundTransparency = 1
	nameLabel.TextScaled = true
	nameLabel.TextXAlignment = icon and Enum.TextXAlignment.Left or Enum.TextXAlignment.Center
	nameLabel.Font = Enum.Font.GothamBold
	nameLabel.TextColor3 = Color3.new(1, 1, 1)
	nameLabel.TextStrokeTransparency = 0.3
	nameLabel.Text = title
	nameLabel.Parent = gui

	local levelLabel = Instance.new("TextLabel")
	levelLabel.Size = UDim2.new(1, -textX, 0.4, 0)
	levelLabel.Position = UDim2.new(0, textX, 0.58, 0)
	levelLabel.BackgroundTransparency = 1
	levelLabel.TextScaled = true
	levelLabel.TextXAlignment = nameLabel.TextXAlignment
	levelLabel.Font = Enum.Font.Gotham
	levelLabel.TextColor3 = player.Team and player.Team.TeamColor.Color or Color3.fromRGB(200, 200, 200)
	levelLabel.TextStrokeTransparency = 0.4
	levelLabel.Text = level
	levelLabel.Parent = gui
end

local function applyCharacter(player, char)
	-- HUD rol ekrani icin rol adi ve varsayilan yetki seviyesi
	local roleForHud = ROLES[player:GetAttribute("RoleKey") or ""]
	player:SetAttribute("RoleName", roleForHud and roleForHud.name or nil)
	player:SetAttribute("RoleLevel", roleForHud and roleForHud.level or nil)

	local hum = char:WaitForChild("Humanoid")
	task.wait(0.2) -- R15 scale degerleri yuklensin

	local scale = player:GetAttribute("BoyScale")
	if scale then applyScale(hum, scale) end

	local role = ROLES[player:GetAttribute("RoleKey") or ""]
	if role then
		hum.MaxHealth = role.health
		hum.Health = role.health
		hum.WalkSpeed = role.speed
		local toolsFolder = ServerStorage:FindFirstChild("Tools")
		if toolsFolder then
			for _, toolName in ipairs(role.tools) do
				local tool = toolsFolder:FindFirstChild(toolName)
				if tool then tool:Clone().Parent = player.Backpack end
			end
		end
	end
	buildTag(player, char)
end

local function onPlayer(player)
	if isAdmin(player) then player:SetAttribute("IsAdmin", true) end
	player.CharacterAdded:Connect(function(char) applyCharacter(player, char) end)
end
Players.PlayerAdded:Connect(onPlayer)
for _, p in ipairs(Players:GetPlayers()) do onPlayer(p) end

----------------------------------------------------------------
-- ROL VERME: izleyiciden cikarir, spawn noktasinda dogurur
----------------------------------------------------------------
local function setRole(player, roleKey)
	local role = ROLES[roleKey]
	if not role then return end
	player:SetAttribute("RoleKey", roleKey)
	player.Team = getTeam(role.team, role.color) -- Spectator takimindan cikar
	player:LoadCharacter()

	local char = player.Character or player.CharacterAdded:Wait()
	local spawns = workspace:FindFirstChild("Spawns")
	if spawns then
		local options = {}
		for _, p in ipairs(spawns:GetChildren()) do
			if p.Name == role.spawn then table.insert(options, p) end
		end
		if #options > 0 then
			char:PivotTo(options[math.random(#options)].CFrame + Vector3.new(0, 4, 0))
		else
			warn("Spawn bulunamadi: " .. role.spawn)
		end
	end
end

_G.SetRole = setRole -- RoundManager: _G.SetRole(player, "d_class")
_G.SCPRoles = ROLES

----------------------------------------------------------------
-- PANEL ISTEKLERI
----------------------------------------------------------------
rolesRF.OnServerInvoke = function(admin)
	if not isAdmin(admin) then return {} end
	local list = {}
	for _, key in ipairs(ROLE_ORDER) do
		table.insert(list, {key = key, name = ROLES[key].name, level = ROLES[key].level})
	end
	return list
end

actionRF.OnServerInvoke = function(admin, data)
	if not isAdmin(admin) then return "Yetkin yok." end
	if typeof(data) ~= "table" then return "Geçersiz istek." end

	local target = Players:GetPlayerByUserId(tonumber(data.target) or 0)
	if not target then return "Oyuncu bulunamadı." end

	if data.action == "reset" then
		target:SetAttribute("RPName", nil)
		target:SetAttribute("RPLevel", nil)
		target:SetAttribute("BoyScale", nil)
		target:SetAttribute("RoleIcon", nil)
		if target.Character then
			local hum = target.Character:FindFirstChildOfClass("Humanoid")
			if hum then applyScale(hum, 1) end
			buildTag(target, target.Character)
		end
		return target.Name .. " sıfırlandı."
	end

	if data.action ~= "apply" then return "Bilinmeyen işlem." end

	-- isim / yetki / ikon / boy (bos birakilirsa mevcut deger korunur)
	local name = clean(data.name, 40)
	local level = clean(data.level, 40)
	local icon = normalizeIcon(data.icon)
	local height = tonumber(data.height)

	if name then target:SetAttribute("RPName", name) end
	if level then target:SetAttribute("RPLevel", level) end
	if icon then target:SetAttribute("RoleIcon", icon) end
	if height then target:SetAttribute("BoyScale", math.clamp(height, MIN_BOY, MAX_BOY)) end

	local roleKey = data.role
	if typeof(roleKey) == "string" and ROLES[roleKey] then
		-- rol degisti: yeni karakter, spawn noktasinda dogar, hepsi CharacterAdded'de uygulanir
		setRole(target, roleKey)
		return target.Name .. " → " .. ROLES[roleKey].name .. " olarak doğdu."
	end

	-- rol degismedi: mevcut karakteri guncelle
	local char = target.Character
	if char then
		local hum = char:FindFirstChildOfClass("Humanoid")
		local scale = target:GetAttribute("BoyScale")
		if hum and scale then applyScale(hum, scale) end
		buildTag(target, char)
	end
	return target.Name .. " güncellendi."
end
```

## AdminPanelClient

*LocalScript — StarterPlayer > StarterPlayerScripts*

```lua
-- StarterPlayer > StarterPlayerScripts icine "AdminPanelClient" adiyla LOCALSCRIPT olarak koy.
-- Paneli M tusu ile ac/kapat (sadece adminlerde calisir).

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local UserInputService = game:GetService("UserInputService")

local player = Players.LocalPlayer
local remotes = ReplicatedStorage:WaitForChild("AdminRemotes")
local actionRF = remotes:WaitForChild("AdminAction")
local rolesRF = remotes:WaitForChild("GetRoles")

-- RENKLER
local BG = Color3.fromRGB(24, 26, 32)
local PANEL = Color3.fromRGB(34, 37, 46)
local ITEM = Color3.fromRGB(48, 52, 64)
local SELECTED = Color3.fromRGB(70, 110, 190)
local TEXT = Color3.fromRGB(235, 235, 240)
local MUTED = Color3.fromRGB(150, 155, 170)

local selectedUserId = nil
local selectedRole = nil

----------------------------------------------------------------
-- UI YARDIMCILARI
----------------------------------------------------------------
local function corner(obj, r)
	local c = Instance.new("UICorner")
	c.CornerRadius = UDim.new(0, r or 6)
	c.Parent = obj
end

local function makeLabel(parent, text, pos, size)
	local l = Instance.new("TextLabel")
	l.BackgroundTransparency = 1
	l.Text = text
	l.Position = pos
	l.Size = size or UDim2.fromOffset(260, 18)
	l.TextXAlignment = Enum.TextXAlignment.Left
	l.Font = Enum.Font.GothamMedium
	l.TextSize = 13
	l.TextColor3 = MUTED
	l.Parent = parent
	return l
end

local function makeBox(parent, placeholder, pos)
	local b = Instance.new("TextBox")
	b.Position = pos
	b.Size = UDim2.fromOffset(260, 32)
	b.BackgroundColor3 = ITEM
	b.PlaceholderText = placeholder
	b.PlaceholderColor3 = MUTED
	b.Text = ""
	b.TextColor3 = TEXT
	b.Font = Enum.Font.Gotham
	b.TextSize = 14
	b.ClearTextOnFocus = false
	b.TextXAlignment = Enum.TextXAlignment.Left
	b.Parent = parent
	corner(b)
	local pad = Instance.new("UIPadding")
	pad.PaddingLeft = UDim.new(0, 8)
	pad.Parent = b
	return b
end

local function makeButton(parent, text, pos, size, color)
	local b = Instance.new("TextButton")
	b.Position = pos
	b.Size = size
	b.BackgroundColor3 = color or ITEM
	b.Text = text
	b.TextColor3 = TEXT
	b.Font = Enum.Font.GothamBold
	b.TextSize = 14
	b.AutoButtonColor = true
	b.Parent = parent
	corner(b)
	return b
end

local function makeList(parent, pos, height)
	local s = Instance.new("ScrollingFrame")
	s.Position = pos
	s.Size = UDim2.fromOffset(260, height)
	s.BackgroundColor3 = PANEL
	s.BorderSizePixel = 0
	s.ScrollBarThickness = 4
	s.CanvasSize = UDim2.new()
	s.AutomaticCanvasSize = Enum.AutomaticSize.Y
	s.Parent = parent
	corner(s)
	local layout = Instance.new("UIListLayout")
	layout.Padding = UDim.new(0, 3)
	layout.Parent = s
	local pad = Instance.new("UIPadding")
	pad.PaddingTop = UDim.new(0, 4)
	pad.PaddingLeft = UDim.new(0, 4)
	pad.PaddingRight = UDim.new(0, 4)
	pad.Parent = s
	return s
end

local function makeItem(list, text)
	local b = Instance.new("TextButton")
	b.Size = UDim2.new(1, -8, 0, 28)
	b.BackgroundColor3 = ITEM
	b.Text = text
	b.TextColor3 = TEXT
	b.Font = Enum.Font.Gotham
	b.TextSize = 13
	b.TextXAlignment = Enum.TextXAlignment.Left
	b.Parent = list
	corner(b, 4)
	local pad = Instance.new("UIPadding")
	pad.PaddingLeft = UDim.new(0, 8)
	pad.Parent = b
	return b
end

local function highlight(list, chosen)
	for _, c in ipairs(list:GetChildren()) do
		if c:IsA("TextButton") then
			c.BackgroundColor3 = (c == chosen) and SELECTED or ITEM
		end
	end
end

local function clearList(list)
	for _, c in ipairs(list:GetChildren()) do
		if c:IsA("TextButton") then c:Destroy() end
	end
end

----------------------------------------------------------------
-- PANEL
----------------------------------------------------------------
local gui = Instance.new("ScreenGui")
gui.Name = "AdminPanel"
gui.ResetOnSpawn = false
gui.Enabled = false
gui.Parent = player:WaitForChild("PlayerGui")

local frame = Instance.new("Frame")
frame.Size = UDim2.fromOffset(580, 470)
frame.Position = UDim2.new(0.5, -290, 0.5, -235)
frame.BackgroundColor3 = BG
frame.Active = true
frame.Draggable = true
frame.Parent = gui
corner(frame, 10)

local title = Instance.new("TextLabel")
title.Size = UDim2.new(1, -50, 0, 36)
title.Position = UDim2.fromOffset(14, 0)
title.BackgroundTransparency = 1
title.Text = "Admin Paneli"
title.TextXAlignment = Enum.TextXAlignment.Left
title.Font = Enum.Font.GothamBold
title.TextSize = 17
title.TextColor3 = TEXT
title.Parent = frame

local closeBtn = makeButton(frame, "X", UDim2.new(1, -36, 0, 5), UDim2.fromOffset(26, 26), Color3.fromRGB(170, 60, 60))
closeBtn.MouseButton1Click:Connect(function() gui.Enabled = false end)

-- Sol sutun: oyuncu ve rol listeleri
makeLabel(frame, "OYUNCU", UDim2.fromOffset(14, 42))
local playerList = makeList(frame, UDim2.fromOffset(14, 62), 170)

makeLabel(frame, "ROL (seçmezsen rol değişmez)", UDim2.fromOffset(14, 240))
local roleList = makeList(frame, UDim2.fromOffset(14, 260), 190)

-- Sag sutun: alanlar
makeLabel(frame, "İSİM / UNVAN (örn: Tesis Yöneticisi)", UDim2.fromOffset(306, 42))
local nameBox = makeBox(frame, "Boş = rol adı", UDim2.fromOffset(306, 62))

makeLabel(frame, "YETKİ SEVİYESİ (örn: 6. Seviye Personel)", UDim2.fromOffset(306, 102))
local levelBox = makeBox(frame, "Boş = rolün varsayılanı", UDim2.fromOffset(306, 122))

makeLabel(frame, "BOY (0.5 - 2)", UDim2.fromOffset(306, 162))
local heightBox = makeBox(frame, "Örn: 1.1", UDim2.fromOffset(306, 182))

makeLabel(frame, "ROL SİMGESİ (Asset ID)", UDim2.fromOffset(306, 222))
local iconBox = makeBox(frame, "Boş = rolün simgesi", UDim2.fromOffset(306, 242))

local status = Instance.new("TextLabel")
status.Position = UDim2.fromOffset(306, 288)
status.Size = UDim2.fromOffset(260, 60)
status.BackgroundTransparency = 1
status.TextWrapped = true
status.TextXAlignment = Enum.TextXAlignment.Left
status.TextYAlignment = Enum.TextYAlignment.Top
status.Font = Enum.Font.Gotham
status.TextSize = 13
status.TextColor3 = MUTED
status.Text = "Önce bir oyuncu seç."
status.Parent = frame

local applyBtn = makeButton(frame, "UYGULA", UDim2.fromOffset(306, 360), UDim2.fromOffset(260, 42), Color3.fromRGB(60, 150, 90))
local resetBtn = makeButton(frame, "İSİM / BOY SIFIRLA", UDim2.fromOffset(306, 410), UDim2.fromOffset(260, 36), Color3.fromRGB(150, 90, 50))

----------------------------------------------------------------
-- LISTELERI DOLDUR
----------------------------------------------------------------
local function refreshPlayers()
	clearList(playerList)
	for _, p in ipairs(Players:GetPlayers()) do
		local item = makeItem(playerList, p.DisplayName .. "  (@" .. p.Name .. ")")
		if p.UserId == selectedUserId then item.BackgroundColor3 = SELECTED end
		item.MouseButton1Click:Connect(function()
			selectedUserId = p.UserId
			highlight(playerList, item)
			-- mevcut degerleri kutulara yaz
			nameBox.Text = p:GetAttribute("RPName") or ""
			levelBox.Text = p:GetAttribute("RPLevel") or ""
			local scale = p:GetAttribute("BoyScale")
			heightBox.Text = scale and tostring(scale) or ""
			iconBox.Text = ""
			status.Text = "Seçildi: " .. p.Name
		end)
	end
end

local function refreshRoles()
	clearList(roleList)
	local none = makeItem(roleList, "— Rolü değiştirme —")
	none.BackgroundColor3 = SELECTED
	none.MouseButton1Click:Connect(function()
		selectedRole = nil
		highlight(roleList, none)
	end)

	local ok, roles = pcall(function() return rolesRF:InvokeServer() end)
	if not ok or typeof(roles) ~= "table" then return end
	for _, r in ipairs(roles) do
		local item = makeItem(roleList, r.name)
		item.MouseButton1Click:Connect(function()
			selectedRole = r.key
			highlight(roleList, item)
			if levelBox.Text == "" then levelBox.PlaceholderText = r.level end
		end)
	end
end

Players.PlayerAdded:Connect(function() if gui.Enabled then refreshPlayers() end end)
Players.PlayerRemoving:Connect(function()
	task.defer(function() if gui.Enabled then refreshPlayers() end end)
end)

----------------------------------------------------------------
-- BUTONLAR
----------------------------------------------------------------
applyBtn.MouseButton1Click:Connect(function()
	if not selectedUserId then
		status.Text = "Önce bir oyuncu seç."
		return
	end
	status.Text = "Uygulanıyor..."
	local ok, result = pcall(function()
		return actionRF:InvokeServer({
			action = "apply",
			target = selectedUserId,
			role = selectedRole,
			name = nameBox.Text,
			level = levelBox.Text,
			height = heightBox.Text,
			icon = iconBox.Text,
		})
	end)
	status.Text = ok and tostring(result) or "Hata oluştu."
end)

resetBtn.MouseButton1Click:Connect(function()
	if not selectedUserId then
		status.Text = "Önce bir oyuncu seç."
		return
	end
	local ok, result = pcall(function()
		return actionRF:InvokeServer({action = "reset", target = selectedUserId})
	end)
	status.Text = ok and tostring(result) or "Hata oluştu."
	nameBox.Text, levelBox.Text, heightBox.Text, iconBox.Text = "", "", "", ""
end)

----------------------------------------------------------------
-- F2 ILE AC / KAPAT
----------------------------------------------------------------
UserInputService.InputBegan:Connect(function(input, processed)
	if processed or input.KeyCode ~= Enum.KeyCode.M then return end
	if not player:GetAttribute("IsAdmin") then return end
	gui.Enabled = not gui.Enabled
	if gui.Enabled then
		refreshPlayers()
		refreshRoles()
	end
end)
```

## RPConsoleServer

*Script — ServerScriptService*

```lua
-- ServerScriptService icine "RPConsoleServer" adiyla normal SCRIPT olarak koy.
-- Komutlar: .me .do .de .ooc .b .s .f .bayil .kalk .yardim (+ nokta olmadan yazilan normal konusma)

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TextService = game:GetService("TextService")

----------------------------------------------------------------
-- AYARLAR
----------------------------------------------------------------
local RANGE = {say = 25, me = 30, ["do"] = 30, de = 30, b = 25, s = 60, f = 5}
local MAX_LEN = 200
local COOLDOWN = 0.7
local MAX_FAINT_TIME = 600 -- ".bayil <saniye>" icin ust sinir

local COLORS = {
	say = Color3.fromRGB(255, 255, 255),
	me = Color3.fromRGB(196, 162, 255),
	["do"] = Color3.fromRGB(255, 205, 130),
	de_ok = Color3.fromRGB(120, 230, 140),
	de_fail = Color3.fromRGB(255, 120, 120),
	ooc = Color3.fromRGB(170, 170, 170),
	shout = Color3.fromRGB(255, 150, 120),
	whisper = Color3.fromRGB(160, 200, 255),
	system = Color3.fromRGB(255, 240, 150),
}

----------------------------------------------------------------
-- REMOTE
----------------------------------------------------------------
local folder = ReplicatedStorage:FindFirstChild("RPRemotes")
if not folder then
	folder = Instance.new("Folder")
	folder.Name = "RPRemotes"
	folder.Parent = ReplicatedStorage
end
local remote = Instance.new("RemoteEvent")
remote.Name = "RPConsole"
remote.Parent = folder

----------------------------------------------------------------
-- YARDIMCI FONKSIYONLAR
----------------------------------------------------------------
-- Turkce karakterleri sadelestirir (.bayıl = .bayil, .bağır = .bagir)
local function normalize(s)
	s = string.gsub(s, "İ", "i")
	s = string.lower(s)
	for from, to in pairs({["ı"] = "i", ["ç"] = "c", ["ş"] = "s", ["ğ"] = "g", ["ö"] = "o", ["ü"] = "u"}) do
		s = string.gsub(s, from, to)
	end
	return s
end

local function getName(player)
	return player:GetAttribute("RPName") or player.DisplayName
end

local function getRoot(player)
	local char = player.Character
	return char and char:FindFirstChild("HumanoidRootPart")
end

local function inRange(sender, other, range)
	if sender == other then return true end
	local a, b = getRoot(sender), getRoot(other)
	return a ~= nil and b ~= nil and (a.Position - b.Position).Magnitude <= range
end

-- Oyuncunun yazdigi metni filtreleyerek yakindaki / herkese gonderir.
-- formatter(filtreliMetin) -> gosterilecek satir
local function broadcastText(sender, rawText, range, color, formatter)
	local ok, filtered = pcall(function()
		return TextService:FilterStringAsync(rawText, sender.UserId, Enum.TextFilterContext.PublicChat)
	end)
	if not ok then return end

	for _, p in ipairs(Players:GetPlayers()) do
		if range == nil or inRange(sender, p, range) then
			local okRecipient, text = pcall(function()
				return filtered:GetChatForUserAsync(p.UserId)
			end)
			if okRecipient then
				remote:FireClient(p, formatter(text), color)
			end
		end
	end
end

-- Oyuncu metni icermeyen sistem/aksiyon mesaji (filtre gerekmez)
local function broadcastPlain(sender, range, color, text)
	for _, p in ipairs(Players:GetPlayers()) do
		if range == nil or inRange(sender, p, range) then
			remote:FireClient(p, text, color)
		end
	end
end

local function reply(player, text)
	remote:FireClient(player, text, COLORS.system)
end

----------------------------------------------------------------
-- BAYILMA
----------------------------------------------------------------
local faintData = {}
local faintCounter = {}

local function isFainted(player)
	return player:GetAttribute("Fainted") == true
end

local function wake(player, silent)
	local data = faintData[player]
	if not data then return end
	faintData[player] = nil
	player:SetAttribute("Fainted", false)

	local char = player.Character
	local hum = char and char:FindFirstChildOfClass("Humanoid")
	local root = getRoot(player)
	if not hum or not root then return end

	root.Anchored = false
	hum.PlatformStand = false
	hum.WalkSpeed = data.walkSpeed
	hum.JumpPower = data.jumpPower
	hum.JumpHeight = data.jumpHeight
	char:PivotTo(CFrame.new(root.Position + Vector3.new(0, 3, 0)) * CFrame.Angles(0, data.yaw, 0))

	if not silent then
		broadcastPlain(player, RANGE.me, COLORS.me, "* " .. getName(player) .. " ayağa kalktı.")
	end
end

local function faint(player, duration)
	if isFainted(player) then return end
	local char = player.Character
	local hum = char and char:FindFirstChildOfClass("Humanoid")
	local root = getRoot(player)
	if not hum or not root or hum.Health <= 0 then return end

	local _, yaw = root.CFrame:ToEulerAnglesYXZ()
	faintData[player] = {
		walkSpeed = hum.WalkSpeed,
		jumpPower = hum.JumpPower,
		jumpHeight = hum.JumpHeight,
		yaw = yaw,
	}

	hum:UnequipTools()
	hum.WalkSpeed = 0
	hum.JumpPower = 0
	hum.JumpHeight = 0
	hum.PlatformStand = true

	-- yerin yuksekligini bul, duz sirt ustu yatir
	local params = RaycastParams.new()
	params.FilterDescendantsInstances = {char}
	params.FilterType = Enum.RaycastFilterType.Exclude
	local hit = workspace:Raycast(root.Position, Vector3.new(0, -20, 0), params)
	local floorY = hit and hit.Position.Y or (root.Position.Y - 3)

	local lying = CFrame.new(root.Position.X, floorY + root.Size.Z / 2 + 0.1, root.Position.Z)
		* CFrame.Angles(0, yaw, 0)
		* CFrame.Angles(math.rad(90), 0, 0)
	char:PivotTo(lying)
	root.Anchored = true
	player:SetAttribute("Fainted", true)

	broadcastPlain(player, RANGE.me, COLORS.me, "* " .. getName(player) .. " bayıldı.")

	-- istege bagli sure: .bayil 30
	faintCounter[player] = (faintCounter[player] or 0) + 1
	local myId = faintCounter[player]
	if duration then
		task.delay(duration, function()
			if faintCounter[player] == myId and isFainted(player) then
				wake(player)
			end
		end)
	end
end

local function onPlayer(player)
	player.CharacterAdded:Connect(function()
		faintData[player] = nil
		player:SetAttribute("Fainted", false)
	end)
end
Players.PlayerAdded:Connect(onPlayer)
for _, p in ipairs(Players:GetPlayers()) do onPlayer(p) end

Players.PlayerRemoving:Connect(function(p)
	faintData[p] = nil
	faintCounter[p] = nil
end)

----------------------------------------------------------------
-- KOMUTLAR
----------------------------------------------------------------
local HELP = {
	"--- KOMUTLAR ---",
	".me <eylem>      → * İsim eylem",
	".do <durum>      → * durum ((İsim))",
	".de <eylem>      → eylemi dener, başarılı / başarısız çıkar",
	".ooc <mesaj>     → herkese OOC mesaj",
	".b <mesaj>       → yakındakilere OOC mesaj",
	".s <mesaj>       → bağırır (uzaktan duyulur)",
	".f <mesaj>       → fısıldar (sadece çok yakın)",
	".bayil [sn]      → yere yığılırsın, hareket edemezsin",
	".kalk            → bayılmışken ayağa kalkarsın",
	"Noktasız yazarsan normal konuşursun.",
}

local lastCommand = {}

local function handle(player, text)
	if typeof(text) ~= "string" then return end
	text = string.sub(text, 1, MAX_LEN)
	text = string.gsub(text, "^%s+", "")
	text = string.gsub(text, "%s+$", "")
	if text == "" then return end

	local now = os.clock()
	if lastCommand[player] and now - lastCommand[player] < COOLDOWN then return end
	lastCommand[player] = now

	local name = getName(player)
	local cmd, rest

	if string.sub(text, 1, 1) == "." then
		local c, r = string.match(text, "^%.(%S+)%s*(.*)$")
		if not c then return end
		cmd = normalize(c)
		rest = r
	else
		cmd = "say"
		rest = text
	end

	local fainted = isFainted(player)

	-- bayilmisken sadece bu komutlar calisir
	local allowedWhileFainted = {ooc = true, b = true, yardim = true, help = true, kalk = true, bayil = true}
	if fainted and not allowedWhileFainted[cmd] then
		reply(player, "Bayılmışken bunu yapamazsın. (.kalk)")
		return
	end

	if cmd == "yardim" or cmd == "help" then
		for _, line in ipairs(HELP) do reply(player, line) end

	elseif cmd == "me" then
		if rest == "" then return reply(player, "Kullanım: .me <eylem>") end
		broadcastText(player, rest, RANGE.me, COLORS.me, function(t)
			return "* " .. name .. " " .. t
		end)

	elseif cmd == "do" then
		if rest == "" then return reply(player, "Kullanım: .do <durum>") end
		broadcastText(player, rest, RANGE["do"], COLORS["do"], function(t)
			return "* " .. t .. " (( " .. name .. " ))"
		end)

	elseif cmd == "de" then
		if rest == "" then return reply(player, "Kullanım: .de <eylem>") end
		local success = math.random() < 0.5
		broadcastText(player, rest, RANGE.de, success and COLORS.de_ok or COLORS.de_fail, function(t)
			return "* " .. name .. " " .. t .. " denedi ve " .. (success and "BAŞARILI OLDU." or "BAŞARAMADI.")
		end)

	elseif cmd == "ooc" then
		if rest == "" then return reply(player, "Kullanım: .ooc <mesaj>") end
		broadcastText(player, rest, nil, COLORS.ooc, function(t)
			return "(( [OOC] " .. player.DisplayName .. ": " .. t .. " ))"
		end)

	elseif cmd == "b" then
		if rest == "" then return reply(player, "Kullanım: .b <mesaj>") end
		broadcastText(player, rest, RANGE.b, COLORS.ooc, function(t)
			return "(( " .. player.DisplayName .. ": " .. t .. " ))"
		end)

	elseif cmd == "s" or cmd == "bagir" then
		if rest == "" then return reply(player, "Kullanım: .s <mesaj>") end
		broadcastText(player, rest, RANGE.s, COLORS.shout, function(t)
			return name .. " bağırır: " .. t .. "!"
		end)

	elseif cmd == "f" or cmd == "fisilda" then
		if rest == "" then return reply(player, "Kullanım: .f <mesaj>") end
		broadcastText(player, rest, RANGE.f, COLORS.whisper, function(t)
			return name .. " fısıldar: " .. t
		end)

	elseif cmd == "bayil" then
		if fainted then
			wake(player)
		else
			local secs = tonumber(rest)
			if secs then secs = math.clamp(secs, 1, MAX_FAINT_TIME) end
			faint(player, secs)
		end

	elseif cmd == "kalk" then
		if fainted then
			wake(player)
		else
			reply(player, "Zaten ayaktasın.")
		end

	elseif cmd == "say" then
		broadcastText(player, rest, RANGE.say, COLORS.say, function(t)
			return name .. ": " .. t
		end)

	else
		reply(player, "Bilinmeyen komut. Liste için .yardim yaz.")
	end
end

remote.OnServerEvent:Connect(handle)

Players.PlayerRemoving:Connect(function(p) lastCommand[p] = nil end)
print("[RPConsoleServer] hazir")
```

## RPConsoleClient

*LocalScript — StarterPlayer > StarterPlayerScripts*

```lua
-- StarterPlayer > StarterPlayerScripts icine "RPConsoleClient" adiyla LOCALSCRIPT olarak koy.
-- I / İ tusuyla yazma kutusu acilir. Enter gonderir, Esc kapatir.

print("[RPConsole] client basladi")

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local UserInputService = game:GetService("UserInputService")
local ContextActionService = game:GetService("ContextActionService")
local RunService = game:GetService("RunService")

local player = Players.LocalPlayer

local DEBUG = true -- true: basilan her tusu Output'a yazar. Calisinca false yap.
local MAX_ENTRIES = 60
local FADE_START = 20
local FADE_TIME = 5

----------------------------------------------------------------
-- ARAYUZ
----------------------------------------------------------------
local gui = Instance.new("ScreenGui")
gui.Name = "RPConsole"
gui.ResetOnSpawn = false
gui.DisplayOrder = 50
gui.IgnoreGuiInset = true
gui.Parent = player:WaitForChild("PlayerGui")

local feed = Instance.new("ScrollingFrame")
feed.Size = UDim2.fromOffset(460, 230)
feed.Position = UDim2.new(0, 12, 1, -310)
feed.BackgroundColor3 = Color3.new(0, 0, 0)
feed.BackgroundTransparency = 1
feed.BorderSizePixel = 0
feed.ScrollBarThickness = 4
feed.CanvasSize = UDim2.new()
feed.AutomaticCanvasSize = Enum.AutomaticSize.Y
feed.Parent = gui

local layout = Instance.new("UIListLayout")
layout.SortOrder = Enum.SortOrder.LayoutOrder
layout.Padding = UDim.new(0, 2)
layout.Parent = feed

local inputBar = Instance.new("Frame")
inputBar.Size = UDim2.fromOffset(460, 36)
inputBar.Position = UDim2.new(0, 12, 1, -60)
inputBar.BackgroundColor3 = Color3.fromRGB(24, 26, 32)
inputBar.BackgroundTransparency = 0.1
inputBar.Visible = false
inputBar.Parent = gui
Instance.new("UICorner", inputBar).CornerRadius = UDim.new(0, 8)

local box = Instance.new("TextBox")
box.Size = UDim2.new(1, -16, 1, 0)
box.Position = UDim2.fromOffset(8, 0)
box.BackgroundTransparency = 1
box.Text = ""
box.PlaceholderText = ".me  .do  .de  .ooc  .bayıl  |  yardım için .yardim"
box.PlaceholderColor3 = Color3.fromRGB(140, 145, 160)
box.TextColor3 = Color3.new(1, 1, 1)
box.Font = Enum.Font.Gotham
box.TextSize = 15
box.TextXAlignment = Enum.TextXAlignment.Left
box.ClearTextOnFocus = false
box.Parent = inputBar

-- Debug: son basilan tusu ekranda gosterir (DEBUG = false yapinca gorunmez)
local debugLabel = Instance.new("TextLabel")
debugLabel.Size = UDim2.fromOffset(300, 20)
debugLabel.Position = UDim2.new(0, 12, 1, -332)
debugLabel.BackgroundTransparency = 1
debugLabel.TextXAlignment = Enum.TextXAlignment.Left
debugLabel.Font = Enum.Font.Code
debugLabel.TextSize = 14
debugLabel.TextColor3 = Color3.fromRGB(255, 200, 80)
debugLabel.Text = "Son tuş: (henüz yok)"
debugLabel.Visible = false
debugLabel.Parent = gui

----------------------------------------------------------------
-- MESAJLAR
----------------------------------------------------------------
local entries = {}
local counter = 0
local isOpen = false

local function addMessage(text, color)
	counter += 1
	local label = Instance.new("TextLabel")
	label.Size = UDim2.new(1, -8, 0, 0)
	label.AutomaticSize = Enum.AutomaticSize.Y
	label.BackgroundTransparency = 1
	label.TextWrapped = true
	label.RichText = false
	label.TextXAlignment = Enum.TextXAlignment.Left
	label.Font = Enum.Font.Gotham
	label.TextSize = 15
	label.TextColor3 = color or Color3.new(1, 1, 1)
	label.TextStrokeTransparency = 0.5
	label.Text = text
	label.LayoutOrder = counter
	label.Parent = feed

	table.insert(entries, {label = label, time = os.clock()})
	if #entries > MAX_ENTRIES then
		local old = table.remove(entries, 1)
		old.label:Destroy()
	end

	task.defer(function()
		feed.CanvasPosition = Vector2.new(0, feed.AbsoluteCanvasSize.Y)
	end)
end

task.spawn(function()
	while true do
		task.wait(0.25)
		local now = os.clock()
		for _, e in ipairs(entries) do
			local alpha = 0
			if not isOpen then
				alpha = math.clamp((now - e.time - FADE_START) / FADE_TIME, 0, 1)
			end
			e.label.TextTransparency = alpha
			e.label.TextStrokeTransparency = 0.5 + alpha * 0.5
		end
	end
end)

----------------------------------------------------------------
-- SERVER BAGLANTISI
----------------------------------------------------------------
local remote = nil

task.spawn(function()
	local folder = ReplicatedStorage:WaitForChild("RPRemotes", 10)
	remote = folder and folder:WaitForChild("RPConsole", 10)
	if remote then
		remote.OnClientEvent:Connect(addMessage)
		addMessage("RP konsolu hazır: I / İ tuşuna bas. Komutlar için .yardim yaz.", Color3.fromRGB(255, 240, 150))
		print("[RPConsole] server baglandi")
	else
		addMessage("HATA: RPConsoleServer çalışmıyor. ServerScriptService içinde normal Script olarak durduğundan emin ol.", Color3.fromRGB(255, 120, 120))
		warn("[RPConsole] RPRemotes bulunamadi - RPConsoleServer calismiyor")
	end
end)

----------------------------------------------------------------
-- ACMA / KAPAMA
----------------------------------------------------------------
local function closeConsole()
	isOpen = false
	inputBar.Visible = false
	feed.BackgroundTransparency = 1
end

local function openConsole()
	if isOpen then return end
	isOpen = true
	inputBar.Visible = true
	feed.BackgroundTransparency = 0.6
	task.spawn(function()
		RunService.RenderStepped:Wait() -- tusun harfi kutuya yazilmasin
		box:CaptureFocus()
		box.Text = ""
	end)
end

box.FocusLost:Connect(function(enterPressed)
	local text = box.Text
	box.Text = ""
	if enterPressed and text ~= "" then
		if remote then
			remote:FireServer(text)
		else
			addMessage("Sunucuya bağlanılamadı.", Color3.fromRGB(255, 120, 120))
		end
	end
	closeConsole()
end)

----------------------------------------------------------------
-- TUS DINLEME
-- "processed" kontrolunu BILEREK kullanmiyoruz; sadece bir yazi kutusu
-- odaktaysa tusu yok sayiyoruz.
----------------------------------------------------------------
local OPEN_KEYS = {
	[Enum.KeyCode.I] = true,     -- "ı" tusu
	[Enum.KeyCode.Quote] = true, -- Turkce klavyedeki "İ" tusu
	[Enum.KeyCode.T] = true,     -- yedek tus: T her klavyede calisir
	[Enum.KeyCode.Unknown] = true, -- Roblox'un taniyamadigi tuslar (ı / İ bazen boyle gelir)
}
local OPEN_CHARS = {i = true, I = true, ["ı"] = true, ["İ"] = true}

local function isOpenKey(input)
	if input.UserInputType ~= Enum.UserInputType.Keyboard then return false end
	if OPEN_KEYS[input.KeyCode] then return true end
	local ok, s = pcall(function()
		return UserInputService:GetStringForKeyCode(input.KeyCode)
	end)
	return ok and OPEN_CHARS[s] == true
end

UserInputService.InputBegan:Connect(function(input, processed)
	if input.UserInputType == Enum.UserInputType.Keyboard and DEBUG then
		debugLabel.Visible = true
		debugLabel.Text = "Son tuş: " .. input.KeyCode.Name .. " | processed: " .. tostring(processed)
		print("[RPConsole] tus:", input.KeyCode.Name, "| processed:", processed, "| acik:", isOpen)
	end
	if isOpen then return end
	if UserInputService:GetFocusedTextBox() then return end
	if isOpenKey(input) then
		openConsole()
	end
end)

-- Ikinci yol: ContextActionService (en yuksek oncelik)
ContextActionService:BindActionAtPriority("RPConsoleOpen", function(_, state, input)
	if state == Enum.UserInputState.Begin then
		openConsole()
	end
	return Enum.ContextActionResult.Pass
end, false, Enum.ContextActionPriority.High.Value, Enum.KeyCode.I, Enum.KeyCode.Quote, Enum.KeyCode.T)
```

## CassieConfig

*ModuleScript — ReplicatedStorage*

```lua
-- ReplicatedStorage icine "CassieConfig" adiyla MODULESCRIPT olarak koy.
-- Hem server hem client bunu kullanir. Tum CASSIE ayarlari burada.

local Config = {}

-- ZAMANLAMA (saniye)
Config.WORD_TIME = 0.45     -- her kelime icin temel sure
Config.PAUSE_COMMA = 0.25   -- virgul / noktalı virgul sonrasi ek bekleme
Config.PAUSE_PERIOD = 0.6   -- nokta / unlem / soru / iki nokta sonrasi ek bekleme
Config.START_DELAY = 1.2    -- zil sesinden sonra yazi baslamadan once bekleme
Config.END_PADDING = 2.5    -- yazi bittikten sonra ekranda kalma suresi
Config.GAP = 1.0            -- iki anons arasindaki bosluk

-- SES
Config.VOLUME = 0.8
Config.BELL_ID = ""         -- anons oncesi zil sesi: "rbxassetid://123456" (bos = zil yok)

-- KELIME SESLERI (istege bagli)
-- Kelime kucuk harfle yazilir, noktalama yazilmaz. Ses dosyasi olmayan kelime sessiz kalir,
-- yazi her durumda ekranda gorunur.
Config.WORD_SOUNDS = {
	-- ["dikkat"] = "rbxassetid://123456",
	-- ["tesis"] = "rbxassetid://123457",
}

-- ANONS TURLERI (renk ve etiket)
Config.KINDS = {
	info     = {label = "BİLGİ",      color = Color3.fromRGB(90, 160, 255)},
	warning  = {label = "UYARI",      color = Color3.fromRGB(255, 170, 60)},
	critical = {label = "ACİL DURUM", color = Color3.fromRGB(235, 70, 70)},
}

----------------------------------------------------------------
-- OTOMATIK OLAY DUYURULARI (CassieEvents scripti kullanir)
----------------------------------------------------------------
Config.EVENTS = {
	-- 1) ONEMLI KISI OLUMU
	-- Isim "Unvan|Isim" seklinde verilirse (ornek: Tesis Komutanı|Liewex) ve unvan asagidaki
	-- listedeyse oyuncu "onemli kisi" sayilir. Yetki seviyesi VIP_MIN_LEVEL ve ustuyse de sayilir.
	-- Unvandaki Turkce buyuk/kucuk harfler listedekiyle AYNI yazilmali (İ, ı gibi).
	VIP_TITLES = {"Tesis Komutanı", "Tesis Yöneticisi", "Saha Direktörü", "Güvenlik Şefi", "Bilim Direktörü"},
	VIP_MIN_LEVEL = 6,   -- 0 yaparsan seviyeye bakmaz
	VIP_DEATH_DELAY = 4, -- olumden kac saniye sonra duyurulsun

	-- 2) TESISE GIRIS (takim adi -> duyuru). Toplu girislerde cooldown sayesinde tek anons okunur.
	TEAM_ARRIVALS = {
		["Chaos Insurgency"] = {
			text = "Dikkat. Kaos İsyancıları tesise giriş yaptı. Yetkisiz silahlı personel tespit edildi.",
			kind = "critical", cooldown = 90,
		},
		["GOC"] = {
			text = "Dikkat. Küresel Okült Koalisyon birimleri tesise giriş yaptı.",
			kind = "critical", cooldown = 90,
		},
	},

	-- 3) RUTBELI GIRISI
	-- Asagidaki rollerden biri tesise girince, ADMIN'IN VERDIGI ISIMLE anons okunur.
	-- Ornek: isim "Tesis Teğmeni|Liewex" ise ->
	--   "DİKKAT DİKKAT. TESİS TEĞMENİ LİEWEX TESİSE GİRİŞ YAPMIŞTIR. BİLGİNİZE."
	-- Isim verilmemisse title + oyuncunun gorunen adi okunur.
	-- Minimum rutbe NTF Çavuşu: yeni rutbe eklemek icin roles tablosuna bir satir ekle.
	RANK_ARRIVALS = {
		template = "Dikkat dikkat. %s tesise giriş yapmıştır. Bilginize.", -- %s = isim
		kind = "warning",
		uppercase = true,  -- tum anons BUYUK HARFLE (Turkce harflere uygun)
		cooldown = 60,     -- ayni oyuncu icin tekrar duyuru araligi (sn)
		roles = {
			-- rol anahtari = {team = rolun takimi (baska takimdaysa duyurulmaz), title = isim yoksa kullanilacak unvan}
			ntf_cavus = {team = "MTF", title = "NTF Çavuşu"},
			ntf_albay = {team = "MTF", title = "NTF Albayı"},
		},
	},

	-- 4) SILAHLI D-CLASS
	-- Bir D-Class elinde silahla, tanik takimlardan birinin gorus alaninda ve gorus mesafesinde
	-- ise duyurulur.
	ARMED_D = {
		enabled = true,
		dTeam = "Class-D",
		witnessTeams = {"Scientist", "Facility Guard", "MTF"}, -- kimler gorurse duyurulsun
		weapons = {"Pistol", "Rifle"},  -- silah sayilan Tool adlari (veya Tool'a IsWeapon = true attribute'u ver)
		range = 60,             -- gorus mesafesi (stud)
		viewAngle = 120,        -- taniğin gorus acisi (derece)
		perPlayerCooldown = 120, -- ayni D-Class icin tekrar duyuru araligi (sn)
		globalCooldown = 20,     -- herhangi iki silahli D-Class duyurusu arasi (sn)
		scanInterval = 0.75,
	},
}

-- Kelimeyi ses aramasi icin sadelestirir (kucuk harf, noktalama yok)
function Config.Normalize(word)
	local lowered = string.lower(word)
	local cleaned = string.gsub(lowered, "[%.,!%?:;\"']", "")
	return cleaned
end

-- Metni kelimelere boler; her kelimenin ne kadar bekleyecegini ve toplam sureyi dondurur.
-- Server (kuyruk suresi) ve client (yazi hizi) AYNI fonksiyonu kullanir, boylece senkron kalir.
function Config.Schedule(text)
	local words = {}
	local total = Config.START_DELAY

	for w in string.gmatch(text, "%S+") do
		local delay = Config.WORD_TIME
		local last = string.sub(w, -1)
		if last == "," or last == ";" then
			delay += Config.PAUSE_COMMA
		elseif last == "." or last == "!" or last == "?" or last == ":" then
			delay += Config.PAUSE_PERIOD
		end
		table.insert(words, {text = w, key = Config.Normalize(w), delay = delay})
		total += delay
	end

	total += Config.END_PADDING
	return words, total
end

return Config
```

## Cassie

*ModuleScript — ServerScriptService*

```lua
-- ServerScriptService icine "Cassie" adiyla MODULESCRIPT olarak koy.
-- Baska script'ler: local Cassie = require(game.ServerScriptService.Cassie)

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Config = require(ReplicatedStorage:WaitForChild("CassieConfig"))

-- Client'a anons gonderen remote
local remote = ReplicatedStorage:FindFirstChild("CassieAnnounce")
if not remote then
	remote = Instance.new("RemoteEvent")
	remote.Name = "CassieAnnounce"
	remote.Parent = ReplicatedStorage
end

local Cassie = {}

----------------------------------------------------------------
-- KUYRUK: anonslar ust uste binmez, oncelige gore siralanir
----------------------------------------------------------------
local PRIORITY = {info = 1, warning = 2, critical = 3}
local queue = {}
local order = 0
local running = false

local function runQueue()
	if running then return end
	running = true
	task.spawn(function()
		while #queue > 0 do
			table.sort(queue, function(a, b)
				if a.priority ~= b.priority then return a.priority > b.priority end
				return a.order < b.order
			end)
			local item = table.remove(queue, 1)
			remote:FireAllClients(item.text, item.kind)
			task.wait(item.duration + Config.GAP)
		end
		running = false
	end)
end

-- opts.kind: "info" | "warning" | "critical"   (varsayilan info)
-- opts.priority: sayi, buyuk olan once okunur  (varsayilan turun onceligi)
function Cassie.Announce(text, opts)
	if typeof(text) ~= "string" or text == "" then return end
	opts = opts or {}
	local kind = Config.KINDS[opts.kind] and opts.kind or "info"
	local _, duration = Config.Schedule(text)

	order += 1
	table.insert(queue, {
		text = text,
		kind = kind,
		priority = opts.priority or PRIORITY[kind],
		order = order,
		duration = duration,
	})
	runQueue()
end

-- Bekleyen anonslari siler (okunmakta olan bitene kadar devam eder)
function Cassie.Clear()
	table.clear(queue)
end

----------------------------------------------------------------
-- HAZIR ANONSLAR
----------------------------------------------------------------
function Cassie.RoundStart()
	Cassie.Announce("Dikkat. Tesis yönetimi tüm personeli göreve çağırıyor. Muhafaza protokolleri aktif.", {kind = "warning"})
end

-- unit: ör. "Epsilon-11, Dokuz Kuyruklu Tilki"
function Cassie.MTFArrival(unit, scpCount)
	local text
	if scpCount and scpCount > 0 then
		text = string.format("Mobil Görev Gücü, %s birimi, tesise giriş yaptı. Tespit edilen SCP sayısı: %d.", unit, scpCount)
	else
		text = string.format("Mobil Görev Gücü, %s birimi, tesise giriş yaptı. Tüm SCP nesneleri muhafaza altında.", unit)
	end
	Cassie.Announce(text, {kind = "info"})
end

function Cassie.ChaosAlert()
	Cassie.Announce("Dikkat. Yetkisiz silahlı personel tesise giriş yaptı. Güvenlik protokolü devrede.", {kind = "warning"})
end

function Cassie.Breach(scpName)
	Cassie.Announce(string.format("Dikkat. SCP %s muhafazayı ihlal etti.", scpName), {kind = "critical"})
end

function Cassie.SCPContained(scpName, unit)
	if unit and unit ~= "" then
		Cassie.Announce(string.format("SCP %s muhafaza edildi. Muhafaza birimi: %s.", scpName, unit), {kind = "info"})
	else
		Cassie.Announce(string.format("SCP %s muhafaza edildi.", scpName), {kind = "info"})
	end
end

function Cassie.SCPTerminated(scpName, cause)
	Cassie.Announce(string.format("SCP %s sonlandırıldı. Sebep: %s.", scpName, cause or "bilinmiyor"), {kind = "info"})
end

function Cassie.DecontWarning(minutes)
	Cassie.Announce(string.format("Hafif Muhafaza Bölgesi dekontaminasyonuna %d dakika kaldı. Tüm personel bölgeyi terk etsin.", minutes), {kind = "warning"})
end

function Cassie.DecontStart()
	Cassie.Announce("Hafif Muhafaza Bölgesi dekontaminasyonu başladı.", {kind = "critical"})
end

function Cassie.WarheadStart(seconds)
	Cassie.Announce(string.format("Alfa Savaş Başlığı başlatıldı. Patlamaya %d saniye. Tüm personel yüzeye çıksın.", seconds), {kind = "critical", priority = 10})
end

function Cassie.WarheadCancel()
	Cassie.Announce("Alfa Savaş Başlığı iptal edildi.", {kind = "warning", priority = 10})
end

function Cassie.WarheadDetonated()
	Cassie.Announce("Alfa Savaş Başlığı patladı. Tesis imha edildi.", {kind = "critical", priority = 10})
end

-- who: ör. "Tesis Komutanı Liewex"
function Cassie.VIPDead(who)
	Cassie.Announce(string.format("Dikkat. %s ölü bulundu.", who), {kind = "critical", priority = 5})
end

-- zone: bölge adı (yoksa nil)
function Cassie.ArmedDClass(zone)
	if zone and zone ~= "" then
		Cassie.Announce(string.format("Dikkat. %s bölgesinde silahlı D-Class tespit edildi.", zone), {kind = "warning", priority = 4})
	else
		Cassie.Announce("Dikkat. Silahlı D-Class tespit edildi.", {kind = "warning", priority = 4})
	end
end

print("[Cassie] hazir")

return Cassie
```

## CassieInit

*Script — ServerScriptService*

```lua
-- ServerScriptService icine "CassieInit" adiyla normal SCRIPT olarak koy.
-- Cassie modulunu baslatir ve adminler icin sohbet komutlari ekler:
--   /cassie <metin>        bilgi anonsu
--   /cassieuyari <metin>   uyari anonsu (turuncu)
--   /cassiekritik <metin>  acil durum anonsu (kirmizi)
--   /cassietest            hazir anonslari sirayla dener

local Players = game:GetService("Players")
local ServerScriptService = game:GetService("ServerScriptService")
local TextChatService = game:GetService("TextChatService")
local TextService = game:GetService("TextService")

local Cassie = require(ServerScriptService:WaitForChild("Cassie"))

-- AdminServer'daki IsAdmin attribute'unu kullanir; oyun sahibi de her zaman yetkilidir.
local function isAdmin(player)
	return player:GetAttribute("IsAdmin") == true or player.UserId == game.CreatorId
end

-- Admin'in yazdigi, herkese gosterilecek metni filtreler
local function filter(player, text)
	local ok, result = pcall(function()
		local f = TextService:FilterStringAsync(text, player.UserId, Enum.TextFilterContext.PublicChat)
		return f:GetNonChatStringForBroadcastAsync()
	end)
	if ok then return result end
	warn("[CassieInit] filtre hatasi: " .. tostring(result))
	return nil
end

local function makeCommand(alias, handler)
	local cmd = Instance.new("TextChatCommand")
	cmd.Name = "Cmd_" .. alias
	cmd.PrimaryAlias = "/" .. alias
	cmd.Parent = TextChatService
	cmd.Triggered:Connect(function(source, text)
		local player = Players:GetPlayerByUserId(source.UserId)
		if not player or not isAdmin(player) then return end
		local rest = string.match(text, "^%S+%s*(.*)$") or ""
		handler(player, rest)
	end)
end

local function textCommand(alias, kind)
	makeCommand(alias, function(player, rest)
		if rest == "" then return end
		rest = string.sub(rest, 1, 250)
		local clean = filter(player, rest)
		if clean then
			Cassie.Announce(clean, {kind = kind})
		end
	end)
end

textCommand("cassie", "info")
textCommand("cassieuyari", "warning")
textCommand("cassiekritik", "critical")

makeCommand("cassietest", function()
	Cassie.RoundStart()
	Cassie.MTFArrival("Epsilon-11, Dokuz Kuyruklu Tilki", 3)
	Cassie.SCPContained("173", "MTF Epsilon-11")
	Cassie.DecontWarning(5)
	Cassie.WarheadStart(90)
end)

print("[CassieInit] hazir")
```

## CassieEvents

*Script — ServerScriptService*

```lua
-- ServerScriptService icine "CassieEvents" adiyla normal SCRIPT olarak koy.
-- Otomatik CASSIE duyurulari:
--   1) Onemli kisi (ornek: "Tesis Komutanı|Liewex") olunce
--   2) Kaos / GOC tesise girince
--   3) Rutbeli (NTF Albayi, Kaos Komutani ...) tesise girince
--   4) Bir oyuncu silahli D-Class gorunce
-- Tum ayarlar CassieConfig > Config.EVENTS icinde.

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerScriptService = game:GetService("ServerScriptService")
local TextService = game:GetService("TextService")

local Config = require(ReplicatedStorage:WaitForChild("CassieConfig"))
local Cassie = require(ServerScriptService:WaitForChild("Cassie"))
local E = Config.EVENTS

----------------------------------------------------------------
-- YARDIMCI FONKSIYONLAR
----------------------------------------------------------------
local function trimLower(s)
	s = string.lower(s)
	s = string.gsub(s, "^%s+", "")
	s = string.gsub(s, "%s+$", "")
	return s
end

-- Herkese gosterilecek ismi filtreler; basarisizsa nil doner
local function filterPublic(player, text)
	local ok, result = pcall(function()
		local f = TextService:FilterStringAsync(text, player.UserId, Enum.TextFilterContext.PublicChat)
		return f:GetNonChatStringForBroadcastAsync()
	end)
	if ok and result then return result end
	warn("[CassieEvents] filtre hatasi: " .. tostring(result))
	return nil
end

local function isAlive(player)
	local char = player.Character
	local hum = char and char:FindFirstChildOfClass("Humanoid")
	return hum ~= nil and hum.Health > 0
end

local function teamName(player)
	return player.Team and player.Team.Name or nil
end

----------------------------------------------------------------
-- 1) ONEMLI KISI OLUMU
----------------------------------------------------------------
local function isVIP(player)
	local name = player:GetAttribute("RPName")
	if typeof(name) == "string" then
		local title = string.match(name, "^(.-)|") or name
		title = trimLower(title)
		for _, t in ipairs(E.VIP_TITLES) do
			if trimLower(t) == title then return true end
		end
	end

	if E.VIP_MIN_LEVEL and E.VIP_MIN_LEVEL > 0 then
		local level = player:GetAttribute("RPLevel")
		if typeof(level) == "string" then
			local n = tonumber(string.match(level, "%d+"))
			if n and n >= E.VIP_MIN_LEVEL then return true end
		end
	end
	return false
end

local function hookDeath(player, char)
	local hum = char:WaitForChild("Humanoid", 10)
	if not hum then return end

	hum.Died:Connect(function()
		if not isVIP(player) then return end
		local rawName = player:GetAttribute("RPName") or player.DisplayName
		-- "Tesis Komutanı|Liewex" -> "Tesis Komutanı Liewex"
		local spoken = string.gsub(rawName, "%s*|%s*", " ")

		task.delay(E.VIP_DEATH_DELAY, function()
			local safe = filterPublic(player, spoken) or player.DisplayName
			Cassie.VIPDead(safe)
		end)
	end)
end

----------------------------------------------------------------
-- 2 + 3) TESISE GIRIS / RUTBELI GIRISI
----------------------------------------------------------------
local lastArrival = {}

local function tryArrival(key, cfg)
	local now = os.clock()
	if lastArrival[key] and now - lastArrival[key] < cfg.cooldown then return end
	lastArrival[key] = now
	Cassie.Announce(cfg.text, {kind = cfg.kind or "warning"})
end

-- Turkce buyuk harf (i -> İ, ı -> I ...); string.upper bunu dogru yapmaz
local TR_UPPER = {["i"] = "İ", ["ı"] = "I", ["ç"] = "Ç", ["ğ"] = "Ğ", ["ö"] = "Ö", ["ş"] = "Ş", ["ü"] = "Ü"}

local function trUpper(s)
	local ok, result = pcall(function()
		local out = {}
		for _, cp in utf8.codes(s) do
			local ch = utf8.char(cp)
			table.insert(out, TR_UPPER[ch] or string.upper(ch))
		end
		return table.concat(out)
	end)
	return ok and result or string.upper(s)
end

local lastRank = {}

-- Rutbeli biri girince admin'in verdigi isimle anons yapar
local function announceRank(player, rankCfg)
	local R = E.RANK_ARRIVALS
	local now = os.clock()
	if lastRank[player] and now - lastRank[player] < R.cooldown then return end
	lastRank[player] = now

	local who
	local rawName = player:GetAttribute("RPName")
	if typeof(rawName) == "string" and rawName ~= "" then
		-- "Tesis Teğmeni|Liewex" -> "Tesis Teğmeni Liewex"
		who = string.gsub(rawName, "%s*|%s*", " ")
	else
		who = rankCfg.title .. " " .. player.DisplayName
	end

	who = filterPublic(player, who) or player.DisplayName

	local text = string.format(R.template, who)
	if R.uppercase then text = trUpper(text) end
	Cassie.Announce(text, {kind = R.kind or "warning", priority = 4})
end

Players.PlayerRemoving:Connect(function(p) lastRank[p] = nil end)

local function checkArrivals(player)
	local team = teamName(player)
	-- Lobi / izleyici takimindaki dogumlar "tesise giris" sayilmaz
	if not team or team == "Lobby" or team == "Spectator" then return end

	local teamCfg = E.TEAM_ARRIVALS[team]
	if teamCfg then
		tryArrival("team:" .. team, teamCfg)
	end

	local roleKey = player:GetAttribute("RoleKey")
	local rankCfg = roleKey and E.RANK_ARRIVALS.roles[roleKey]
	if rankCfg and rankCfg.team == team then
		announceRank(player, rankCfg)
	end
end

----------------------------------------------------------------
-- OYUNCU BAGLANTILARI
----------------------------------------------------------------
local function onPlayer(player)
	player.CharacterAdded:Connect(function(char)
		hookDeath(player, char)
		checkArrivals(player)
	end)
	if player.Character then
		hookDeath(player, player.Character)
	end
end

Players.PlayerAdded:Connect(onPlayer)
for _, p in ipairs(Players:GetPlayers()) do onPlayer(p) end

----------------------------------------------------------------
-- 4) SILAHLI D-CLASS
----------------------------------------------------------------
local A = E.ARMED_D

local witnessTeams = {}
for _, t in ipairs(A.witnessTeams) do witnessTeams[t] = true end
local minDot = math.cos(math.rad(A.viewAngle / 2))

local function hasWeaponInHand(char)
	for _, child in ipairs(char:GetChildren()) do
		if child:IsA("Tool") and (child:GetAttribute("IsWeapon") == true or table.find(A.weapons, child.Name)) then
			return true
		end
	end
	return false
end

-- Taniğin gorus acisi, mesafesi ve engel olup olmadigi
local function canSee(observer, target)
	local oChar, tChar = observer.Character, target.Character
	local oHead = oChar and oChar:FindFirstChild("Head")
	local tHead = tChar and tChar:FindFirstChild("Head")
	if not oHead or not tHead then return false end

	local offset = tHead.Position - oHead.Position
	local dist = offset.Magnitude
	if dist > A.range then return false end
	if dist > 0.1 and offset.Unit:Dot(oHead.CFrame.LookVector) < minDot then return false end

	local params = RaycastParams.new()
	params.FilterDescendantsInstances = {oChar, tChar}
	params.FilterType = Enum.RaycastFilterType.Exclude
	return workspace:Raycast(oHead.Position, offset, params) == nil
end

-- Istege bagli: Workspace > Zones klasorundeki buyuk Part'larin adi bolge adi olur
local function getZone(position)
	local zones = workspace:FindFirstChild("Zones")
	if not zones then return nil end
	for _, part in ipairs(zones:GetChildren()) do
		if part:IsA("BasePart") then
			local rel = part.CFrame:PointToObjectSpace(position)
			local half = part.Size / 2
			if math.abs(rel.X) <= half.X and math.abs(rel.Y) <= half.Y and math.abs(rel.Z) <= half.Z then
				return part.Name
			end
		end
	end
	return nil
end

local lastGlobal = -math.huge
local lastPerPlayer = {}

local function scanArmedD()
	local now = os.clock()
	if now - lastGlobal < A.globalCooldown then return end

	for _, d in ipairs(Players:GetPlayers()) do
		if teamName(d) == A.dTeam and isAlive(d) and hasWeaponInHand(d.Character) then
			local last = lastPerPlayer[d]
			if not last or now - last >= A.perPlayerCooldown then
				for _, w in ipairs(Players:GetPlayers()) do
					if w ~= d and witnessTeams[teamName(w) or ""] and isAlive(w) and canSee(w, d) then
						lastGlobal = now
						lastPerPlayer[d] = now
						local root = d.Character:FindFirstChild("HumanoidRootPart")
						Cassie.ArmedDClass(root and getZone(root.Position) or nil)
						return
					end
				end
			end
		end
	end
end

Players.PlayerRemoving:Connect(function(p) lastPerPlayer[p] = nil end)

if A.enabled then
	task.spawn(function()
		while true do
			task.wait(A.scanInterval)
			local ok, err = pcall(scanArmedD)
			if not ok then warn("[CassieEvents] tarama hatasi: " .. tostring(err)) end
		end
	end)
end

print("[CassieEvents] hazir")
```

## CassieClient

*LocalScript — StarterPlayer > StarterPlayerScripts*

```lua
-- StarterPlayer > StarterPlayerScripts icine "CassieClient" adiyla LOCALSCRIPT olarak koy.

print("[CassieClient] basladi")

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")
local SoundService = game:GetService("SoundService")
local Debris = game:GetService("Debris")

local player = Players.LocalPlayer
local Config = require(ReplicatedStorage:WaitForChild("CassieConfig"))

----------------------------------------------------------------
-- ARAYUZ
----------------------------------------------------------------
local gui = Instance.new("ScreenGui")
gui.Name = "Cassie"
gui.ResetOnSpawn = false
gui.IgnoreGuiInset = true
gui.DisplayOrder = 100
gui.Parent = player:WaitForChild("PlayerGui")

local HIDDEN_POS = UDim2.new(0.5, -310, 0, -140)
local SHOWN_POS = UDim2.new(0.5, -310, 0, 100) -- HUD'daki round kutusunun altinda

local frame = Instance.new("Frame")
frame.Size = UDim2.fromOffset(620, 110)
frame.Position = HIDDEN_POS
frame.BackgroundColor3 = Color3.fromRGB(18, 20, 26)
frame.BackgroundTransparency = 0.08
frame.Visible = false
frame.Parent = gui
Instance.new("UICorner", frame).CornerRadius = UDim.new(0, 8)

local stroke = Instance.new("UIStroke")
stroke.Thickness = 2
stroke.Parent = frame

local accent = Instance.new("Frame")
accent.Size = UDim2.new(0, 6, 1, 0)
accent.BorderSizePixel = 0
accent.Parent = frame
Instance.new("UICorner", accent).CornerRadius = UDim.new(0, 8)

local header = Instance.new("TextLabel")
header.Size = UDim2.new(1, -30, 0, 22)
header.Position = UDim2.fromOffset(20, 8)
header.BackgroundTransparency = 1
header.TextXAlignment = Enum.TextXAlignment.Left
header.Font = Enum.Font.GothamBold
header.TextSize = 14
header.Parent = frame

local body = Instance.new("TextLabel")
body.Size = UDim2.new(1, -36, 1, -40)
body.Position = UDim2.fromOffset(20, 32)
body.BackgroundTransparency = 1
body.TextXAlignment = Enum.TextXAlignment.Left
body.TextYAlignment = Enum.TextYAlignment.Top
body.TextWrapped = true
body.Font = Enum.Font.Gotham
body.TextSize = 19
body.TextColor3 = Color3.fromRGB(240, 240, 245)
body.Text = ""
body.Parent = frame

----------------------------------------------------------------
-- SES
----------------------------------------------------------------
local function playSound(id)
	if typeof(id) ~= "string" or id == "" then return end
	local s = Instance.new("Sound")
	s.SoundId = id
	s.Volume = Config.VOLUME
	s.Parent = SoundService
	s:Play()
	Debris:AddItem(s, 15)
end

----------------------------------------------------------------
-- ANONS GOSTERIMI
----------------------------------------------------------------
local token = 0

local function slide(show)
	if show then frame.Visible = true end
	local tween = TweenService:Create(
		frame,
		TweenInfo.new(0.35, Enum.EasingStyle.Quad, Enum.EasingDirection.Out),
		{Position = show and SHOWN_POS or HIDDEN_POS}
	)
	tween:Play()
	if not show then
		tween.Completed:Once(function()
			-- yeni bir anons baslamadiysa gizle
			if frame.Position == HIDDEN_POS then frame.Visible = false end
		end)
	end
end

local function show(text, kind)
	token += 1
	local myToken = token

	local style = Config.KINDS[kind] or Config.KINDS.info
	stroke.Color = style.color
	accent.BackgroundColor3 = style.color
	header.TextColor3 = style.color
	header.Text = "CASSIE  ·  " .. style.label
	body.Text = ""

	local words = Config.Schedule(text)
	slide(true)
	playSound(Config.BELL_ID)

	task.spawn(function()
		task.wait(Config.START_DELAY)
		local shown = {}
		for _, w in ipairs(words) do
			if myToken ~= token then return end -- yeni anons geldi
			table.insert(shown, w.text)
			body.Text = table.concat(shown, " ")
			playSound(Config.WORD_SOUNDS[w.key])
			task.wait(w.delay)
		end
		task.wait(Config.END_PADDING)
		if myToken == token then slide(false) end
	end)
end

----------------------------------------------------------------
-- SERVER BAGLANTISI
----------------------------------------------------------------
task.spawn(function()
	local remote = ReplicatedStorage:WaitForChild("CassieAnnounce", 15)
	if not remote then
		warn("[CassieClient] CassieAnnounce bulunamadi - CassieInit/Cassie server'da calismiyor")
		return
	end
	remote.OnClientEvent:Connect(show)
	print("[CassieClient] server baglandi")
end)
```

## HudClient

*LocalScript — StarterPlayer > StarterPlayerScripts*

```lua
-- StarterPlayer > StarterPlayerScripts icine "HudClient" adiyla LOCALSCRIPT olarak koy.
-- Icerik: round durumu, geri sayim, dalga suresi, can, kart seviyesi, rol ekrani (5 sn),
-- izleyici bilgisi ve round sonu sonuc ekrani. Tum arayuz kodla uretilir.

print("[HudClient] basladi")

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")
local StarterGui = game:GetService("StarterGui")

local player = Players.LocalPlayer

----------------------------------------------------------------
-- AYARLAR
----------------------------------------------------------------
local ROLE_SCREEN_TIME = 5   -- rol ekrani suresi (sn)
local RESULT_FADE = 0.5

local BG = Color3.fromRGB(18, 20, 26)
local PANEL = Color3.fromRGB(28, 31, 40)
local TEXT = Color3.fromRGB(240, 240, 245)
local MUTED = Color3.fromRGB(150, 155, 170)
local GREEN = Color3.fromRGB(80, 200, 120)
local RED = Color3.fromRGB(235, 70, 70)
local YELLOW = Color3.fromRGB(255, 220, 100)
local BLUE = Color3.fromRGB(90, 160, 255)

-- Takim adi -> oyuncuya gosterilecek hedef cumlesi (istedigin gibi degistir)
local OBJECTIVES = {
	["Class-D"] = "Tesisten kaç. Silah ve kart bul, hayatta kal.",
	["Scientist"] = "Hayatta kal ve tesisten kaç. Güvenlik personeline yakın dur.",
	["Facility Guard"] = "Bilim insanlarını koru, SCP'leri muhafaza et.",
	["SCP"] = "Muhafazadan çık ve tesisteki herkesi etkisiz hale getir.",
	["MTF"] = "SCP'leri muhafaza et ve hayatta kalan personeli kurtar.",
	["Chaos Insurgency"] = "D-Class'ları kurtar ve Vakıf personelini etkisiz hale getir.",
	["GOC"] = "Anormal tehditleri tespit et ve yok et.",
	["GOI"] = "Kendi hedefin için tesise sız.",
	["Serpent's Hand"] = "SCP'leri koru ve Vakıf'a karşı çalış.",
}

-- Rol adi yoksa takim adindan gosterilecek ad
local TEAM_NAMES = {
	["Class-D"] = "D-Class",
	["Scientist"] = "Bilim Adamı",
	["Facility Guard"] = "Güvenlik Personeli",
	["MTF"] = "NTF",
	["Chaos Insurgency"] = "Kaos İsyancıları",
}

local RESULTS = {
	Foundation = {title = "VAKIF KAZANDI", color = BLUE},
	SCP = {title = "SCP'LER KAZANDI", color = RED},
	Chaos = {title = "KAOS İSYANCILARI KAZANDI", color = Color3.fromRGB(255, 170, 60)},
	Timeout = {title = "SÜRE DOLDU", color = YELLOW},
	Draw = {title = "BERABERLİK", color = MUTED},
}

local PHASE_STYLE = {
	Lobby = {"LOBİ", MUTED},
	Intermission = {"ROUND BAŞLIYOR", YELLOW},
	Round = {"ROUND", GREEN},
	Ended = {"ROUND BİTTİ", RED},
}

local KEYCARD_COLORS = {
	[1] = Color3.fromRGB(200, 200, 210),
	[2] = Color3.fromRGB(90, 200, 110),
	[3] = Color3.fromRGB(255, 200, 70),
	[4] = Color3.fromRGB(255, 130, 50),
	[5] = Color3.fromRGB(235, 70, 70),
}

----------------------------------------------------------------
-- TURKCE YARDIMCILAR ("Sen X'sin" cumlesi icin)
----------------------------------------------------------------
local TR_LOWER = {["İ"] = "i", ["I"] = "ı", ["Ç"] = "ç", ["Ğ"] = "ğ", ["Ö"] = "ö", ["Ş"] = "ş", ["Ü"] = "ü"}
local VOWEL_SUFFIX = {
	["a"] = "sın", ["ı"] = "sın", ["e"] = "sin", ["i"] = "sin",
	["o"] = "sun", ["u"] = "sun", ["ö"] = "sün", ["ü"] = "sün",
}

local function trLower(s)
	local out = {}
	for _, cp in utf8.codes(s) do
		local ch = utf8.char(cp)
		table.insert(out, TR_LOWER[ch] or string.lower(ch))
	end
	return table.concat(out)
end

-- "NTF Çavuşu" -> "Sen NTF Çavuşu'sun"; kisaltmalar (NTF, GOC, SCP) -> "...'sin"
local function youAre(roleName)
	local lastWord = string.match(roleName, "(%S+)%s*$") or roleName
	local suffix = "sin"
	local isAcronym = string.find(lastWord, "%l") == nil and #lastWord <= 4
	if not isAcronym then
		local lastVowel
		for _, cp in utf8.codes(trLower(lastWord)) do
			local ch = utf8.char(cp)
			if VOWEL_SUFFIX[ch] then lastVowel = ch end
		end
		if lastVowel then suffix = VOWEL_SUFFIX[lastVowel] end
	end
	return "Sen " .. roleName .. "'" .. suffix
end

local function fmt(seconds)
	seconds = math.max(0, math.floor(seconds or 0))
	return string.format("%d:%02d", seconds // 60, seconds % 60)
end

----------------------------------------------------------------
-- ARAYUZ YARDIMCILARI
----------------------------------------------------------------
local function make(class, props, parent)
	local o = Instance.new(class)
	for k, v in pairs(props) do o[k] = v end
	o.Parent = parent
	return o
end

local function corner(obj, r)
	make("UICorner", {CornerRadius = UDim.new(0, r or 8)}, obj)
end

local function label(parent, props)
	local l = Instance.new("TextLabel")
	l.BackgroundTransparency = 1
	l.Font = Enum.Font.Gotham
	l.TextColor3 = TEXT
	l.TextSize = 14
	l.TextXAlignment = Enum.TextXAlignment.Center
	for k, v in pairs(props) do l[k] = v end
	l.Parent = parent
	return l
end

local gui = make("ScreenGui", {
	Name = "Hud", ResetOnSpawn = false, IgnoreGuiInset = true, DisplayOrder = 10,
}, player:WaitForChild("PlayerGui"))

-- Varsayilan Roblox arayuzlerini kapat (can cubugu bizde var)
local HIDE_ROBLOX_BACKPACK = true -- false yaparsan Roblox'un esya cubugu geri gelir

task.spawn(function()
	for _ = 1, 3 do
		pcall(function()
			StarterGui:SetCoreGuiEnabled(Enum.CoreGuiType.Health, false)
			if HIDE_ROBLOX_BACKPACK then
				StarterGui:SetCoreGuiEnabled(Enum.CoreGuiType.Backpack, false)
			end
		end)
		task.wait(1)
	end
end)

----------------------------------------------------------------
-- 1) UST ORTA: ROUND DURUMU
----------------------------------------------------------------
local topPill = make("Frame", {
	AnchorPoint = Vector2.new(0.5, 0), Position = UDim2.new(0.5, 0, 0, 12),
	Size = UDim2.fromOffset(340, 78), BackgroundColor3 = PANEL, BackgroundTransparency = 0.1,
}, gui)
corner(topPill, 10)
make("UIStroke", {Color = Color3.fromRGB(60, 65, 80), Thickness = 1}, topPill)

local phaseLabel = label(topPill, {
	Position = UDim2.fromOffset(0, 6), Size = UDim2.new(1, 0, 0, 16),
	Font = Enum.Font.GothamBold, TextSize = 12,
})
local timerLabel = label(topPill, {
	Position = UDim2.fromOffset(0, 22), Size = UDim2.new(1, 0, 0, 34),
	Font = Enum.Font.GothamBold, TextSize = 28,
})
local subLabel = label(topPill, {
	Position = UDim2.fromOffset(0, 57), Size = UDim2.new(1, 0, 0, 16),
	TextSize = 12, TextColor3 = MUTED,
})

----------------------------------------------------------------
-- 2) SAG ALT: KART SEVIYESI + CAN
----------------------------------------------------------------
local bottomRight = make("Frame", {
	AnchorPoint = Vector2.new(1, 1), Position = UDim2.new(1, -16, 1, -16),
	Size = UDim2.fromOffset(280, 76), BackgroundTransparency = 1,
}, gui)

-- Kart satiri
local cardRow = make("Frame", {
	Size = UDim2.new(1, 0, 0, 34), BackgroundColor3 = PANEL, BackgroundTransparency = 0.1,
}, bottomRight)
corner(cardRow, 8)

label(cardRow, {
	Position = UDim2.fromOffset(12, 0), Size = UDim2.fromOffset(40, 34),
	Text = "KART", Font = Enum.Font.GothamBold, TextSize = 12, TextColor3 = MUTED,
	TextXAlignment = Enum.TextXAlignment.Left,
})

local pips = {}
for i = 1, 5 do
	local pip = make("Frame", {
		Position = UDim2.fromOffset(58 + (i - 1) * 26, 13), Size = UDim2.fromOffset(22, 8),
		BackgroundColor3 = Color3.fromRGB(55, 60, 75), BorderSizePixel = 0,
	}, cardRow)
	corner(pip, 3)
	pips[i] = pip
end

local cardText = label(cardRow, {
	Position = UDim2.new(1, -92, 0, 0), Size = UDim2.fromOffset(80, 34),
	Font = Enum.Font.GothamBold, TextSize = 12, TextXAlignment = Enum.TextXAlignment.Right,
})

-- Can satiri
local healthRow = make("Frame", {
	Position = UDim2.fromOffset(0, 42), Size = UDim2.new(1, 0, 0, 34),
	BackgroundColor3 = PANEL, BackgroundTransparency = 0.1, ClipsDescendants = true,
}, bottomRight)
corner(healthRow, 8)

local healthFill = make("Frame", {
	Size = UDim2.fromScale(1, 1), BackgroundColor3 = GREEN, BorderSizePixel = 0, BackgroundTransparency = 0.35,
}, healthRow)

local healthText = label(healthRow, {
	Size = UDim2.fromScale(1, 1), Font = Enum.Font.GothamBold, TextSize = 15, Text = "100",
})
label(healthRow, {
	Position = UDim2.fromOffset(12, 0), Size = UDim2.fromOffset(40, 34),
	Text = "CAN", Font = Enum.Font.GothamBold, TextSize = 12, TextXAlignment = Enum.TextXAlignment.Left,
})

----------------------------------------------------------------
-- 3) IZLEYICI BILGISI
----------------------------------------------------------------
local specFrame = make("Frame", {
	AnchorPoint = Vector2.new(0.5, 1), Position = UDim2.new(0.5, 0, 1, -110),
	Size = UDim2.fromOffset(340, 40), BackgroundColor3 = PANEL, BackgroundTransparency = 0.1,
	Visible = false,
}, gui)
corner(specFrame, 8)
local specLabel = label(specFrame, {
	Size = UDim2.fromScale(1, 1), Font = Enum.Font.GothamBold, TextSize = 14,
})

----------------------------------------------------------------
-- 4) ROL EKRANI
----------------------------------------------------------------
local roleCard = make("CanvasGroup", {
	AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.new(0.5, 0, 0.34, 0),
	Size = UDim2.fromOffset(580, 200), BackgroundColor3 = BG, BackgroundTransparency = 0.05,
	GroupTransparency = 1, Visible = false,
}, gui)
corner(roleCard, 12)

local roleAccent = make("Frame", {Size = UDim2.new(1, 0, 0, 5), BorderSizePixel = 0}, roleCard)
local roleKicker = label(roleCard, {
	Position = UDim2.fromOffset(0, 18), Size = UDim2.new(1, 0, 0, 16),
	Text = "ROLÜN", Font = Enum.Font.GothamBold, TextSize = 13,
})
local roleMain = label(roleCard, {
	Position = UDim2.fromOffset(20, 40), Size = UDim2.new(1, -40, 0, 52),
	Font = Enum.Font.GothamBold, TextScaled = true,
})
make("UITextSizeConstraint", {MaxTextSize = 36, MinTextSize = 16}, roleMain)
local roleSub = label(roleCard, {
	Position = UDim2.fromOffset(20, 98), Size = UDim2.new(1, -40, 0, 22), TextSize = 16,
})
local roleGoal = label(roleCard, {
	Position = UDim2.fromOffset(30, 130), Size = UDim2.new(1, -60, 0, 56),
	TextSize = 15, TextColor3 = MUTED, TextWrapped = true, TextYAlignment = Enum.TextYAlignment.Top,
})

local roleToken = 0

local function showRole()
	local team = player.Team
	if not team or team.Name == "Lobby" or team.Name == "Spectator" then return end

	roleToken += 1
	local myToken = roleToken

	local roleName = player:GetAttribute("RoleName") or TEAM_NAMES[team.Name] or team.Name
	local ok, text = pcall(youAre, roleName)
	if not ok then text = "Sen " .. roleName end

	local color = team.TeamColor.Color
	-- cok koyu takim renkleri (Kaos: siyah) okunmaz; aciklastir
	if color.R + color.G + color.B < 0.45 then color = Color3.fromRGB(190, 190, 200) end

	roleAccent.BackgroundColor3 = color
	roleKicker.TextColor3 = color
	roleMain.Text = text

	local parts = {}
	local rpName = player:GetAttribute("RPName")
	local level = player:GetAttribute("RPLevel") or player:GetAttribute("RoleLevel")
	if typeof(rpName) == "string" and rpName ~= "" then
		table.insert(parts, (string.gsub(rpName, "%s*|%s*", " ")))
	end
	if level then table.insert(parts, tostring(level)) end
	roleSub.Text = table.concat(parts, "   ·   ")
	roleGoal.Text = OBJECTIVES[team.Name] or ""

	roleCard.Visible = true
	TweenService:Create(roleCard, TweenInfo.new(0.4), {GroupTransparency = 0}):Play()

	task.delay(ROLE_SCREEN_TIME, function()
		if myToken ~= roleToken then return end
		local tween = TweenService:Create(roleCard, TweenInfo.new(0.5), {GroupTransparency = 1})
		tween:Play()
		tween.Completed:Once(function()
			if myToken == roleToken then roleCard.Visible = false end
		end)
	end)
end

----------------------------------------------------------------
-- 5) ROUND SONU SONUC EKRANI
----------------------------------------------------------------
local resultOverlay = make("CanvasGroup", {
	Size = UDim2.fromScale(1, 1), BackgroundColor3 = Color3.new(0, 0, 0), BackgroundTransparency = 0.35,
	GroupTransparency = 1, Visible = false, ZIndex = 20,
}, gui)

local resAccent = make("Frame", {
	AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.new(0.5, 0, 0.5, -70),
	Size = UDim2.fromOffset(420, 4), BorderSizePixel = 0,
}, resultOverlay)

local resTitle = label(resultOverlay, {
	AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.new(0.5, 0, 0.5, -20),
	Size = UDim2.fromOffset(900, 70), Font = Enum.Font.GothamBold, TextSize = 52,
})
local resSub = label(resultOverlay, {
	AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.new(0.5, 0, 0.5, 38),
	Size = UDim2.fromOffset(700, 28), TextSize = 20, TextColor3 = TEXT,
})
local resMe = label(resultOverlay, {
	AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.new(0.5, 0, 0.5, 84),
	Size = UDim2.fromOffset(400, 28), Font = Enum.Font.GothamBold, TextSize = 18,
})

local currentHum = nil
local state = nil

local function isAlive()
	local team = player.Team
	if not team or team.Name == "Spectator" or team.Name == "Lobby" then return false end
	return currentHum ~= nil and currentHum.Health > 0
end

local function showResult()
	if not state then return end
	local res = RESULTS[state:GetAttribute("Result") or ""] or RESULTS.Draw
	resTitle.Text = res.title
	resTitle.TextColor3 = res.color
	resAccent.BackgroundColor3 = res.color
	resSub.Text = string.format(
		"Hayatta kalan: %d   ·   Round süresi: %s",
		state:GetAttribute("Survivors") or 0,
		fmt(state:GetAttribute("Duration") or 0)
	)
	local alive = isAlive()
	resMe.Text = alive and "HAYATTA KALDIN" or "ÖLDÜN"
	resMe.TextColor3 = alive and GREEN or RED

	resultOverlay.Visible = true
	TweenService:Create(resultOverlay, TweenInfo.new(RESULT_FADE), {GroupTransparency = 0}):Play()
end

local function hideResult()
	if not resultOverlay.Visible then return end
	local tween = TweenService:Create(resultOverlay, TweenInfo.new(RESULT_FADE), {GroupTransparency = 1})
	tween:Play()
	tween.Completed:Once(function()
		if resultOverlay.GroupTransparency >= 0.99 then resultOverlay.Visible = false end
	end)
end

----------------------------------------------------------------
-- GUNCELLEME FONKSIYONLARI
----------------------------------------------------------------
local function refreshSpectator()
	local isSpec = player.Team ~= nil and player.Team.Name == "Spectator"
	local phase = state and state:GetAttribute("Phase")
	specFrame.Visible = isSpec and phase == "Round"
	if specFrame.Visible then
		specLabel.Text = "İZLEYİCİSİN   ·   Sonraki dalga " .. fmt(state:GetAttribute("NextWave"))
	end
end

local function refreshTop()
	if not state then
		phaseLabel.Text = "ROUND"
		phaseLabel.TextColor3 = MUTED
		timerLabel.TextSize = 28
		timerLabel.Text = "--:--"
		subLabel.Text = "Round sistemi bulunamadı"
		return
	end

	local phase = state:GetAttribute("Phase") or "Lobby"
	local style = PHASE_STYLE[phase] or PHASE_STYLE.Lobby
	phaseLabel.Text = style[1]
	phaseLabel.TextColor3 = style[2]
	timerLabel.TextSize = 28

	if phase == "Lobby" then
		timerLabel.TextSize = 20
		timerLabel.Text = "Oyuncu bekleniyor"
		subLabel.Text = string.format("%d / %d oyuncu", state:GetAttribute("PlayerCount") or 0, state:GetAttribute("MinPlayers") or 0)
	elseif phase == "Intermission" then
		timerLabel.Text = fmt(state:GetAttribute("TimeLeft"))
		subLabel.Text = "Hazırlan"
	elseif phase == "Round" then
		timerLabel.Text = fmt(state:GetAttribute("TimeLeft"))
		subLabel.Text = "Sonraki dalga   " .. fmt(state:GetAttribute("NextWave"))
	else
		timerLabel.TextSize = 20
		timerLabel.Text = "Sonuçlar"
		subLabel.Text = ""
	end
	refreshSpectator()
end

local function updateHealth()
	local hum = currentHum
	if not hum then
		healthFill.Size = UDim2.fromScale(0, 1)
		healthText.Text = "0"
		return
	end
	local ratio = math.clamp(hum.Health / math.max(hum.MaxHealth, 1), 0, 1)
	healthFill.Size = UDim2.fromScale(ratio, 1)
	healthFill.BackgroundColor3 = RED:Lerp(GREEN, ratio)
	healthText.Text = tostring(math.ceil(hum.Health))
end

local function renderKeycard(level)
	for i, pip in ipairs(pips) do
		pip.BackgroundColor3 = (i <= level) and KEYCARD_COLORS[level] or Color3.fromRGB(55, 60, 75)
	end
	if level > 0 then
		cardText.Text = "SEVİYE " .. level
		cardText.TextColor3 = KEYCARD_COLORS[level]
	else
		cardText.Text = "KART YOK"
		cardText.TextColor3 = MUTED
	end
end

-- Elindeki / cantasindaki en yuksek kart seviyesi.
-- Tool adi "Keycard1".."Keycard5" olmali (ya da Tool'a KeycardLevel attribute'u ver).
local function keycardLevel()
	local best = 0
	local function scan(container)
		if not container then return end
		for _, item in ipairs(container:GetChildren()) do
			if item:IsA("Tool") then
				local lvl = item:GetAttribute("KeycardLevel") or tonumber(string.match(item.Name, "^Keycard(%d+)$"))
				if typeof(lvl) == "number" and lvl > best then best = lvl end
			end
		end
	end
	scan(player.Character)
	scan(player:FindFirstChildOfClass("Backpack"))
	return math.min(best, 5)
end

----------------------------------------------------------------
-- BAGLANTILAR
----------------------------------------------------------------
local function onCharacter(char)
	local hum = char:WaitForChild("Humanoid", 10)
	if not hum then return end
	currentHum = hum
	updateHealth()
	hum.HealthChanged:Connect(updateHealth)
	hum:GetPropertyChangedSignal("MaxHealth"):Connect(updateHealth)
	task.delay(0.8, showRole) -- rol bilgisi (attribute) gelsin diye kisa bekleme
end

player.CharacterAdded:Connect(onCharacter)
if player.Character then task.spawn(onCharacter, player.Character) end

player:GetPropertyChangedSignal("Team"):Connect(refreshSpectator)

-- Kart seviyesi: 0.4 sn'de bir bakar, sadece degisince cizer
task.spawn(function()
	local shown = -1
	while true do
		local level = keycardLevel()
		if level ~= shown then
			shown = level
			renderKeycard(level)
		end
		task.wait(0.4)
	end
end)

-- Round durumu (RoundManager yayinlar)
state = ReplicatedStorage:WaitForChild("RoundState", 10)
if state then
	state.AttributeChanged:Connect(function(name)
		refreshTop()
		if name == "Phase" then
			if state:GetAttribute("Phase") == "Ended" then showResult() else hideResult() end
		end
	end)
	if state:GetAttribute("Phase") == "Ended" then showResult() end
else
	warn("[HudClient] RoundState bulunamadi - RoundManager (yeni surum) calismiyor")
end

renderKeycard(0)
updateHealth()
refreshTop()
```
