-- ServerScriptService icine "AdminServer" adiyla normal SCRIPT olarak koy.
-- Eski "AdminRoleSystem" scriptini SIL (yerine bu geciyor).

local Players = game:GetService("Players")
local Teams = game:GetService("Teams")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")

----------------------------------------------------------------
-- AYARLAR
----------------------------------------------------------------
local ADMINS = {
	-- 123456789, -- admin UserId'lerini buraya yaz (oyun sahibi otomatik admin)
}
local MIN_BOY, MAX_BOY = 0.5, 2

----------------------------------------------------------------
-- ROLLER
-- icon: rol simgesi (henuz yapilmadi, hazir olunca "rbxassetid://123" yaz)
-- level: admin bos birakirsa gorunecek varsayilan yetki seviyesi
----------------------------------------------------------------
local ROLE_ORDER = {
	"d_class", "bilimadami", "guvenlik",
	"ntf_uzman", "ntf_cavus", "ntf_albay",
	"kaos_acemi", "kaos_piyade", "kaos_akinci", "kaos_komutan",
	"goc", "goi", "yilanin_eli",
}

local ROLES = {
	d_class      = {name = "D-Class",                   team = "Class-D",          color = "Deep orange", health = 100, speed = 16, spawn = "ClassD",       level = "0. Seviye Personel", icon = "", tools = {}},
	bilimadami   = {name = "Bilim Adamı",               team = "Scientist",        color = "Bright yellow", health = 100, speed = 16, spawn = "Scientist",  level = "2. Seviye Personel", icon = "", tools = {"Keycard2"}},
	guvenlik     = {name = "Güvenlik Personeli",        team = "Facility Guard",   color = "Dark blue",   health = 120, speed = 16, spawn = "Guard",        level = "2. Seviye Personel", icon = "", tools = {"Keycard2", "Pistol"}},
	ntf_uzman    = {name = "NTF Uzmanı",                team = "MTF",              color = "Bright blue", health = 130, speed = 17, spawn = "MTF",          level = "3. Seviye Personel", icon = "", tools = {"Keycard3", "Rifle"}},
	ntf_cavus    = {name = "NTF Çavuşu",                team = "MTF",              color = "Bright blue", health = 140, speed = 17, spawn = "MTF",          level = "4. Seviye Personel", icon = "", tools = {"Keycard4", "Rifle"}},
	ntf_albay    = {name = "NTF Albayı",                team = "MTF",              color = "Bright blue", health = 160, speed = 17, spawn = "MTF",          level = "5. Seviye Personel", icon = "", tools = {"Keycard5", "Rifle"}},
	kaos_acemi   = {name = "Kaos İsyancıları Acemisi",  team = "Chaos Insurgency", color = "Black",       health = 110, speed = 16, spawn = "Chaos",        level = "2. Seviye Personel", icon = "", tools = {"Keycard2", "Pistol"}},
	kaos_piyade  = {name = "Kaos İsyancıları Piyadesi", team = "Chaos Insurgency", color = "Black",       health = 130, speed = 17, spawn = "Chaos",        level = "3. Seviye Personel", icon = "", tools = {"Keycard3", "Rifle"}},
	kaos_akinci  = {name = "Kaos İsyancıları Akıncısı", team = "Chaos Insurgency", color = "Black",       health = 140, speed = 18, spawn = "Chaos",        level = "4. Seviye Personel", icon = "", tools = {"Keycard4", "Rifle"}},
	kaos_komutan = {name = "Kaos İsyancıları Komutanı", team = "Chaos Insurgency", color = "Black",       health = 170, speed = 17, spawn = "Chaos",        level = "5. Seviye Personel", icon = "", tools = {"Keycard5", "Rifle"}},
	goc          = {name = "GOC",                       team = "GOC",              color = "Navy blue",   health = 150, speed = 17, spawn = "GOC",          level = "4. Seviye Personel", icon = "", tools = {"Keycard4", "Rifle"}},
	goi          = {name = "GOI",                       team = "GOI",              color = "Dark green",  health = 120, speed = 16, spawn = "GOI",          level = "3. Seviye Personel", icon = "", tools = {"Keycard3", "Pistol"}},
	yilanin_eli  = {name = "Yılanın Eli",               team = "Serpent's Hand",   color = "Camo",        health = 130, speed = 17, spawn = "SerpentsHand", level = "3. Seviye Personel", icon = "", tools = {"Keycard3", "Pistol"}},
}

----------------------------------------------------------------
-- REMOTE'LAR
----------------------------------------------------------------
local remotes = Instance.new("Folder")
remotes.Name = "AdminRemotes"
remotes.Parent = ReplicatedStorage

local actionRF = Instance.new("RemoteFunction")
actionRF.Name = "AdminAction"
actionRF.Parent = remotes

local rolesRF = Instance.new("RemoteFunction")
rolesRF.Name = "GetRoles"
rolesRF.Parent = remotes

----------------------------------------------------------------
-- YARDIMCI FONKSIYONLAR
----------------------------------------------------------------
local function isAdmin(player)
	if player.UserId == game.CreatorId then return true end
	if game.CreatorType == Enum.CreatorType.Group then
		local ok, rank = pcall(function() return player:GetRankInGroup(game.CreatorId) end)
		if ok and rank >= 255 then return true end
	end
	return table.find(ADMINS, player.UserId) ~= nil
end

local function clean(text, maxLen)
	if typeof(text) ~= "string" then return nil end
	text = string.gsub(text, "^%s+", "")
	text = string.gsub(text, "%s+$", "")
	if text == "" then return nil end
	return string.sub(text, 1, maxLen)
end

local function normalizeIcon(text)
	text = clean(text, 60)
	if not text then return nil end
	if tonumber(text) then return "rbxassetid://" .. text end
	if string.sub(text, 1, 13) == "rbxassetid://" then return text end
	return nil
end

local function getTeam(name, color)
	local t = Teams:FindFirstChild(name)
	if not t then
		t = Instance.new("Team")
		t.Name = name
		t.TeamColor = BrickColor.new(color)
		t.AutoAssignable = false
		t.Parent = Teams
	end
	return t
end

local SCALE_NAMES = {"BodyHeightScale", "BodyWidthScale", "BodyDepthScale", "HeadScale"}

local function applyScale(hum, scale)
	for _, n in ipairs(SCALE_NAMES) do
		local v = hum:FindFirstChild(n)
		if v then v.Value = scale end
	end
end

----------------------------------------------------------------
-- KAFANIN USTUNDEKI ETIKET: [simge] Isim / Yetki seviyesi
----------------------------------------------------------------
local function buildTag(player, char)
	local hum = char:FindFirstChildOfClass("Humanoid")
	local head = char:FindFirstChild("Head")
	if not hum or not head then return end

	local role = ROLES[player:GetAttribute("RoleKey") or ""]
	local title = player:GetAttribute("RPName") or (role and role.name) or player.DisplayName
	local level = player:GetAttribute("RPLevel") or (role and role.level) or ""
	local icon = player:GetAttribute("RoleIcon") or (role and role.icon ~= "" and role.icon) or nil

	hum.DisplayName = title
	hum.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None

	local old = head:FindFirstChild("RPTag")
	if old then old:Destroy() end

	local gui = Instance.new("BillboardGui")
	gui.Name = "RPTag"
	gui.Size = UDim2.fromOffset(280, 60)
	gui.StudsOffset = Vector3.new(0, 3, 0)
	gui.MaxDistance = 45
	gui.Adornee = head
	gui.Parent = head

	local textX = 0
	if icon then
		local img = Instance.new("ImageLabel")
		img.Size = UDim2.fromOffset(52, 52)
		img.Position = UDim2.fromOffset(0, 4)
		img.BackgroundTransparency = 1
		img.Image = icon
		img.Parent = gui
		textX = 58
	end

	local nameLabel = Instance.new("TextLabel")
	nameLabel.Size = UDim2.new(1, -textX, 0.55, 0)
	nameLabel.Position = UDim2.new(0, textX, 0, 0)
	nameLabel.BackgroundTransparency = 1
	nameLabel.TextScaled = true
	nameLabel.TextXAlignment = icon and Enum.TextXAlignment.Left or Enum.TextXAlignment.Center
	nameLabel.Font = Enum.Font.GothamBold
	nameLabel.TextColor3 = Color3.new(1, 1, 1)
	nameLabel.TextStrokeTransparency = 0.3
	nameLabel.Text = title
	nameLabel.Parent = gui

	local levelLabel = Instance.new("TextLabel")
	levelLabel.Size = UDim2.new(1, -textX, 0.4, 0)
	levelLabel.Position = UDim2.new(0, textX, 0.58, 0)
	levelLabel.BackgroundTransparency = 1
	levelLabel.TextScaled = true
	levelLabel.TextXAlignment = nameLabel.TextXAlignment
	levelLabel.Font = Enum.Font.Gotham
	levelLabel.TextColor3 = player.Team and player.Team.TeamColor.Color or Color3.fromRGB(200, 200, 200)
	levelLabel.TextStrokeTransparency = 0.4
	levelLabel.Text = level
	levelLabel.Parent = gui
end

local function applyCharacter(player, char)
	-- HUD rol ekrani icin rol adi ve varsayilan yetki seviyesi
	local roleForHud = ROLES[player:GetAttribute("RoleKey") or ""]
	player:SetAttribute("RoleName", roleForHud and roleForHud.name or nil)
	player:SetAttribute("RoleLevel", roleForHud and roleForHud.level or nil)

	local hum = char:WaitForChild("Humanoid")
	task.wait(0.2) -- R15 scale degerleri yuklensin

	local scale = player:GetAttribute("BoyScale")
	if scale then applyScale(hum, scale) end

	local role = ROLES[player:GetAttribute("RoleKey") or ""]
	if role then
		hum.MaxHealth = role.health
		hum.Health = role.health
		hum.WalkSpeed = role.speed
		local toolsFolder = ServerStorage:FindFirstChild("Tools")
		if toolsFolder then
			for _, toolName in ipairs(role.tools) do
				local tool = toolsFolder:FindFirstChild(toolName)
				if tool then tool:Clone().Parent = player.Backpack end
			end
		end
	end
	buildTag(player, char)
end

local function onPlayer(player)
	if isAdmin(player) then player:SetAttribute("IsAdmin", true) end
	player.CharacterAdded:Connect(function(char) applyCharacter(player, char) end)
end
Players.PlayerAdded:Connect(onPlayer)
for _, p in ipairs(Players:GetPlayers()) do onPlayer(p) end

----------------------------------------------------------------
-- ROL VERME: izleyiciden cikarir, spawn noktasinda dogurur
----------------------------------------------------------------
local function setRole(player, roleKey)
	local role = ROLES[roleKey]
	if not role then return end
	player:SetAttribute("RoleKey", roleKey)
	player.Team = getTeam(role.team, role.color) -- Spectator takimindan cikar
	player:LoadCharacter()

	local char = player.Character or player.CharacterAdded:Wait()
	local spawns = workspace:FindFirstChild("Spawns")
	if spawns then
		local options = {}
		for _, p in ipairs(spawns:GetChildren()) do
			if p.Name == role.spawn then table.insert(options, p) end
		end
		if #options > 0 then
			char:PivotTo(options[math.random(#options)].CFrame + Vector3.new(0, 4, 0))
		else
			warn("Spawn bulunamadi: " .. role.spawn)
		end
	end
end

_G.SetRole = setRole -- RoundManager: _G.SetRole(player, "d_class")
_G.SCPRoles = ROLES

----------------------------------------------------------------
-- PANEL ISTEKLERI
----------------------------------------------------------------
rolesRF.OnServerInvoke = function(admin)
	if not isAdmin(admin) then return {} end
	local list = {}
	for _, key in ipairs(ROLE_ORDER) do
		table.insert(list, {key = key, name = ROLES[key].name, level = ROLES[key].level})
	end
	return list
end

actionRF.OnServerInvoke = function(admin, data)
	if not isAdmin(admin) then return "Yetkin yok." end
	if typeof(data) ~= "table" then return "Geçersiz istek." end

	local target = Players:GetPlayerByUserId(tonumber(data.target) or 0)
	if not target then return "Oyuncu bulunamadı." end

	if data.action == "reset" then
		target:SetAttribute("RPName", nil)
		target:SetAttribute("RPLevel", nil)
		target:SetAttribute("BoyScale", nil)
		target:SetAttribute("RoleIcon", nil)
		if target.Character then
			local hum = target.Character:FindFirstChildOfClass("Humanoid")
			if hum then applyScale(hum, 1) end
			buildTag(target, target.Character)
		end
		return target.Name .. " sıfırlandı."
	end

	if data.action ~= "apply" then return "Bilinmeyen işlem." end

	-- isim / yetki / ikon / boy (bos birakilirsa mevcut deger korunur)
	local name = clean(data.name, 40)
	local level = clean(data.level, 40)
	local icon = normalizeIcon(data.icon)
	local height = tonumber(data.height)

	if name then target:SetAttribute("RPName", name) end
	if level then target:SetAttribute("RPLevel", level) end
	if icon then target:SetAttribute("RoleIcon", icon) end
	if height then target:SetAttribute("BoyScale", math.clamp(height, MIN_BOY, MAX_BOY)) end

	local roleKey = data.role
	if typeof(roleKey) == "string" and ROLES[roleKey] then
		-- rol degisti: yeni karakter, spawn noktasinda dogar, hepsi CharacterAdded'de uygulanir
		setRole(target, roleKey)
		return target.Name .. " → " .. ROLES[roleKey].name .. " olarak doğdu."
	end

	-- rol degismedi: mevcut karakteri guncelle
	local char = target.Character
	if char then
		local hum = char:FindFirstChildOfClass("Humanoid")
		local scale = target:GetAttribute("BoyScale")
		if hum and scale then applyScale(hum, scale) end
		buildTag(target, char)
	end
	return target.Name .. " güncellendi."
end
