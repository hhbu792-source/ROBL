-- StarterPlayer > StarterPlayerScripts icine "AdminPanelClient" adiyla LOCALSCRIPT olarak koy.
-- Paneli M tusu ile ac/kapat (sadece adminlerde calisir).

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local UserInputService = game:GetService("UserInputService")

local player = Players.LocalPlayer
local remotes = ReplicatedStorage:WaitForChild("AdminRemotes")
local actionRF = remotes:WaitForChild("AdminAction")
local rolesRF = remotes:WaitForChild("GetRoles")

-- RENKLER
local BG = Color3.fromRGB(24, 26, 32)
local PANEL = Color3.fromRGB(34, 37, 46)
local ITEM = Color3.fromRGB(48, 52, 64)
local SELECTED = Color3.fromRGB(70, 110, 190)
local TEXT = Color3.fromRGB(235, 235, 240)
local MUTED = Color3.fromRGB(150, 155, 170)

local selectedUserId = nil
local selectedRole = nil

----------------------------------------------------------------
-- UI YARDIMCILARI
----------------------------------------------------------------
local function corner(obj, r)
	local c = Instance.new("UICorner")
	c.CornerRadius = UDim.new(0, r or 6)
	c.Parent = obj
end

local function makeLabel(parent, text, pos, size)
	local l = Instance.new("TextLabel")
	l.BackgroundTransparency = 1
	l.Text = text
	l.Position = pos
	l.Size = size or UDim2.fromOffset(260, 18)
	l.TextXAlignment = Enum.TextXAlignment.Left
	l.Font = Enum.Font.GothamMedium
	l.TextSize = 13
	l.TextColor3 = MUTED
	l.Parent = parent
	return l
end

local function makeBox(parent, placeholder, pos)
	local b = Instance.new("TextBox")
	b.Position = pos
	b.Size = UDim2.fromOffset(260, 32)
	b.BackgroundColor3 = ITEM
	b.PlaceholderText = placeholder
	b.PlaceholderColor3 = MUTED
	b.Text = ""
	b.TextColor3 = TEXT
	b.Font = Enum.Font.Gotham
	b.TextSize = 14
	b.ClearTextOnFocus = false
	b.TextXAlignment = Enum.TextXAlignment.Left
	b.Parent = parent
	corner(b)
	local pad = Instance.new("UIPadding")
	pad.PaddingLeft = UDim.new(0, 8)
	pad.Parent = b
	return b
end

local function makeButton(parent, text, pos, size, color)
	local b = Instance.new("TextButton")
	b.Position = pos
	b.Size = size
	b.BackgroundColor3 = color or ITEM
	b.Text = text
	b.TextColor3 = TEXT
	b.Font = Enum.Font.GothamBold
	b.TextSize = 14
	b.AutoButtonColor = true
	b.Parent = parent
	corner(b)
	return b
end

local function makeList(parent, pos, height)
	local s = Instance.new("ScrollingFrame")
	s.Position = pos
	s.Size = UDim2.fromOffset(260, height)
	s.BackgroundColor3 = PANEL
	s.BorderSizePixel = 0
	s.ScrollBarThickness = 4
	s.CanvasSize = UDim2.new()
	s.AutomaticCanvasSize = Enum.AutomaticSize.Y
	s.Parent = parent
	corner(s)
	local layout = Instance.new("UIListLayout")
	layout.Padding = UDim.new(0, 3)
	layout.Parent = s
	local pad = Instance.new("UIPadding")
	pad.PaddingTop = UDim.new(0, 4)
	pad.PaddingLeft = UDim.new(0, 4)
	pad.PaddingRight = UDim.new(0, 4)
	pad.Parent = s
	return s
end

local function makeItem(list, text)
	local b = Instance.new("TextButton")
	b.Size = UDim2.new(1, -8, 0, 28)
	b.BackgroundColor3 = ITEM
	b.Text = text
	b.TextColor3 = TEXT
	b.Font = Enum.Font.Gotham
	b.TextSize = 13
	b.TextXAlignment = Enum.TextXAlignment.Left
	b.Parent = list
	corner(b, 4)
	local pad = Instance.new("UIPadding")
	pad.PaddingLeft = UDim.new(0, 8)
	pad.Parent = b
	return b
end

local function highlight(list, chosen)
	for _, c in ipairs(list:GetChildren()) do
		if c:IsA("TextButton") then
			c.BackgroundColor3 = (c == chosen) and SELECTED or ITEM
		end
	end
end

local function clearList(list)
	for _, c in ipairs(list:GetChildren()) do
		if c:IsA("TextButton") then c:Destroy() end
	end
end

----------------------------------------------------------------
-- PANEL
----------------------------------------------------------------
local gui = Instance.new("ScreenGui")
gui.Name = "AdminPanel"
gui.ResetOnSpawn = false
gui.Enabled = false
gui.Parent = player:WaitForChild("PlayerGui")

local frame = Instance.new("Frame")
frame.Size = UDim2.fromOffset(580, 470)
frame.Position = UDim2.new(0.5, -290, 0.5, -235)
frame.BackgroundColor3 = BG
frame.Active = true
frame.Draggable = true
frame.Parent = gui
corner(frame, 10)

local title = Instance.new("TextLabel")
title.Size = UDim2.new(1, -50, 0, 36)
title.Position = UDim2.fromOffset(14, 0)
title.BackgroundTransparency = 1
title.Text = "Admin Paneli"
title.TextXAlignment = Enum.TextXAlignment.Left
title.Font = Enum.Font.GothamBold
title.TextSize = 17
title.TextColor3 = TEXT
title.Parent = frame

local closeBtn = makeButton(frame, "X", UDim2.new(1, -36, 0, 5), UDim2.fromOffset(26, 26), Color3.fromRGB(170, 60, 60))
closeBtn.MouseButton1Click:Connect(function() gui.Enabled = false end)

-- Sol sutun: oyuncu ve rol listeleri
makeLabel(frame, "OYUNCU", UDim2.fromOffset(14, 42))
local playerList = makeList(frame, UDim2.fromOffset(14, 62), 170)

makeLabel(frame, "ROL (seçmezsen rol değişmez)", UDim2.fromOffset(14, 240))
local roleList = makeList(frame, UDim2.fromOffset(14, 260), 190)

-- Sag sutun: alanlar
makeLabel(frame, "İSİM / UNVAN (örn: Tesis Yöneticisi)", UDim2.fromOffset(306, 42))
local nameBox = makeBox(frame, "Boş = rol adı", UDim2.fromOffset(306, 62))

makeLabel(frame, "YETKİ SEVİYESİ (örn: 6. Seviye Personel)", UDim2.fromOffset(306, 102))
local levelBox = makeBox(frame, "Boş = rolün varsayılanı", UDim2.fromOffset(306, 122))

makeLabel(frame, "BOY (0.5 - 2)", UDim2.fromOffset(306, 162))
local heightBox = makeBox(frame, "Örn: 1.1", UDim2.fromOffset(306, 182))

makeLabel(frame, "ROL SİMGESİ (Asset ID)", UDim2.fromOffset(306, 222))
local iconBox = makeBox(frame, "Boş = rolün simgesi", UDim2.fromOffset(306, 242))

local status = Instance.new("TextLabel")
status.Position = UDim2.fromOffset(306, 288)
status.Size = UDim2.fromOffset(260, 60)
status.BackgroundTransparency = 1
status.TextWrapped = true
status.TextXAlignment = Enum.TextXAlignment.Left
status.TextYAlignment = Enum.TextYAlignment.Top
status.Font = Enum.Font.Gotham
status.TextSize = 13
status.TextColor3 = MUTED
status.Text = "Önce bir oyuncu seç."
status.Parent = frame

local applyBtn = makeButton(frame, "UYGULA", UDim2.fromOffset(306, 360), UDim2.fromOffset(260, 42), Color3.fromRGB(60, 150, 90))
local resetBtn = makeButton(frame, "İSİM / BOY SIFIRLA", UDim2.fromOffset(306, 410), UDim2.fromOffset(260, 36), Color3.fromRGB(150, 90, 50))

----------------------------------------------------------------
-- LISTELERI DOLDUR
----------------------------------------------------------------
local function refreshPlayers()
	clearList(playerList)
	for _, p in ipairs(Players:GetPlayers()) do
		local item = makeItem(playerList, p.DisplayName .. "  (@" .. p.Name .. ")")
		if p.UserId == selectedUserId then item.BackgroundColor3 = SELECTED end
		item.MouseButton1Click:Connect(function()
			selectedUserId = p.UserId
			highlight(playerList, item)
			-- mevcut degerleri kutulara yaz
			nameBox.Text = p:GetAttribute("RPName") or ""
			levelBox.Text = p:GetAttribute("RPLevel") or ""
			local scale = p:GetAttribute("BoyScale")
			heightBox.Text = scale and tostring(scale) or ""
			iconBox.Text = ""
			status.Text = "Seçildi: " .. p.Name
		end)
	end
end

local function refreshRoles()
	clearList(roleList)
	local none = makeItem(roleList, "— Rolü değiştirme —")
	none.BackgroundColor3 = SELECTED
	none.MouseButton1Click:Connect(function()
		selectedRole = nil
		highlight(roleList, none)
	end)

	local ok, roles = pcall(function() return rolesRF:InvokeServer() end)
	if not ok or typeof(roles) ~= "table" then return end
	for _, r in ipairs(roles) do
		local item = makeItem(roleList, r.name)
		item.MouseButton1Click:Connect(function()
			selectedRole = r.key
			highlight(roleList, item)
			if levelBox.Text == "" then levelBox.PlaceholderText = r.level end
		end)
	end
end

Players.PlayerAdded:Connect(function() if gui.Enabled then refreshPlayers() end end)
Players.PlayerRemoving:Connect(function()
	task.defer(function() if gui.Enabled then refreshPlayers() end end)
end)

----------------------------------------------------------------
-- BUTONLAR
----------------------------------------------------------------
applyBtn.MouseButton1Click:Connect(function()
	if not selectedUserId then
		status.Text = "Önce bir oyuncu seç."
		return
	end
	status.Text = "Uygulanıyor..."
	local ok, result = pcall(function()
		return actionRF:InvokeServer({
			action = "apply",
			target = selectedUserId,
			role = selectedRole,
			name = nameBox.Text,
			level = levelBox.Text,
			height = heightBox.Text,
			icon = iconBox.Text,
		})
	end)
	status.Text = ok and tostring(result) or "Hata oluştu."
end)

resetBtn.MouseButton1Click:Connect(function()
	if not selectedUserId then
		status.Text = "Önce bir oyuncu seç."
		return
	end
	local ok, result = pcall(function()
		return actionRF:InvokeServer({action = "reset", target = selectedUserId})
	end)
	status.Text = ok and tostring(result) or "Hata oluştu."
	nameBox.Text, levelBox.Text, heightBox.Text, iconBox.Text = "", "", "", ""
end)

----------------------------------------------------------------
-- F2 ILE AC / KAPAT
----------------------------------------------------------------
UserInputService.InputBegan:Connect(function(input, processed)
	if processed or input.KeyCode ~= Enum.KeyCode.M then return end
	if not player:GetAttribute("IsAdmin") then return end
	gui.Enabled = not gui.Enabled
	if gui.Enabled then
		refreshPlayers()
		refreshRoles()
	end
end)
