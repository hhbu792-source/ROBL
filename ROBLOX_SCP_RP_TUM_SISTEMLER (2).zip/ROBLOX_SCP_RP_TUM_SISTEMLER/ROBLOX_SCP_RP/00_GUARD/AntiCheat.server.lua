-- ServerScriptService icine "AntiCheat" adiyla normal SCRIPT olarak koy.
--
-- Sunucu taraflidir: oyuncunun karakterini periyodik olarak olcer ve su hileleri yakalar:
--   * Hiz hilesi (WalkSpeed/JumpPower ayari + gercek hiz olcumu)
--   * Isinlanma
--   * Ucma (havada asili kalma / yukselme)
--   * Noclip (duvardan gecme)
-- Ceza: karakteri geri cekme (rubber-band) -> uyari puani -> belirli puanda kick (istege bagli ban).
-- Adminler Config'e gore muaftir. Supheli durumlar admin konsoluna (RP konsolu) kirmizi yazi olarak duser.
--
-- MESRU ISINLAMA ICIN: baska bir script oyuncuyu isinlayacaksa (Warhead, SCP-106 vb.) once sunu yaz:
--   player:SetAttribute("ACExemptUntil", workspace:GetServerTimeNow() + 3)
-- (3 saniye boyunca kontrol edilmez). Dogma / rol verme / .bayil zaten otomatik muaftir.

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

----------------------------------------------------------------
-- AYARLAR
----------------------------------------------------------------
local CFG = {
	ENABLED = true,
	EXEMPT_ADMINS = true,     -- IsAdmin attribute'u olan oyuncular kontrol edilmez (test icin false yap)
	CHECK_INTERVAL = 0.5,     -- kontrol araligi (sn)
	GRACE_AFTER_SPAWN = 4,    -- dogduktan sonra kac sn kontrol edilmesin (spawn isinlamasi icin)

	-- HIZ / ISINLANMA
	SPEED_LIMIT = 36,         -- insan icin izin verilen gercek hiz (stud/sn); en hizli rol ~18, tolerans payi var
	SPEED_LIMIT_SCP = 90,     -- SCP takimi icin
	TELEPORT_DISTANCE = 70,   -- tek kontrol araliginda bu kadar stud giderse isinlanma sayilir
	MAX_WALKSPEED = 24,       -- bunu asan WalkSpeed degeri hile sayilir
	MAX_WALKSPEED_SCP = 70,
	DEFAULT_WALKSPEED = 16,   -- hile bulununca donulecek deger
	MAX_JUMPPOWER = 75,
	DEFAULT_JUMPPOWER = 50,
	MAX_JUMPHEIGHT = 12,
	DEFAULT_JUMPHEIGHT = 7.2,

	-- UCMA
	FLY_CHECK = true,
	FLY_AIR_TIME = 2.0,       -- bu kadar sn havada kalip dusmuyorsa supheli
	FLY_MIN_FALL_SPEED = 12,  -- asagi dikey hiz bunun altindaysa (dusmuyor) supheli

	-- NOCLIP
	NOCLIP_CHECK = true,
	NOCLIP_HITS = 3,          -- bu kadar duvar ihlali ...
	NOCLIP_WINDOW = 10,       -- ... bu kadar sn icinde olursa ceza

	-- CEZA
	RUBBER_BAND = true,       -- hile bulununca oyuncuyu son temiz konuma geri cek
	KICK_ENABLED = true,      -- false yaparsan sadece kaydeder ve geri ceker (ilk gunler icin onerilir)
	KICK_STRIKES = 8,         -- STRIKE_WINDOW icinde toplam bu puana ulasan atilir
	STRIKE_WINDOW = 60,
	KICK_MESSAGE = "Anti-cheat: şüpheli hareket tespit edildi.",
	USE_BAN = false,          -- true: kick yerine ban (Players:BanAsync)
	BAN_SECONDS = 24 * 60 * 60, -- -1 = kalici

	-- BILDIRIM
	NOTIFY_ADMINS = true,
	NOTIFY_COOLDOWN = 5,      -- ayni oyuncu + sebep icin tekrar bildirim araligi (sn)
}

if not CFG.ENABLED then return end

----------------------------------------------------------------
-- DURUM
----------------------------------------------------------------
local data = {}

local rayParams = RaycastParams.new()
rayParams.FilterType = Enum.RaycastFilterType.Exclude
rayParams.RespectCanCollide = true

-- Havada olmasi normal sayilan Humanoid durumlari
local SKIP_STATES = {
	[Enum.HumanoidStateType.Climbing] = true,
	[Enum.HumanoidStateType.Swimming] = true,
	[Enum.HumanoidStateType.Seated] = true,
	[Enum.HumanoidStateType.PlatformStanding] = true,
	[Enum.HumanoidStateType.Ragdoll] = true,
	[Enum.HumanoidStateType.Physics] = true,
	[Enum.HumanoidStateType.FallingDown] = true,
	[Enum.HumanoidStateType.GettingUp] = true,
	[Enum.HumanoidStateType.Dead] = true,
}

local function newData()
	return {
		lastPos = nil, lastTime = nil, lastGood = nil, lastGround = nil,
		graceUntil = os.clock() + CFG.GRACE_AFTER_SPAWN,
		speedHits = 0, airTime = 0, flyHits = 0,
		noclipHits = {}, strikes = {}, lastNotify = {},
	}
end

----------------------------------------------------------------
-- BILDIRIM VE CEZA
----------------------------------------------------------------
local function notifyAdmins(text)
	if not CFG.NOTIFY_ADMINS then return end
	local folder = ReplicatedStorage:FindFirstChild("RPRemotes")
	local remote = folder and folder:FindFirstChild("RPConsole")
	if not remote then return end
	for _, p in ipairs(Players:GetPlayers()) do
		if p:GetAttribute("IsAdmin") then
			remote:FireClient(p, text, Color3.fromRGB(255, 90, 90))
		end
	end
end

local function punish(player, reason)
	if CFG.USE_BAN then
		local ok, err = pcall(function()
			Players:BanAsync({
				UserIds = {player.UserId},
				Duration = CFG.BAN_SECONDS,
				DisplayReason = CFG.KICK_MESSAGE,
				PrivateReason = "AntiCheat: " .. reason,
				ExcludeAltAccounts = false,
				ApplyToUniverse = true,
			})
		end)
		if not ok then
			warn("[AntiCheat] Ban basarisiz, kick yapiliyor: " .. tostring(err))
			player:Kick(CFG.KICK_MESSAGE)
		end
	else
		player:Kick(CFG.KICK_MESSAGE)
	end
end

local function strike(player, reason, weight)
	local d = data[player]
	if not d then return end
	local now = os.clock()

	-- eski puanlari sil
	for i = #d.strikes, 1, -1 do
		if now - d.strikes[i].t > CFG.STRIKE_WINDOW then table.remove(d.strikes, i) end
	end
	table.insert(d.strikes, {t = now, w = weight})

	local total = 0
	for _, s in ipairs(d.strikes) do total += s.w end

	warn(string.format("[AntiCheat] %s (%d): %s | puan %d/%d", player.Name, player.UserId, reason, total, CFG.KICK_STRIKES))

	local key = string.match(reason, "^[^%(]+") or reason
	if not d.lastNotify[key] or now - d.lastNotify[key] >= CFG.NOTIFY_COOLDOWN then
		d.lastNotify[key] = now
		notifyAdmins(string.format("[AntiCheat] %s: %s (puan %d/%d)", player.Name, reason, total, CFG.KICK_STRIKES))
	end

	if CFG.KICK_ENABLED and total >= CFG.KICK_STRIKES then
		punish(player, reason)
	end
end

local function rubberBand(player, cf)
	if not CFG.RUBBER_BAND or not cf then return end
	local char = player.Character
	local root = char and char:FindFirstChild("HumanoidRootPart")
	if root then
		root.AssemblyLinearVelocity = Vector3.zero
		root.CFrame = cf
	end
end

----------------------------------------------------------------
-- KONTROL
----------------------------------------------------------------
local function isExempt(player, d)
	if player:GetAttribute("Fainted") == true then return true end
	if CFG.EXEMPT_ADMINS and player:GetAttribute("IsAdmin") == true then return true end
	if os.clock() < d.graceUntil then return true end
	local untilTime = player:GetAttribute("ACExemptUntil")
	if typeof(untilTime) == "number" and workspace:GetServerTimeNow() < untilTime then return true end
	return false
end

local function check(player)
	local d = data[player]
	if not d then return end

	local char = player.Character
	local hum = char and char:FindFirstChildOfClass("Humanoid")
	local root = char and char:FindFirstChild("HumanoidRootPart")
	local now = os.clock()

	if not hum or not root or hum.Health <= 0 then
		d.lastPos = nil
		return
	end

	-- Muaf durumda sadece referans noktalarini guncelle
	if isExempt(player, d) then
		d.lastPos, d.lastTime, d.lastGood, d.lastGround = root.Position, now, root.CFrame, root.CFrame
		d.speedHits, d.airTime, d.flyHits = 0, 0, 0
		return
	end

	local isSCP = player.Team ~= nil and player.Team.Name == "SCP"

	-- 1) HUMANOID OZELLIKLERI (istemci bunlari degistirip sunucuya yansitabilir)
	local maxWalk = isSCP and CFG.MAX_WALKSPEED_SCP or CFG.MAX_WALKSPEED
	if hum.WalkSpeed > maxWalk then
		strike(player, string.format("WalkSpeed %d", hum.WalkSpeed), 2)
		hum.WalkSpeed = CFG.DEFAULT_WALKSPEED
	end
	if hum.UseJumpPower then
		if hum.JumpPower > CFG.MAX_JUMPPOWER then
			strike(player, string.format("JumpPower %d", hum.JumpPower), 2)
			hum.JumpPower = CFG.DEFAULT_JUMPPOWER
		end
	elseif hum.JumpHeight > CFG.MAX_JUMPHEIGHT then
		strike(player, string.format("JumpHeight %d", hum.JumpHeight), 2)
		hum.JumpHeight = CFG.DEFAULT_JUMPHEIGHT
	end

	-- 2) HAREKET OLCUMU
	local pos = root.Position

	if d.lastPos and d.lastTime then
		local dt = math.max(now - d.lastTime, 0.05)
		local delta = pos - d.lastPos
		local horiz = Vector3.new(delta.X, 0, delta.Z).Magnitude
		local speed = horiz / dt
		local limit = isSCP and CFG.SPEED_LIMIT_SCP or CFG.SPEED_LIMIT

		-- 2a) Isinlanma
		if horiz >= CFG.TELEPORT_DISTANCE then
			strike(player, string.format("ışınlanma (%d stud)", horiz), 3)
			rubberBand(player, d.lastGood)
			d.lastPos = d.lastGood and d.lastGood.Position or pos
			d.lastTime = now
			return
		end

		-- 2b) Hiz (tek olcum gecikmeyle bozulabilir; art arda 2 olcum gerekir)
		if speed > limit then
			d.speedHits += 1
			if d.speedHits >= 2 then
				strike(player, string.format("hız (%d stud/sn)", speed), 2)
				rubberBand(player, d.lastGood)
				d.speedHits = 0
				d.lastPos = d.lastGood and d.lastGood.Position or pos
				d.lastTime = now
				return
			end
		else
			d.speedHits = 0
		end

		-- 2c) Noclip: iki olcum arasinda sabit bir duvardan gecti mi?
		if CFG.NOCLIP_CHECK and horiz > 1 then
			local lift = Vector3.new(0, 1, 0)
			local origin = d.lastPos + lift
			local result = workspace:Raycast(origin, (pos + lift) - origin, rayParams)
			if result and result.Instance.CanCollide and result.Instance.Anchored then
				table.insert(d.noclipHits, now)
				for i = #d.noclipHits, 1, -1 do
					if now - d.noclipHits[i] > CFG.NOCLIP_WINDOW then table.remove(d.noclipHits, i) end
				end
				if #d.noclipHits >= CFG.NOCLIP_HITS then
					strike(player, "noclip (" .. result.Instance.Name .. ")", 3)
					rubberBand(player, d.lastGood)
					d.noclipHits = {}
					d.lastPos = d.lastGood and d.lastGood.Position or pos
					d.lastTime = now
					return
				end
			end
		end

		-- 2d) Ucma: uzun suredir havada ve dusmuyor
		if CFG.FLY_CHECK then
			local airborne = hum.FloorMaterial == Enum.Material.Air and not SKIP_STATES[hum:GetState()]
			if airborne then
				d.airTime += dt
				local vy = root.AssemblyLinearVelocity.Y
				if d.airTime > CFG.FLY_AIR_TIME and vy > -CFG.FLY_MIN_FALL_SPEED then
					d.flyHits += 1
					if d.flyHits >= 2 then
						strike(player, "uçma", 3)
						rubberBand(player, d.lastGround or d.lastGood)
						d.flyHits, d.airTime = 0, 0
						d.lastPos = (d.lastGround or d.lastGood or root.CFrame).Position
						d.lastTime = now
						return
					end
				elseif vy <= -CFG.FLY_MIN_FALL_SPEED then
					d.flyHits = 0 -- gercekten dusuyor
				end
			else
				d.airTime, d.flyHits = 0, 0
				d.lastGround = root.CFrame
			end
		end
	end

	d.lastPos, d.lastTime, d.lastGood = pos, now, root.CFrame
	if not d.lastGround then d.lastGround = root.CFrame end
end

----------------------------------------------------------------
-- OYUNCU BAGLANTILARI
----------------------------------------------------------------
local function onPlayer(player)
	data[player] = newData()
	player.CharacterAdded:Connect(function()
		local d = data[player]
		if not d then return end
		d.lastPos, d.lastTime, d.lastGood, d.lastGround = nil, nil, nil, nil
		d.speedHits, d.airTime, d.flyHits = 0, 0, 0
		d.noclipHits = {}
		d.graceUntil = os.clock() + CFG.GRACE_AFTER_SPAWN
	end)
end

Players.PlayerAdded:Connect(onPlayer)
for _, p in ipairs(Players:GetPlayers()) do onPlayer(p) end
Players.PlayerRemoving:Connect(function(p) data[p] = nil end)

task.spawn(function()
	while true do
		task.wait(CFG.CHECK_INTERVAL)

		-- Noclip raycast'inde karakterler engel sayilmasin
		local ignore = {}
		for _, p in ipairs(Players:GetPlayers()) do
			if p.Character then table.insert(ignore, p.Character) end
		end
		rayParams.FilterDescendantsInstances = ignore

		for _, p in ipairs(Players:GetPlayers()) do
			local ok, err = pcall(check, p)
			if not ok then warn("[AntiCheat] kontrol hatasi: " .. tostring(err)) end
		end
	end
end)

print("[AntiCheat] hazir")
