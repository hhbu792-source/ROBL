-- ServerScriptService icine "SingleServerGuard" adiyla normal SCRIPT olarak koy.
--
-- NE YAPAR: Oyunun "ana sunucusu" tek olur. Roblox yeni bir sunucu acarsa, o sunucu ana sunucuyu
-- bulur ve oyunculari otomatik olarak oraya isinlar (TeleportService). Ana sunucu kapanirsa
-- siradaki sunucu ana sunucu olur.
--
-- GEREKENLER:
--  1) Oyun yayinlanmis olmali (MemoryStore yayinlanmamis oyunda calismaz).
--  2) Game Settings > Places > Max Players degerini yuksek tut (ör. 100-200); ana sunucu dolarsa
--     yeni gelenler "Sunucu dolu" mesajiyla atilir.
--  3) Studio'da denemek icin: Game Settings > Security > "Enable Studio Access to API Services" ac
--     ve asagida ENABLED_IN_STUDIO = true yap. (Studio testinde zaten tek sunucu vardir.)

local Players = game:GetService("Players")
local MemoryStoreService = game:GetService("MemoryStoreService")
local TeleportService = game:GetService("TeleportService")
local RunService = game:GetService("RunService")

----------------------------------------------------------------
-- AYARLAR
----------------------------------------------------------------
local ENABLED = true
local ENABLED_IN_STUDIO = false   -- Studio'da kapali; yayinlanmis oyunda calisir
local LOCK_KEY = "MainServerLock"
local HEARTBEAT = 15              -- ana sunucu kilidi kac saniyede bir yeniler
local LOCK_TTL = 60               -- kilit en fazla bu kadar sn yasar (sunucu cokerse kendiliginden biter)
local STALE_AFTER = 45            -- kilit bu kadar sn yenilenmediyse sahibi oldu sayilir
local MAX_TRIES = 3               -- bir oyuncu icin isinlama deneme sayisi
local KICK_MESSAGE = "Ana sunucuya bağlanılamadı. Lütfen birkaç saniye sonra tekrar katıl."

----------------------------------------------------------------
-- ATLAMA KOSULLARI
----------------------------------------------------------------
if not ENABLED then return end

if RunService:IsStudio() and not ENABLED_IN_STUDIO then
	print("[SingleServer] Studio'da kapali (ENABLED_IN_STUDIO = false)")
	return
end

if game.PrivateServerId ~= "" then
	print("[SingleServer] Ozel / ayrilmis sunucu, koruma atlandi")
	return
end

----------------------------------------------------------------
-- KILIT (MemoryStore)
----------------------------------------------------------------
local map = MemoryStoreService:GetSortedMap("SingleServerGuard")

local isMain = true     -- MemoryStore calismazsa kimseyi atmamak icin varsayilan: ana sunucuyum
local mainJobId = game.JobId
local determined = false

-- Kilidi alir veya yeniler. Baska canli bir sunucu sahipse degistirmez.
local function refresh()
	local ok, result = pcall(function()
		return map:UpdateAsync(LOCK_KEY, function(current)
			local now = os.time()
			if current == nil or current.jobId == game.JobId or now - (current.time or 0) > STALE_AFTER then
				return {jobId = game.JobId, time = now}
			end
			return nil -- baska canli sahip var, dokunma
		end, LOCK_TTL)
	end)

	if not ok then
		warn("[SingleServer] MemoryStore hatasi (yayinlanmis oyun ve API erisimi gerekli): " .. tostring(result))
		return -- onceki durumu koru
	end

	if result ~= nil then
		-- kilit bizde
		if not isMain or not determined then
			print("[SingleServer] Bu sunucu ANA sunucu: " .. game.JobId)
		end
		isMain = true
		mainJobId = game.JobId
		determined = true
		return
	end

	-- kilit baskasinda: kimde?
	local okGet, current = pcall(function() return map:GetAsync(LOCK_KEY) end)
	if okGet and current and current.jobId then
		if isMain or mainJobId ~= current.jobId or not determined then
			print("[SingleServer] Ana sunucu baska: " .. current.jobId)
		end
		isMain = false
		mainJobId = current.jobId
		determined = true
	end
end

refresh()

----------------------------------------------------------------
-- OYUNCULARI ANA SUNUCUYA GONDER
----------------------------------------------------------------
local tries = {}

local function sendToMain(player)
	if isMain or player.Parent ~= Players then return end

	tries[player] = (tries[player] or 0) + 1
	if tries[player] > MAX_TRIES then
		player:Kick(KICK_MESSAGE)
		return
	end

	local ok, err = pcall(function()
		TeleportService:TeleportToPlaceInstance(game.PlaceId, mainJobId, player)
	end)
	if not ok then
		warn("[SingleServer] Isinlama baslatilamadi: " .. tostring(err))
		task.wait(2)
		refresh()
		sendToMain(player)
	end
end

-- Isinlama sonradan basarisiz olursa (sunucu dolu, ana sunucu kapandi vb.)
TeleportService.TeleportInitFailed:Connect(function(player, result, message)
	warn("[SingleServer] Isinlama basarisiz: " .. tostring(result) .. " - " .. tostring(message))
	if result == Enum.TeleportResult.GameFull then
		player:Kick("Sunucu dolu. Lütfen daha sonra tekrar dene.")
		return
	end
	task.wait(3)
	refresh() -- ana sunucu degismis olabilir (ya da bu sunucu ana oldu)
	if not isMain then
		sendToMain(player)
	end
end)

local function onPlayer(player)
	if not isMain then
		sendToMain(player)
	end
end

Players.PlayerAdded:Connect(onPlayer)
for _, p in ipairs(Players:GetPlayers()) do task.spawn(onPlayer, p) end

Players.PlayerRemoving:Connect(function(p) tries[p] = nil end)

----------------------------------------------------------------
-- KALP ATISI: kilidi yenile, ana sunucu degistiyse bekleyenleri yonlendir
----------------------------------------------------------------
task.spawn(function()
	while true do
		task.wait(HEARTBEAT)
		local wasMain = isMain
		refresh()
		if not isMain and not wasMain then
			-- hala ana sunucu degiliz ve icimizde oyuncu kalmis olabilir
			for _, p in ipairs(Players:GetPlayers()) do
				task.spawn(sendToMain, p)
			end
		end
	end
end)

----------------------------------------------------------------
-- KAPANIRKEN KILIDI BIRAK (siradaki sunucu hemen ana olabilsin)
----------------------------------------------------------------
game:BindToClose(function()
	if not isMain then return end
	pcall(function()
		local current = map:GetAsync(LOCK_KEY)
		if current and current.jobId == game.JobId then
			map:RemoveAsync(LOCK_KEY)
			print("[SingleServer] Ana sunucu kapaniyor, kilit birakildi")
		end
	end)
end)

print("[SingleServer] hazir (ana sunucu: " .. tostring(isMain) .. ")")
